/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        'sans': ['Satoshi', 'sans-serif'],
        'brand': ['Satoshi', 'sans-serif'],
        'display': ['Satoshi', 'sans-serif'],
      },
      colors: {
        // Futuristic SaaS Color Palette - Precision, Freedom, Modern Elegance
        // Base neutrals - ultra clean and sophisticated
        base: {
          white: '#FDFDFE',
          'white-pure': '#FFFFFF',
          'gray-50': '#F8FAFC',
          'gray-100': '#F1F5F9',
          'gray-200': '#E2E8F0',
          'gray-300': '#CBD5E1',
          'gray-400': '#94A3B8',
          'gray-500': '#64748B',
          'gray-600': '#475569',
          'gray-700': '#334155',
          'gray-800': '#1E293B',
          'gray-900': '#0F172A',
          'charcoal': '#0A0A0B',
          'charcoal-light': '#1A1A1B',
        },
        // Electric Blue spectrum - the hero color for AI/Tech feel
        electric: {
          50: '#F0FDFF', 
          100: '#D0F0FF', // Glacier blue
          200: '#A0E7FF',
          300: '#5EE3FF', // Main Electric Blue
          400: '#22D3EE',
          500: '#06B6D4',
          600: '#0891B2',
          700: '#0E7490',
          800: '#155E75',
          900: '#164E63',
        },
        // Ice Blue - complementary cool tone for data/precision
        ice: {
          50: '#F8FAFC',
          100: '#F1F5F9', 
          200: '#E2E8F0', 
          300: '#CBD5E1', 
          400: '#94A3B8',
          500: '#64748B',
          600: '#475569',
          700: '#334155',
          800: '#1E293B',
          900: '#0F172A',
        },
        // Lavender - soft accent for creativity/freedom
        lavender: {
          50: '#FAF9FF',
          100: '#F3F1FF', 
          200: '#E9E5FF', 
          300: '#D4CDFF', 
          400: '#B18CFF', // Main Lavender
          500: '#9F7AEA',
          600: '#805AD5',
          700: '#6B46C1',
          800: '#553C9A',
          900: '#44337A',
        },
        // Soft mist colors for backgrounds
        mist: {
          cyan: '#D0F0FF',
          lavender: '#FFE4F7',
          pearl: '#F8FCFF',
        },
        // Semantic colors using the futuristic palette
        primary: {
          50: '#F0FDFF',
          100: '#D0F0FF',
          200: '#A0E7FF',
          300: '#5EE3FF',
          400: '#22D3EE',
          500: '#06B6D4',
          600: '#0891B2',
          700: '#0E7490',
          800: '#155E75',
          900: '#164E63',
        },
        secondary: {
          50: '#F8FAFC',
          100: '#F1F5F9',
          200: '#E2E8F0',
          300: '#CBD5E1',
          400: '#94A3B8',
          500: '#64748B',
          600: '#475569',
          700: '#334155',
          800: '#1E293B',
          900: '#0F172A',
        },
        accent: {
          50: '#FAF9FF',
          100: '#F3F1FF',
          200: '#E9E5FF',
          300: '#D4CDFF',
          400: '#B18CFF',
          500: '#9F7AEA',
          600: '#805AD5',
          700: '#6B46C1',
          800: '#553C9A',
          900: '#44337A',
        },
        success: {
          50: '#F0FDF4',
          100: '#DCFCE7', 
          200: '#BBF7D0', 
          300: '#86EFAC', 
          400: '#22C55E', // Changed to be more vibrant
          500: '#16A34A',
          600: '#16A34A',
          700: '#15803D',
          800: '#166534',
          900: '#14532D',
        },
        warning: {
          50: '#FFFBEB',
          100: '#FEF3C7',
          200: '#FDE68A',
          300: '#FCD34D',
          400: '#FBBF24',
          500: '#F59E0B',
          600: '#D97706',
          700: '#B45309',
          800: '#92400E',
          900: '#78350F',
        },
        error: {
          50: '#FEF2F2',
          100: '#FEE2E2', 
          200: '#FECACA', 
          300: '#FCA5A5', 
          400: '#F87171', 
          500: '#EF4444',
          600: '#DC2626',
          700: '#B91C1C',
          800: '#991B1B',
          900: '#7F1D1D',
        },
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '128': '32rem',
      },
      borderRadius: {
        'xs': '0.25rem',
        'sm': '0.375rem',
        'md': '0.5rem', 
        'lg': '0.75rem', 
        'xl': '1rem', 
        '2xl': '1.5rem', 
        '3xl': '2rem', 
        'fluid': '1rem', // 16px
        'elevated': '2rem', // 32px - for cards and major elements
      },
      boxShadow: {
        'subtle': '0 1px 3px rgba(0, 0, 0, 0.01)',
        'soft': '0 4px 16px rgba(0, 0, 0, 0.02)',
        'elevated': '0 8px 32px rgba(0, 0, 0, 0.03)',
        'floating': '0 16px 48px rgba(0, 0, 0, 0.04)',
        'glass': '0 8px 32px rgba(94, 227, 255, 0.06)',
        'glass-strong': '0 16px 48px rgba(94, 227, 255, 0.1)',
        'inner-subtle': 'inset 0 1px 2px rgba(255, 255, 255, 0.05)',
        'inner-glass': 'inset 0 1px 2px rgba(255, 255, 255, 0.08)',
        'focus-electric': '0 0 0 3px rgba(94, 227, 255, 0.08)',
        'glow-electric': '0 0 20px rgba(94, 227, 255, 0.15)',
        'glow-lavender': '0 0 20px rgba(177, 140, 255, 0.15)',
      },
      animation: {
        'fade-in': 'fade-in 0.6s ease-out',
        'slide-up': 'slide-up 0.6s ease-out',
        'scale-in': 'scale-in 0.4s ease-out',
        'pulse-subtle': 'pulse-subtle 3s ease-in-out infinite',
        'float-gentle': 'floatGentle 20s ease-in-out infinite',
        'morph-gentle': 'morphGentle 30s ease-in-out infinite',
        'glow-pulse': 'glow-pulse 4s ease-in-out infinite',
      },
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1' },
        },
        'slide-up': {
          '0%': { opacity: '0', transform: 'translateY(16px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'scale-in': {
          '0%': { opacity: '0', transform: 'scale(0.96)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        'pulse-subtle': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.85' },
        },
        'glow-pulse': {
          '0%, 100%': { boxShadow: '0 0 20px rgba(94, 227, 255, 0.1)' },
          '50%': { boxShadow: '0 0 30px rgba(94, 227, 255, 0.2)' },
        },
        'float-gentle': {
          '0%, 100%': { 
            transform: 'translate(0, 0) scale(1)',
          },
          '33%': { 
            transform: 'translate(40px, -30px) scale(1.05)',
          },
          '66%': { 
            transform: 'translate(-30px, 20px) scale(0.95)',
          },
        },
        'morph-gentle': {
          '0%, 100%': { 
            transform: 'translate(0, 0) scale(1)',
            borderRadius: '50%',
          },
          '25%': { 
            transform: 'translate(30px, -40px) scale(1.1)',
            borderRadius: '60% 40% 30% 70%',
          },
          '50%': { 
            transform: 'translate(-40px, 30px) scale(0.9)',
            borderRadius: '30% 60% 70% 40%',
          },
          '75%': { 
            transform: 'translate(20px, 25px) scale(1.05)',
            borderRadius: '40% 30% 60% 70%',
          },
        },
      },
      backdropBlur: {
        'subtle': '4px',
        'soft': '12px',
        'medium': '20px',
        'strong': '32px',
        'glass': '40px',
      },
    },
  },
  plugins: [],
};