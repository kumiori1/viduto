// ===== דוגמה לאינטגרציה עם React =====
// קובץ זה מראה איך לשלב את תפריט המבורגר עם React

// דוגמה לשימוש בתוך קומפוננט React
const IntegrationExample = () => {
    const { user, signOut } = useAuth();
    const { credits } = useVideoCredits();
    const { chats, setActiveChat } = useVideoChat();
    const [showPricing, setShowPricing] = useState(false);

    // אינטגרציה עם תפריט המבורגר
    useEffect(() => {
        // הגדרת callbacks לתפריט המבורגר
        const reactCallbacks = {
            onNewProject: () => {
                console.log('New project from hamburger menu');
                window.location.href = '/';
            },
            
            onNavigateToProducts: () => {
                console.log('Navigate to products from hamburger menu');
                window.location.href = '/dashboard/products';
            },
            
            onNavigateToBrand: () => {
                console.log('Navigate to brand from hamburger menu');
                window.location.href = '/dashboard/brand';
            },
            
            onNavigateToSettings: () => {
                console.log('Navigate to settings from hamburger menu');
                window.location.href = '/dashboard/settings';
            },
            
            onOpenSubscriptionModal: () => {
                console.log('Open subscription modal from hamburger menu');
                setShowPricing(true);
            },
            
            onLogout: () => {
                console.log('Logout from hamburger menu');
                if (confirm('האם אתה בטוח שברצונך להתנתק?')) {
                    signOut();
                }
            },
            
            onChatSelect: (chatTitle) => {
                console.log('Chat selected from hamburger menu:', chatTitle);
                const selectedChat = chats.find(chat => chat.title === chatTitle);
                if (selectedChat) {
                    setActiveChat(selectedChat);
                }
            }
        };
        
        // אינטגרציה עם התפריט
        if (window.integrateWithReact) {
            window.integrateWithReact(reactCallbacks);
        }
        
        // סנכרון state עם התפריט
        if (window.syncHamburgerWithReactState) {
            window.syncHamburgerWithReactState({
                user,
                credits,
                chats
            });
        }
    }, [user, credits, chats, signOut, setActiveChat, setShowPricing]);

    // עדכון התפריט כשה-state משתנה
    useEffect(() => {
        if (window.syncHamburgerWithReactState) {
            window.syncHamburgerWithReactState({
                user,
                credits,
                chats
            });
        }
    }, [user, credits, chats]);

    return (
        <div>
            {/* התוכן שלך כאן */}
        </div>
    );
};

// ===== פונקציות עזר נוספות =====

// פונקציה לעדכון מספר הקרדיטים בזמן אמת
window.updateMenuCredits = (newCreditsAmount) => {
    if (window.hamburgerMenu) {
        window.hamburgerMenu.updateCredits(newCreditsAmount);
    }
};

// פונקציה להוספת צ'אט חדש לרשימה
window.addChatToMenu = (newChat) => {
    if (window.hamburgerMenu) {
        const currentChats = Array.from(document.querySelectorAll('.chat-item')).map(item => ({
            title: item.querySelector('.chat-title').textContent,
            status: item.querySelector('.status-icon').className.includes('completed') ? 'completed' : 'generating'
        }));
        
        const updatedChats = [newChat, ...currentChats];
        window.hamburgerMenu.updateChatsList(updatedChats);
    }
};

// פונקציה לעדכון סטטוס צ'אט קיים
window.updateChatStatus = (chatTitle, newStatus) => {
    const chatItems = document.querySelectorAll('.chat-item');
    chatItems.forEach(item => {
        const titleElement = item.querySelector('.chat-title');
        if (titleElement && titleElement.textContent === chatTitle) {
            const statusIcon = item.querySelector('.status-icon');
            const statusText = item.querySelector('.status-text');
            
            if (statusIcon) {
                statusIcon.className = `status-icon status-${newStatus}`;
            }
            
            if (statusText) {
                statusText.textContent = window.hamburgerMenu.getStatusText(newStatus);
            }
        }
    });
};