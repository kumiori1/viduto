// ===== HAMBURGER MENU JAVASCRIPT =====
// פונקציונליות מלאה לתפריט המבורגר

class HamburgerMenu {
    constructor() {
        this.hamburgerBtn = document.getElementById('hamburgerBtn');
        this.hamburgerMenu = document.getElementById('hamburgerMenu');
        this.menuBackdrop = document.getElementById('menuBackdrop');
        this.closeBtn = document.getElementById('closeBtn');
        this.newProjectBtn = document.getElementById('newProjectBtn');
        this.menuItems = document.querySelectorAll('.menu-item');
        this.chatItems = document.querySelectorAll('.chat-item');
        
        this.isOpen = false;
        
        this.init();
    }
    
    init() {
        // Event listeners לפתיחה וסגירה
        this.hamburgerBtn?.addEventListener('click', () => this.toggleMenu());
        this.closeBtn?.addEventListener('click', () => this.closeMenu());
        this.menuBackdrop?.addEventListener('click', () => this.closeMenu());
        
        // Event listener למקש Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isOpen) {
                this.closeMenu();
            }
        });
        
        // Event listeners לפריטי התפריט
        this.setupMenuItemListeners();
        this.setupChatItemListeners();
        
        // Event listener לכפתור פרויקט חדש
        this.newProjectBtn?.addEventListener('click', () => this.handleNewProject());
        
        console.log('🟢 Hamburger Menu initialized successfully');
    }
    
    toggleMenu() {
        if (this.isOpen) {
            this.closeMenu();
        } else {
            this.openMenu();
        }
    }
    
    openMenu() {
        this.isOpen = true;
        this.hamburgerMenu?.classList.add('active');
        this.hamburgerBtn?.classList.add('active');
        
        // מניעת גלילה של הגוף כשהתפריט פתוח
        document.body.style.overflow = 'hidden';
        
        console.log('🔵 Menu opened');
        
        // Focus על התפריט לנגישות
        this.hamburgerMenu?.focus();
    }
    
    closeMenu() {
        this.isOpen = false;
        this.hamburgerMenu?.classList.remove('active');
        this.hamburgerBtn?.classList.remove('active');
        
        // החזרת גלילה לגוף
        document.body.style.overflow = '';
        
        console.log('🔵 Menu closed');
        
        // החזרת focus לכפתור המבורגר
        this.hamburgerBtn?.focus();
    }
    
    setupMenuItemListeners() {
        this.menuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                const action = item.getAttribute('data-action');
                this.handleMenuAction(action);
            });
        });
    }
    
    setupChatItemListeners() {
        this.chatItems.forEach(item => {
            item.addEventListener('click', (e) => {
                // הסרת active מכל הצ'אטים
                this.chatItems.forEach(chat => chat.classList.remove('active'));
                
                // הוספת active לצ'אט שנלחץ
                item.classList.add('active');
                
                // כאן תוכל להוסיף לוגיקה לפתיחת הצ'אט
                const chatTitle = item.querySelector('.chat-title')?.textContent;
                console.log('🔵 Chat selected:', chatTitle);
                
                // סגירת התפריט אחרי בחירת צ'אט
                this.closeMenu();
                
                // כאן תוכל להוסיף ניווט לצ'אט הספציפי
                this.navigateToChat(chatTitle);
            });
        });
    }
    
    handleMenuAction(action) {
        console.log('🔵 Menu action:', action);
        
        switch (action) {
            case 'products':
                this.navigateToProducts();
                break;
            case 'brand':
                this.navigateToBrand();
                break;
            case 'subscription':
                this.openSubscriptionModal();
                break;
            case 'settings':
                this.navigateToSettings();
                break;
            case 'logout':
                this.handleLogout();
                break;
            default:
                console.warn('Unknown menu action:', action);
        }
        
        // סגירת התפריט אחרי פעולה
        this.closeMenu();
    }
    
    handleNewProject() {
        console.log('🔵 New project clicked');
        
        // כאן תוכל להוסיף לוגיקה ליצירת פרויקט חדש
        // לדוגמה: ניווט לדף הבית או פתיחת מודל
        
        this.closeMenu();
        
        // דוגמה לניווט
        window.location.href = '/';
    }
    
    navigateToProducts() {
        console.log('🔵 Navigating to products');
        window.location.href = '/dashboard/products';
    }
    
    navigateToBrand() {
        console.log('🔵 Navigating to brand guidelines');
        window.location.href = '/dashboard/brand';
    }
    
    navigateToSettings() {
        console.log('🔵 Navigating to settings');
        window.location.href = '/dashboard/settings';
    }
    
    navigateToChat(chatTitle) {
        console.log('🔵 Navigating to chat:', chatTitle);
        // כאן תוכל להוסיף לוגיקה לניווט לצ'אט ספציפי
        // לדוגמה: window.location.href = `/chat/${chatId}`;
    }
    
    openSubscriptionModal() {
        console.log('🔵 Opening subscription modal');
        
        // כאן תוכל להוסיף לוגיקה לפתיחת מודל מנוי
        // לדוגמה: פתיחת מודל או ניווט לדף מנוי
        
        // דוגמה לפתיחת מודל (אם יש לך מודל במערכת)
        if (typeof window.showPricingModal === 'function') {
            window.showPricingModal();
        } else {
            // fallback - ניווט לדף תמחור
            window.location.href = '/pricing';
        }
    }
    
    handleLogout() {
        console.log('🔵 Logout clicked');
        
        // אישור יציאה
        if (confirm('האם אתה בטוח שברצונך להתנתק?')) {
            // כאן תוכל להוסיף לוגיקה ליציאה
            // לדוגמה: קריאה לפונקציית logout
            
            if (typeof window.signOut === 'function') {
                window.signOut();
            } else {
                // fallback - ניווט לדף הבית
                window.location.href = '/';
            }
            
            console.log('🔵 User logged out');
        }
    }
    
    // פונקציות עזר
    updateUserInfo(email, credits) {
        const emailElement = document.querySelector('.user-email');
        const creditsElement = document.querySelector('.user-credits');
        
        if (emailElement) emailElement.textContent = email;
        if (creditsElement) creditsElement.textContent = `${credits} credits`;
    }
    
    updateChatsList(chats) {
        const chatsList = document.querySelector('.chats-list');
        const noChats = document.querySelector('.no-chats');
        
        if (!chatsList) return;
        
        // ניקוי הרשימה הקיימת
        const existingChats = chatsList.querySelectorAll('.chat-item');
        existingChats.forEach(chat => chat.remove());
        
        if (chats.length === 0) {
            // הצגת הודעת "אין צ'אטים"
            if (noChats) noChats.style.display = 'block';
        } else {
            // הסתרת הודעת "אין צ'אטים"
            if (noChats) noChats.style.display = 'none';
            
            // הוספת הצ'אטים החדשים
            chats.forEach(chat => {
                const chatElement = this.createChatElement(chat);
                chatsList.appendChild(chatElement);
            });
            
            // הוספת event listeners לצ'אטים החדשים
            this.setupChatItemListeners();
        }
    }
    
    createChatElement(chat) {
        const chatElement = document.createElement('button');
        chatElement.className = 'chat-item';
        chatElement.innerHTML = `
            <div class="chat-header">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polygon points="23 7 16 12 23 17 23 7"></polygon>
                    <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
                </svg>
                <span class="chat-title">${chat.title}</span>
            </div>
            <div class="chat-status">
                <div class="status-icon status-${chat.status}"></div>
                <span class="status-text">${this.getStatusText(chat.status)}</span>
            </div>
        `;
        
        return chatElement;
    }
    
    getStatusText(status) {
        const statusMap = {
            'briefing': 'Briefing',
            'approved': 'Approved',
            'generating': 'Generating',
            'completed': 'Completed',
            'revision': 'Revision'
        };
        
        return statusMap[status] || 'Unknown';
    }
    
    // פונקציה לעדכון מספר הקרדיטים בזמן אמת
    updateCredits(newCreditsAmount) {
        this.updateUserInfo(
            document.querySelector('.user-email')?.textContent || '',
            newCreditsAmount
        );
    }
}

// ===== INITIALIZATION =====
// אתחול התפריט כשהדף נטען
document.addEventListener('DOMContentLoaded', () => {
    console.log('🔵 DOM loaded, initializing hamburger menu...');
    
    // יצירת instance של התפריט
    window.hamburgerMenu = new HamburgerMenu();
    
    // דוגמה לעדכון פרטי משתמש (תוכל להחליף בנתונים אמיתיים)
    setTimeout(() => {
        window.hamburgerMenu.updateUserInfo('user@example.com', 4666);
        
        // דוגמה לעדכון רשימת צ'אטים
        const sampleChats = [
            { title: 'Luxury Perfume Ad', status: 'completed' },
            { title: 'Tech Product Demo', status: 'generating' },
            { title: 'Fashion Showcase', status: 'briefing' }
        ];
        
        window.hamburgerMenu.updateChatsList(sampleChats);
    }, 100);
});

// ===== GLOBAL FUNCTIONS =====
// פונקציות שיכולות להיקרא מחוץ לקובץ

// פתיחת התפריט מבחוץ
window.openHamburgerMenu = () => {
    if (window.hamburgerMenu) {
        window.hamburgerMenu.openMenu();
    }
};

// סגירת התפריט מבחוץ
window.closeHamburgerMenu = () => {
    if (window.hamburgerMenu) {
        window.hamburgerMenu.closeMenu();
    }
};

// עדכון פרטי משתמש מבחוץ
window.updateHamburgerUserInfo = (email, credits) => {
    if (window.hamburgerMenu) {
        window.hamburgerMenu.updateUserInfo(email, credits);
    }
};

// עדכון רשימת צ'אטים מבחוץ
window.updateHamburgerChats = (chats) => {
    if (window.hamburgerMenu) {
        window.hamburgerMenu.updateChatsList(chats);
    }
};

// ===== INTEGRATION HELPERS =====
// פונקציות עזר לאינטגרציה עם מערכות קיימות

// אינטגרציה עם React (אם נדרש)
window.integrateWithReact = (reactCallbacks) => {
    if (window.hamburgerMenu && reactCallbacks) {
        // עדכון callbacks לפעולות שונות
        if (reactCallbacks.onNewProject) {
            window.hamburgerMenu.handleNewProject = reactCallbacks.onNewProject;
        }
        
        if (reactCallbacks.onNavigateToProducts) {
            window.hamburgerMenu.navigateToProducts = reactCallbacks.onNavigateToProducts;
        }
        
        if (reactCallbacks.onNavigateToBrand) {
            window.hamburgerMenu.navigateToBrand = reactCallbacks.onNavigateToBrand;
        }
        
        if (reactCallbacks.onNavigateToSettings) {
            window.hamburgerMenu.navigateToSettings = reactCallbacks.onNavigateToSettings;
        }
        
        if (reactCallbacks.onOpenSubscriptionModal) {
            window.hamburgerMenu.openSubscriptionModal = reactCallbacks.onOpenSubscriptionModal;
        }
        
        if (reactCallbacks.onLogout) {
            window.hamburgerMenu.handleLogout = reactCallbacks.onLogout;
        }
        
        if (reactCallbacks.onChatSelect) {
            window.hamburgerMenu.navigateToChat = reactCallbacks.onChatSelect;
        }
        
        console.log('🟢 React integration completed');
    }
};

// פונקציה לסנכרון עם state של React
window.syncHamburgerWithReactState = (state) => {
    if (window.hamburgerMenu && state) {
        // עדכון פרטי משתמש
        if (state.user && state.credits) {
            window.hamburgerMenu.updateUserInfo(
                state.user.email, 
                state.credits.available_credits
            );
        }
        
        // עדכון רשימת צ'אטים
        if (state.chats) {
            window.hamburgerMenu.updateChatsList(state.chats);
        }
        
        console.log('🟢 Hamburger menu synced with React state');
    }
};