import { useEffect } from 'react';
import { useAuth } from './useAuth';
import { facebookPixel } from '../utils/facebookPixel';

export const useFacebookPixel = () => {
  const { user } = useAuth();

  // Track page views automatically
  useEffect(() => {
    facebookPixel.trackPageView();
  }, []);

  const trackPurchase = (params: {
    value: number;
    currency?: string;
    order_id?: string;
    content_ids?: string[];
    content_name?: string;
    num_items?: number;
  }) => {
    return facebookPixel.trackPurchase(params.value, params.currency, {
      order_id: params.order_id,
      content_ids: params.content_ids,
      content_name: params.content_name,
      num_items: params.num_items,
    });
  };

  const trackLogin = () => {
    return facebookPixel.trackLogin({
      email: user?.email,
      external_id: user?.id,
    });
  };

  const trackRegistration = (params?: {
    registration_method?: string;
  }) => {
    return facebookPixel.trackCompleteRegistration({
      email: user?.email,
      external_id: user?.id,
      registration_method: params?.registration_method || 'email',
    });
  };

  const trackVideoRequest = (params: {
    video_title: string;
    target_platform: string;
  }) => {
    return facebookPixel.trackLead({
      content_name: params.video_title,
      content_category: 'video_request',
      delivery_category: params.target_platform,
      external_id: user?.id,
    });
  };

  const trackInitiateCheckout = (params: {
    value: number;
    currency?: string;
    content_ids?: string[];
    content_name?: string;
  }) => {
    return facebookPixel.trackInitiateCheckout(params.value, params.currency, {
      content_ids: params.content_ids,
      content_name: params.content_name,
    });
  };

  const trackViewContent = (params?: {
    content_name?: string;
    content_category?: string;
    content_ids?: string[];
  }) => {
    return facebookPixel.trackViewContent(params);
  };

  return {
    trackPurchase,
    trackLogin,
    trackRegistration,
    trackVideoRequest,
    trackInitiateCheckout,
    trackViewContent,
    trackPageView: facebookPixel.trackPageView,
    trackCustom: facebookPixel.trackCustom,
  };
};