import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';
import { RealtimePostgresChangesPayload } from '@supabase/supabase-js';

export interface VideoRequest {
  id: string;
  user_id: string;
  title: string;
  brief_description: string;
  target_platform: string;
  music_style: string;
  voiceover: string;
  language: string;
  additional_requests: string;
  images_count: number;
  image_urls: string[];
  image_names: string[];
  status: 'submitted' | 'in-progress' | 'ready' | 'revision_requested';
  request_date: string;
  expected_delivery: string | null;
  video_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateVideoRequestData {
  title: string;
  brief_description: string;
  target_platform: string;
  music_style: string;
  voiceover: string;
  language: string;
  additional_requests: string;
  images_count: number;
  image_urls: string[];
  image_names: string[];
  expected_delivery?: string;
}

export function useVideoRequests() {
  const { user } = useAuth();
  const [videoRequests, setVideoRequests] = useState<VideoRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setVideoRequests([]);
      setLoading(false);
      return;
    }

    const fetchAndSubscribe = async () => {
      setLoading(true);
      setError(null);

      try {
        console.log('Fetching video requests for user:', user.id);

        // 1. Initial data fetch
        const { data, error: fetchError } = await supabase
          .from('user_video_requests')
          .select('*')
          .eq('user_id', user.id)
          .order('request_date', { ascending: false });

        if (fetchError) {
          console.error('Supabase fetch error:', fetchError);
          throw fetchError;
        }

        console.log('Video requests data received:', data);
        setVideoRequests(data || []);
      } catch (err) {
        console.error('Error fetching video requests:', err);
        const errorMessage = err instanceof Error ? err.message : 'Failed to fetch video requests';
        setError(errorMessage);
      } finally {
        setLoading(false);
      }

      // 2. Set up Realtime subscription
      console.log('Setting up Realtime subscription for user:', user.id);
      
      const subscription = supabase
        .channel(`user_video_requests:${user.id}`) // Unique channel name per user
        .on<VideoRequest>(
          'postgres_changes',
          {
            event: '*', // Listen for all events (INSERT, UPDATE, DELETE)
            schema: 'public',
            table: 'user_video_requests',
            filter: `user_id=eq.${user.id}`, // Filter for current user's requests
          },
          (payload: RealtimePostgresChangesPayload<VideoRequest>) => {
            console.log('Realtime change received!', payload);

            if (payload.eventType === 'INSERT') {
              console.log('New video request added:', payload.new);
              setVideoRequests((prev) => [payload.new as VideoRequest, ...prev]);
            } else if (payload.eventType === 'UPDATE') {
              console.log('Video request updated:', payload.new);
              setVideoRequests((prev) =>
                prev.map((req) =>
                  req.id === (payload.new as VideoRequest).id ? (payload.new as VideoRequest) : req
                )
              );
            } else if (payload.eventType === 'DELETE') {
              console.log('Video request deleted:', payload.old);
              setVideoRequests((prev) =>
                prev.filter((req) => req.id !== (payload.old as VideoRequest).id)
              );
            }
          }
        )
        .subscribe((status) => {
          console.log('Realtime subscription status:', status);
        });

      // Cleanup function for the useEffect hook
      return () => {
        console.log('Unsubscribing from Realtime channel');
        supabase.removeChannel(subscription);
      };
    };

    const cleanup = fetchAndSubscribe();
    
    // Return cleanup function
    return () => {
      cleanup.then((cleanupFn) => {
        if (cleanupFn) cleanupFn();
      });
    };
  }, [user]); // Re-run effect if user changes

  const refetch = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      console.log('Manually refetching video requests for user:', user.id);

      const { data, error: fetchError } = await supabase
        .from('user_video_requests')
        .select('*')
        .eq('user_id', user.id)
        .order('request_date', { ascending: false });

      if (fetchError) {
        console.error('Supabase refetch error:', fetchError);
        throw fetchError;
      }

      console.log('Video requests refetch data received:', data);
      setVideoRequests(data || []);
    } catch (err) {
      console.error('Error refetching video requests:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to refetch video requests';
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const createVideoRequest = async (requestData: CreateVideoRequestData): Promise<VideoRequest | null> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      // Generate unique ID for the request
      const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Calculate expected delivery (3 business days from now)
      const expectedDelivery = requestData.expected_delivery || 
        new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString();

      const newRequest = {
        id: requestId,
        user_id: user.id,
        title: requestData.title,
        brief_description: requestData.brief_description,
        target_platform: requestData.target_platform,
        music_style: requestData.music_style || '',
        voiceover: requestData.voiceover,
        language: requestData.language,
        additional_requests: requestData.additional_requests || '',
        images_count: requestData.images_count,
        image_urls: requestData.image_urls,
        image_names: requestData.image_names,
        status: 'submitted' as const,
        expected_delivery: expectedDelivery,
        video_url: null
      };

      console.log('Creating video request:', newRequest);

      const { data, error } = await supabase
        .from('user_video_requests')
        .insert(newRequest)
        .select()
        .single();

      if (error) {
        console.error('Error creating video request:', error);
        throw error;
      }

      console.log('Video request created successfully:', data);

      // Realtime will handle updating the local state automatically
      return data;
    } catch (err) {
      console.error('Error in createVideoRequest:', err);
      throw err;
    }
  };

  const updateVideoRequest = async (id: string, updates: Partial<VideoRequest>): Promise<VideoRequest | null> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      console.log('Updating video request:', id, updates);

      const { data, error } = await supabase
        .from('user_video_requests')
        .update(updates)
        .eq('id', id)
        .eq('user_id', user.id) // Ensure user can only update their own requests
        .select()
        .single();

      if (error) {
        console.error('Error updating video request:', error);
        throw error;
      }

      console.log('Video request updated successfully:', data);

      // Realtime will handle updating the local state automatically
      return data;
    } catch (err) {
      console.error('Error in updateVideoRequest:', err);
      throw err;
    }
  };

  const deleteVideoRequest = async (id: string): Promise<void> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      console.log('Deleting video request:', id);

      const { error } = await supabase
        .from('user_video_requests')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id); // Ensure user can only delete their own requests

      if (error) {
        console.error('Error deleting video request:', error);
        throw error;
      }

      console.log('Video request deleted successfully');

      // Realtime will handle updating the local state automatically
    } catch (err) {
      console.error('Error in deleteVideoRequest:', err);
      throw err;
    }
  };

  return {
    videoRequests,
    loading,
    error,
    refetch,
    createVideoRequest,
    updateVideoRequest,
    deleteVideoRequest
  };
}