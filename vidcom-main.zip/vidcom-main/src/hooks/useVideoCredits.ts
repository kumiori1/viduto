import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';

export interface UserVideoCredits {
  id: number;
  user_id: string;
  available_credits: number;
  total_purchased: number;
  total_used: number;
  created_at: string;
  updated_at: string;
}

export function useVideoCredits() {
  const { user } = useAuth();
  const [credits, setCredits] = useState<UserVideoCredits | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCredits = async () => {
    if (!user) {
      setCredits(null);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      console.log('🔵 fetchCredits: Starting fetch for user:', user.id);
      
      // Check if Supabase is configured
      if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
        console.log('🔴 fetchCredits: Supabase not configured, using demo data');
        setCredits({
          id: 1,
          user_id: user.id,
          available_credits: 150,
          total_purchased: 150,
          total_used: 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
        setLoading(false);
        return;
      }

      const { data, error: fetchError } = await supabase
        .from('user_video_credits')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (fetchError) {
        if (fetchError.code === 'PGRST116') {
          // No credits record exists, create one
          console.log('🔵 fetchCredits: No credits record found, creating one');
          const { data: newCredits, error: insertError } = await supabase
            .from('user_video_credits')
            .insert({
              user_id: user.id,
              available_credits: 0,
              total_purchased: 0,
              total_used: 0
            })
            .select()
            .single();

          if (insertError) {
            console.warn('🔴 fetchCredits: Error creating credits record:', insertError);
            throw insertError;
          }

          setCredits(newCredits);
        } else {
          console.warn('🔴 fetchCredits: Database error:', fetchError);
          throw fetchError;
        }
      } else {
        console.log('🟢 fetchCredits: Success:', data);
        setCredits(data);
      }
    } catch (err) {
      console.warn('🔴 fetchCredits: Error:', err);
      
      // Fallback to demo data on any error
      console.log('🔵 fetchCredits: Using demo data as fallback');
      setCredits({
        id: 1,
        user_id: user?.id || 'demo',
        available_credits: 150,
        total_purchased: 150,
        total_used: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });
      setError(null); // Don't show error in demo mode
    } finally {
      setLoading(false);
    }
  };

  const useCredit = async (amount: number = 1): Promise<boolean> => {
    if (!user || !credits) {
      console.log('🔴 useCredit: No user or credits available');
      return false;
    }

    if (credits.available_credits < amount) {
      console.log('🔴 useCredit: Insufficient credits');
      setError('Insufficient credits');
      return false;
    }

    try {
      setLoading(true);
      setError(null);
      
      console.log('🔵 useCredit: Deducting credits:', amount);
      
      // Check if Supabase is configured
      if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
        console.log('🔵 useCredit: Demo mode - simulating credit usage');
        setCredits(prev => prev ? {
          ...prev,
          available_credits: prev.available_credits - amount,
          total_used: prev.total_used + amount
        } : null);
        setLoading(false);
        return true;
      }

      // Demo mode - simulate credit deduction
      const updatedCredits = {
        ...credits,
        available_credits: credits.available_credits - amount,
        total_used: credits.total_used + amount,
        updated_at: new Date().toISOString()
      };

      setCredits(updatedCredits);
      console.log('🟢 useCredit: Demo credits updated successfully');
      return true;
    } catch (err) {
      console.error('🔴 useCredit: Error:', err);
      setError('Failed to use credits');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const refetch = () => {
    fetchCredits();
  };

  useEffect(() => {
    if (user) {
      console.log('🔵 useVideoCredits: User detected, fetching credits');
      fetchCredits();
    } else {
      console.log('🔵 useVideoCredits: No user, clearing credits');
      setCredits(null);
      setError(null);
    }
  }, [user]);

  return {
    credits,
    loading,
    error,
    refetch,
    useCredits: useCredit // Alias for backward compatibility
  };
}