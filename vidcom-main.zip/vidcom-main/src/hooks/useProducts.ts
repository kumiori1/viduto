import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { isSupabaseConfigured } from '../lib/supabase';
import { useAuth } from './useAuth';
import { RealtimePostgresChangesPayload } from '@supabase/supabase-js';

export interface Product {
  id: string;
  user_id: string;
  name: string;
  description: string;
  reference_tag: string;
  image_urls: string[];
  image_names: string[];
  metadata: any;
  created_at: string;
  updated_at: string;
}

export interface CreateProductData {
  name: string;
  description: string;
  reference_tag: string;
  image_urls: string[];
  image_names: string[];
  metadata?: any;
}

export function useProducts() {
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setProducts([]);
      setLoading(false);
      return;
    }

    fetchProducts();
    setupRealtimeSubscription();

    return () => {
      cleanupRealtimeSubscription();
    };
  }, [user]);

  const [realtimeSubscription, setRealtimeSubscription] = useState<any>(null);

  const setupRealtimeSubscription = () => {
    cleanupRealtimeSubscription();
    
    if (!user) return;

    console.log('Setting up realtime subscription for products, user:', user.id);
    
    const subscription = supabase
      .channel(`products_${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'products',
          filter: `user_id=eq.${user.id}`,
        },
        (payload: RealtimePostgresChangesPayload<Product>) => {
          console.log('Realtime product change received:', payload);
          
          if (payload.eventType === 'INSERT') {
            setProducts(prev => [payload.new as Product, ...prev]);
          } else if (payload.eventType === 'UPDATE') {
            setProducts(prev =>
              prev.map(product =>
                product.id === (payload.new as Product).id ? (payload.new as Product) : product
              )
            );
          } else if (payload.eventType === 'DELETE') {
            setProducts(prev =>
              prev.filter(product => product.id !== (payload.old as Product).id)
            );
          }
        }
      )
      .subscribe((status) => {
        console.log('Products realtime subscription status:', status);
      });

    setRealtimeSubscription(subscription);
  };

  const cleanupRealtimeSubscription = () => {
    if (realtimeSubscription) {
      supabase.removeChannel(realtimeSubscription);
      setRealtimeSubscription(null);
    }
  };

  const fetchProducts = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('products')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (fetchError) {
        throw fetchError;
      }

      setProducts(data || []);
    } catch (err) {
      console.error('Error fetching products:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch products');
    } finally {
      setLoading(false);
    }
  };

  const createProduct = async (productData: CreateProductData): Promise<Product | null> => {
    try {
      // In demo mode, create mock product
      const newProduct: Product = {
        id: `product_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        user_id: 'demo-user-123',
        name: productData.name,
        description: productData.description || '',
        reference_tag: productData.reference_tag,
        image_urls: productData.image_urls,
        image_names: productData.image_names,
        metadata: productData.metadata || {},
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      // Update local state
      setProducts(prev => [newProduct, ...prev]);

      return newProduct;
    } catch (err) {
      console.error('Error creating product:', err);
      throw err;
    }
  };

  const updateProduct = async (id: string, updates: Partial<Product>): Promise<Product | null> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      const { data, error } = await supabase
        .from('products')
        .update(updates)
        .eq('id', id)
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) {
        throw error;
      }

      return data;
    } catch (err) {
      console.error('Error updating product:', err);
      throw err;
    }
  };

  const deleteProduct = async (id: string): Promise<void> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        throw error;
      }
    } catch (err) {
      console.error('Error deleting product:', err);
      throw err;
    }
  };

  return {
    products,
    loading,
    error,
    refetch: fetchProducts,
    createProduct,
    updateProduct,
    deleteProduct,
    canCreateProduct: () => true, // Always allow creating products if user has credits
    getProductLimits: () => ({
      current: products.length,
      max: 999, // No limit - only credits matter
      canCreate: true
    })
  };
}