import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';

export interface BrandGuidelines {
  id: string;
  user_id: string;
  logo_url: string;
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  font_family: string;
  title_style: string;
  body_style: string;
  mood: string;
  pace: string;
  transitions: string;
  default_prompts: string[];
  style_preferences: any;
  created_at: string;
  updated_at: string;
}

export interface CreateBrandGuidelinesData {
  logo_url?: string;
  primary_color?: string;
  secondary_color?: string;
  accent_color?: string;
  font_family?: string;
  title_style?: string;
  body_style?: string;
  mood?: string;
  pace?: string;
  transitions?: string;
  default_prompts?: string[];
  style_preferences?: any;
}

export function useBrandGuidelines() {
  const { user } = useAuth();
  const [brandGuidelines, setBrandGuidelines] = useState<BrandGuidelines | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setBrandGuidelines(null);
      setLoading(false);
      return;
    }

    fetchBrandGuidelines();
  }, [user]);

  const fetchBrandGuidelines = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('brand_guidelines')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (fetchError) {
        throw fetchError;
      }

      setBrandGuidelines(data);
    } catch (err) {
      console.error('Error fetching brand guidelines:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch brand guidelines');
    } finally {
      setLoading(false);
    }
  };

  const createOrUpdateBrandGuidelines = async (data: CreateBrandGuidelinesData): Promise<BrandGuidelines | null> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      const guidelinesData = {
        user_id: user.id,
        ...data,
      };

      const { data: result, error } = await supabase
        .from('brand_guidelines')
        .upsert(guidelinesData, {
          onConflict: 'user_id',
        })
        .select()
        .single();

      if (error) {
        throw error;
      }

      setBrandGuidelines(result);
      return result;
    } catch (err) {
      console.error('Error creating/updating brand guidelines:', err);
      throw err;
    }
  };

  const deleteBrandGuidelines = async (): Promise<void> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      const { error } = await supabase
        .from('brand_guidelines')
        .delete()
        .eq('user_id', user.id);

      if (error) {
        throw error;
      }

      setBrandGuidelines(null);
    } catch (err) {
      console.error('Error deleting brand guidelines:', err);
      throw err;
    }
  };

  return {
    brandGuidelines,
    loading,
    error,
    refetch: fetchBrandGuidelines,
    createOrUpdate: createOrUpdateBrandGuidelines,
    delete: deleteBrandGuidelines,
  };
}