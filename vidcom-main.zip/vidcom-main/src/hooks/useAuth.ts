import { useState, useEffect } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Handle session not found events
    const handleSessionNotFound = () => {
      console.log('Session expired, signing out...');
      if (import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY) {
        supabase.auth.signOut();
      }
    };

    window.addEventListener('supabase:session_not_found', handleSessionNotFound);

    // Get initial session
    if (import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        setUser(session?.user ?? null);
        setLoading(false);
      });
    } else {
      console.log('Supabase not configured, running in demo mode');
      setUser(null);
      setLoading(false);
    }

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => {
      subscription.unsubscribe();
      window.removeEventListener('supabase:session_not_found', handleSessionNotFound);
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    
    // Ensure user exists in users table after successful login
    if (data.user && !error) {
      try {
        await supabase.rpc('sync_user_on_login', {
          user_id: data.user.id,
          user_email: data.user.email
        });
      } catch (syncError) {
        console.log('User sync error (non-critical):', syncError);
      }
    }
    
    // Handle pending request after successful login
    if (data.user && !error) {
      // The pending request will be handled by the HomePage component
      console.log('User signed in successfully');
    }
    
    return { data, error };
  };

  const signUp = async (email: string, password: string) => {
    // Check if Supabase is configured
    if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
      console.error('Supabase not configured for signup');
      return { 
        data: null, 
        error: { message: 'Supabase not configured. Please set up environment variables.' } 
      };
    }

    console.log('🔵 Starting signup process for:', email);
    
    try {
      // Try to sign up the user with Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: undefined,
          data: {
            email: email
          }
        },
      });
      
      console.log('🔵 Supabase signup response:', { 
        hasUser: !!data.user, 
        hasSession: !!data.session,
        errorCode: error?.message,
        userEmail: data.user?.email 
      });

      // If signup successful, wait for triggers to complete
      if (!error && data.user) {
        console.log('🟢 User created successfully:', data.user.email);
        
        // Wait for database triggers to complete
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Verify setup completed
        try {
          const { data: creditsData } = await supabase
            .from('user_video_credits')
            .select('available_credits')
            .eq('user_id', data.user.id)
            .single();
          
          if (creditsData) {
            console.log('🟢 Credits setup verified:', creditsData.available_credits);
          } else {
            console.log('🟡 Credits not found, will be created on first login');
          }
        } catch (verifyError) {
          console.log('🟡 Credits verification failed, will be created on first login');
        }
        
        return { data, error: null };
      }
      
      // Handle any signup errors
      if (error) {
        console.error('🔴 Signup failed:', error);
        return { data, error };
      }
      
      return { data, error };
    } catch (networkError) {
      console.error('🔴 Network error during signup:', networkError);
      return {
        data: null,
        error: { 
          message: 'Network error. Please check your connection and try again.' 
        }
      };
    }
  };

  const signOut = async () => {
    // Check if user session is valid before attempting logout
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    // If no user or there's an error (401/403), session is already invalid
    if (!user || userError) {
      return { error: null };
    }
    
    try {
      const { error } = await supabase.auth.signOut();
      
      // Handle session_not_found error gracefully - user is already logged out
      if (error && error.message?.includes('session_not_found')) {
        return { error: null };
      }
      
      return { error };
    } catch (error) {
      // Catch any unexpected errors or promise rejections from Supabase client
      if (error && typeof error === 'object' && 'message' in error && 
          (error as any).message?.includes('session_not_found')) {
        return { error: null };
      }
      
      // For other errors, return null to indicate successful logout
      // since the session is likely already invalid
      return { error: null };
    }
  };

  return {
    user,
    loading,
    signIn,
    signUp,
    signOut,
  };
}