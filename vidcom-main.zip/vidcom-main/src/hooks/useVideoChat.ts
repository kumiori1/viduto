import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';
import { ChatMessage, VideoChat, WorkflowState } from '../types/chat';
import { chatWorkflowService } from '../services/chatWorkflowService';
import { generateVideoTitle } from '../lib/anthropic';

export function useVideoChat() {
  const { user } = useAuth();
  const [chats, setChats] = useState<VideoChat[]>([]);
  const [activeChat, setActiveChat] = useState<VideoChat | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [realtimeSubscription, setRealtimeSubscription] = useState<any>(null);

  // Initialize when user changes
  useEffect(() => {
    if (user) {
      console.log('🔵 CHAT HOOK: Initializing for user:', user.id);
      initializeChat();
    } else {
      console.log('🔵 CHAT HOOK: No user, cleaning up');
      cleanup();
    }

    return cleanup;
  }, [user]);

  const initializeChat = async () => {
    try {
      await fetchChats();
      setupRealtimeSubscription();
    } catch (error) {
      console.error('🔴 CHAT HOOK: Initialization error:', error);
      setError('Failed to initialize chat');
    }
  };

  const cleanup = () => {
    cleanupRealtimeSubscription();
    setChats([]);
    setActiveChat(null);
    setError(null);
  };

  const fetchChats = async () => {
    if (!user) return;

    try {
      setLoading(true);
      console.log('🔵 FETCH: Getting chats for user:', user.id);
      
      const { data, error } = await supabase
        .from('video_chats')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('🔴 FETCH: Database error:', error);
        throw error;
      }
      
      // Ensure messages are arrays and workflow_state exists
      const processedChats = (data || []).map(chat => ({
        ...chat,
        messages: Array.isArray(chat.messages) ? chat.messages : [],
        workflow_state: chat.workflow_state || {
          phase: 'initial',
          brief_approved: false,
          revision_count: 0,
          last_action: 'created',
          context: {}
        }
      }));
      
      console.log('🟢 FETCH: Success, chats count:', processedChats.length);
      setChats(processedChats);
    } catch (err) {
      console.error('🔴 FETCH: Error:', err);
      setError('Failed to fetch chats');
    } finally {
      setLoading(false);
    }
  };

  const setupRealtimeSubscription = () => {
    if (!user) return;
    
    cleanupRealtimeSubscription();
    
    console.log('🔵 REALTIME: Setting up subscription for user:', user.id, 'at', new Date().toISOString());
    
    const subscription = supabase
      .channel(`video_chats_${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'video_chats',
          filter: `user_id=eq.${user.id}`,
        },
        (payload: any) => {
          handleRealtimeUpdate(payload);
        }
      )
      .subscribe((status, err) => {
        console.log('🔵 REALTIME: Subscription status:', status, 'at', new Date().toISOString());
        if (err) {
          console.error('🔴 REALTIME: Subscription error:', err);
        } else if (status === 'SUBSCRIBED') {
          console.log('🟢 REALTIME: Successfully subscribed to chat updates for user:', user.id);
        } else if (status === 'CHANNEL_ERROR') {
          console.error('🔴 REALTIME: Channel error, attempting reconnection...');
          // Attempt to reconnect after a delay
          setTimeout(() => {
            console.log('🔵 REALTIME: Attempting to reconnect...');
            setupRealtimeSubscription();
          }, 5000);
        }
      });

    setRealtimeSubscription(subscription);
  };

  const cleanupRealtimeSubscription = () => {
    if (realtimeSubscription) {
      console.log('🔵 REALTIME: Cleaning up subscription');
      supabase.removeChannel(realtimeSubscription);
      setRealtimeSubscription(null);
    }
  };

  const handleRealtimeUpdate = (payload: any) => {
    console.log('🟢 REALTIME UPDATE: Received payload:', {
      eventType: payload.eventType,
      chatId: payload.new?.id || payload.old?.id,
      status: payload.new?.status,
      messagesCount: payload.new?.messages?.length,
      timestamp: new Date().toISOString()
    });
    
    if (payload.eventType === 'INSERT') {
      const newChat = payload.new as VideoChat;
      console.log('🟢 REALTIME: New chat inserted:', newChat.id);
      
      setChats(prev => {
        const exists = prev.find(chat => chat.id === newChat.id);
        if (exists) return prev;
        return [newChat, ...prev];
      });
      
    } else if (payload.eventType === 'UPDATE') {
      const updatedChat = payload.new as VideoChat;
      console.log('🟢 REALTIME: Chat updated:', updatedChat.id);
      
      // Ensure messages is an array
      const safeMessages = Array.isArray(updatedChat.messages) ? updatedChat.messages : [];
      const safeWorkflowState = updatedChat.workflow_state || {
        phase: 'initial',
        brief_approved: false,
        revision_count: 0,
        last_action: 'updated',
        context: {}
      };
      
      const processedChat = { 
        ...updatedChat, 
        messages: safeMessages,
        workflow_state: safeWorkflowState
      };
      
      // Update chats list
      setChats(prev => prev.map(chat => 
        chat.id === updatedChat.id ? processedChat : chat
      ));
      
      // Update active chat if it's the same one
      setActiveChat(prev => {
        if (prev && prev.id === updatedChat.id) {
          console.log('🟢 REALTIME: Active chat updated with', safeMessages.length, 'messages');
          // Force scroll to bottom after realtime update
          setTimeout(() => {
            console.log('🔵 REALTIME: Triggering scroll after update');
            const messagesEnd = document.querySelector('[data-messages-end]');
            const messagesArea = document.querySelector('.mobile-messages-area');
            
            if (messagesEnd) {
              messagesEnd.scrollIntoView({ behavior: 'smooth', block: 'end' });
              console.log('🟢 REALTIME: Scrolled to messages end');
            }
            
            if (messagesArea) {
              messagesArea.scrollTop = messagesArea.scrollHeight;
              console.log('🟢 REALTIME: Scrolled messages area');
            }
          }, 200);
          return processedChat;
        }
        return prev;
      });
      
    } else if (payload.eventType === 'DELETE') {
      const deletedChat = payload.old as VideoChat;
      console.log('🟢 REALTIME: Chat deleted:', deletedChat.id);
      
      setChats(prev => prev.filter(chat => chat.id !== deletedChat.id));
      setActiveChat(prev => prev?.id === deletedChat.id ? null : prev);
    }
  };

  // Add message to chat with immediate local update
  const addMessageToChat = useCallback(async (chatId: string, message: ChatMessage): Promise<void> => {
    console.log('🔵 ADD MESSAGE: Adding to chat:', chatId, 'Type:', message.type);
    
    try {
      // Update local state immediately for instant feedback
      setActiveChat(prev => {
        if (prev && prev.id === chatId) {
          const updatedMessages = [...prev.messages, message];
          console.log('🟢 ADD MESSAGE: Local update applied, total messages:', updatedMessages.length);
          
          // Force scroll to bottom after local update with multiple methods
          setTimeout(() => {
            console.log('🔵 ADD MESSAGE: Triggering scroll after local update');
            const messagesEnd = document.querySelector('[data-messages-end]');
            const messagesArea = document.querySelector('.mobile-messages-area');
            
            if (messagesEnd) {
              messagesEnd.scrollIntoView({ behavior: 'smooth', block: 'end' });
              console.log('🟢 ADD MESSAGE: Scrolled to messages end');
            }
            
            if (messagesArea) {
              messagesArea.scrollTop = messagesArea.scrollHeight;
              console.log('🟢 ADD MESSAGE: Scrolled messages area');
            }
            
            // Force another scroll attempt
            setTimeout(() => {
              if (messagesArea) {
                messagesArea.scrollTop = messagesArea.scrollHeight;
              }
            }, 100);
          }, 100);
          
          return { ...prev, messages: updatedMessages, updated_at: new Date().toISOString() };
        }
        return prev;
      });

      // In demo mode, also update the chats list
      setChats(prev => prev.map(chat => 
        chat.id === chatId 
          ? { ...chat, messages: [...chat.messages, message], updated_at: new Date().toISOString() }
          : chat
      ));

      console.log('🟢 ADD MESSAGE: Successfully saved to database');
      
    } catch (error) {
      console.error('🔴 ADD MESSAGE: Error:', error);
      
      // Revert local state on error
      setActiveChat(prev => {
        if (prev && prev.id === chatId) {
          const revertedMessages = prev.messages.filter(msg => msg.id !== message.id);
          return { ...prev, messages: revertedMessages };
        }
        return prev;
      });
      
      throw error;
    }
  }, []);

  // Update chat status and workflow state
  const updateChatState = useCallback(async (
    chatId: string, 
    status: VideoChat['status'], 
    workflowUpdates?: Partial<WorkflowState>,
    additionalUpdates?: Partial<VideoChat>
  ): Promise<void> => {
    console.log('🔵 UPDATE STATE: Updating chat:', chatId, 'to status:', status);
    
    try {
      // Get current chat from local state
      const currentChat = activeChat?.id === chatId ? activeChat : chats.find(c => c.id === chatId);
      const currentWorkflowState = currentChat?.workflow_state || {
        phase: 'initial',
        brief_approved: false,
        revision_count: 0,
        last_action: 'created',
        context: {}
      };

      const updatedWorkflowState = { ...currentWorkflowState, ...workflowUpdates };

      const updates = {
        status,
        workflow_state: updatedWorkflowState,
        updated_at: new Date().toISOString(),
        ...additionalUpdates
      };

      // Update local state immediately
      setActiveChat(prev => {
        if (prev && prev.id === chatId) {
          return { ...prev, ...updates };
        }
        return prev;
      });

      // Update chats list
      setChats(prev => prev.map(chat => 
        chat.id === chatId ? { ...chat, ...updates } : chat
      ));

      console.log('🟢 UPDATE STATE: Successfully updated');
      
    } catch (error) {
      console.error('🔴 UPDATE STATE: Error:', error);
      throw error;
    }
  }, []);

  // Create new chat
  const createNewChat = async (description: string, productInfo: string): Promise<VideoChat | null> => {
    if (!user) return null;

    try {
      console.log('🔵 CREATE CHAT: Starting...');
      
      const title = await generateVideoTitle(description);
      const chatId = `chat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const initialWorkflowState: WorkflowState = {
        phase: 'initial',
        brief_approved: false,
        revision_count: 0,
        last_action: 'created',
        context: { original_description: description, product_info: productInfo }
      };

      const userMessage: ChatMessage = {
        id: `msg_${Date.now()}_user`,
        role: 'user',
        content: description,
        timestamp: new Date().toISOString(),
        type: 'text'
      };

      const thinkingMessage: ChatMessage = {
        id: `msg_${Date.now()}_thinking`,
        role: 'assistant',
        content: 'I\'m analyzing your request and creating a detailed video brief...',
        timestamp: new Date().toISOString(),
        type: 'loading'
      };

      const newChat: VideoChat = {
        id: chatId,
        user_id: user.id,
        title,
        description: productInfo,
        image_urls: [],
        image_names: [],
        status: 'briefing',
        messages: [userMessage, thinkingMessage],
        credits_used: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        workflow_state: initialWorkflowState
      };

      console.log('🔵 CREATE CHAT: Inserting to database...');
      
      // In demo mode, simulate database insert
      const data = { ...newChat };
      
      // Update local state immediately for demo mode
      setChats(prev => [data, ...prev]);
      setActiveChat(data);

      console.log('🟢 CREATE CHAT: Success, starting brief generation');
      
      // Start brief generation in background
      setTimeout(() => generateInitialBrief(data.id, description, productInfo), 500);
      
      return data;

    } catch (err) {
      console.error('🔴 CREATE CHAT: Error:', err);
      throw err;
    }
  };

  // Generate initial brief
  const generateInitialBrief = async (chatId: string, description: string, productInfo: string): Promise<void> => {
    try {
      console.log('🔵 BRIEF: Starting generation for chat:', chatId);
      
      // Generate brief using workflow service
      const briefMessage = await chatWorkflowService.generateInitialBrief(description, productInfo);
      const approvalMessage = chatWorkflowService.createApprovalRequest();
      
      // Remove loading messages and add brief + approval
      const { data: currentChat, error: fetchError } = await supabase
        .from('video_chats')
        .select('messages, workflow_state')
        .eq('id', chatId)
        .single();

      if (fetchError) {
        console.error('🔴 BRIEF: Failed to fetch chat:', fetchError);
        throw fetchError;
      }

      const currentMessages = Array.isArray(currentChat.messages) ? currentChat.messages : [];
      const messagesWithoutLoading = currentMessages.filter(msg => msg.type !== 'loading');
      const finalMessages = [...messagesWithoutLoading, briefMessage, approvalMessage];

      // Update workflow state
      const updatedWorkflowState = chatWorkflowService.updateWorkflowState(
        currentChat.workflow_state || {
          phase: 'initial',
          brief_approved: false,
          revision_count: 0,
          last_action: 'created',
          context: {}
        },
        'generate_brief'
      );

      // Update database
      const { error: updateError } = await supabase
        .from('video_chats')
        .update({
          messages: finalMessages,
          workflow_state: updatedWorkflowState,
          updated_at: new Date().toISOString()
        })
        .eq('id', chatId);

      if (updateError) {
        console.error('🔴 BRIEF: Update error:', updateError);
        throw updateError;
      }

      console.log('🟢 BRIEF: Successfully generated and saved');
      
    } catch (error) {
      console.error('🔴 BRIEF: Error:', error);
      await addErrorMessage(chatId, 'Sorry, I encountered an error while creating your video brief. Please try again.');
    }
  };

  // Send message with workflow logic
  const sendMessage = async (chatId: string, content: string): Promise<void> => {
    if (!user) return;

    try {
      console.log('🔵 SEND MESSAGE: Starting for chat:', chatId, 'Content:', content.substring(0, 50));
      
      // Add user message immediately
      const userMessage: ChatMessage = {
        id: `msg_${Date.now()}_user`,
        role: 'user',
        content,
        timestamp: new Date().toISOString(),
        type: 'text'
      };

      await addMessageToChat(chatId, userMessage);

      // Get current chat state
      const { data: currentChat, error: fetchError } = await supabase
        .from('video_chats')
        .select('*')
        .eq('id', chatId)
        .single();

      if (fetchError || !currentChat) {
        console.error('🔴 SEND MESSAGE: Failed to fetch chat:', fetchError);
        throw new Error('Failed to fetch current chat');
      }

      const workflowState = currentChat.workflow_state || {
        phase: 'initial',
        brief_approved: false,
        revision_count: 0,
        last_action: 'created',
        context: {}
      };

      // Determine what action to take
      const { action } = chatWorkflowService.determineWorkflowAction(content, workflowState);
      console.log('🔵 WORKFLOW: Determined action:', action, 'Current phase:', workflowState.phase);

      // Add thinking message
      const thinkingMessage: ChatMessage = {
        id: `msg_${Date.now()}_thinking`,
        role: 'assistant',
        content: 'Let me work on that for you...',
        timestamp: new Date().toISOString(),
        type: 'loading'
      };

      await addMessageToChat(chatId, thinkingMessage);

      // Execute the determined action
      await executeWorkflowAction(chatId, action, content, currentChat);

    } catch (err) {
      console.error('🔴 SEND MESSAGE: Error:', err);
      // Force refresh chat data on error
      setTimeout(() => {
        fetchChats();
      }, 1000);
      await addErrorMessage(chatId, 'Sorry, I encountered an error. Please try again.');
    }
  };

  // Execute workflow action
  const executeWorkflowAction = async (
    chatId: string, 
    action: string, 
    userContent: string, 
    currentChat: VideoChat
  ): Promise<void> => {
    try {
      console.log('🔵 EXECUTE: Action:', action);

      switch (action) {
        case 'approve_brief':
          await handleBriefApproval(chatId, currentChat);
          break;
          
        case 'revise_brief':
          await handleBriefRevision(chatId, userContent, currentChat);
          break;
          
        case 'request_revision':
          await handleVideoRevision(chatId, userContent, currentChat);
          break;
          
        case 'general_chat':
        default:
          await handleGeneralConversation(chatId, userContent, currentChat);
          break;
      }
    } catch (error) {
      console.error('🔴 EXECUTE: Error:', error);
      throw error;
    }
  };

  // Handle brief approval - renamed and updated to fetch chat internally
  const approveAndStartProduction = async (chatId: string): Promise<void> => {
    try {
      console.log('🔵 APPROVAL: Starting for chat:', chatId);
      
      // Fetch current chat data
      const { data: currentChat, error: fetchError } = await supabase
        .from('video_chats')
        .select('*')
        .eq('id', chatId)
        .single();

      if (fetchError || !currentChat) {
        console.error('🔴 APPROVAL: Failed to fetch chat:', fetchError);
        throw new Error('Failed to fetch current chat');
      }

      // Remove loading messages and approval requests
      const messagesWithoutLoading = currentChat.messages.filter(msg => 
        msg.type !== 'loading' && msg.type !== 'approval_request'
      );
      
      const confirmationMessage: ChatMessage = {
        id: `msg_${Date.now()}_confirmation`,
        role: 'assistant',
        content: 'Perfect! Starting video production now...\n\nI will keep you updated with real-time progress. This typically takes 5-10 minutes.',
        timestamp: new Date().toISOString(), 
        type: 'text'
      };

      const finalMessages = [...messagesWithoutLoading, confirmationMessage];

      // Update workflow state
      const updatedWorkflowState = chatWorkflowService.updateWorkflowState(
        currentChat.workflow_state,
        'approve_brief'
      );

      // Update database
      const { error: updateError } = await supabase
        .from('video_chats')
        .update({
          status: 'approved',
          messages: finalMessages,
          workflow_state: updatedWorkflowState,
          updated_at: new Date().toISOString()
        })
        .eq('id', chatId);

      if (updateError) {
        console.error('🔴 APPROVAL: Update error:', updateError);
        throw updateError;
      }

      console.log('🟢 APPROVAL: Success, starting production');
      
      // Start video production
      setTimeout(() => startVideoProduction(chatId), 1000);
      
    } catch (error) {
      console.error('🔴 APPROVAL: Error:', error);
      throw error;
    }
  };

  // Handle brief revision
  const handleBriefRevision = async (chatId: string, userRequest: string, currentChat: VideoChat): Promise<void> => {
    try {
      console.log('🔵 BRIEF REVISION: Starting for chat:', chatId);
      
      // Find original brief
      const originalBrief = currentChat.messages.find(msg => msg.type === 'brief')?.content || '';
      const productInfo = currentChat.workflow_state.context?.product_info || currentChat.description;
      
      // Generate revised brief
      const revisedBriefMessage = await chatWorkflowService.reviseBrief(originalBrief, userRequest, productInfo);
      const newApprovalMessage = chatWorkflowService.createApprovalRequest();
      
      // Remove loading and old brief messages
      const messagesWithoutLoadingAndBrief = currentChat.messages.filter(msg => 
        msg.type !== 'loading' && msg.type !== 'brief' && msg.type !== 'approval_request'
      );
      
      const finalMessages = [...messagesWithoutLoadingAndBrief, revisedBriefMessage, newApprovalMessage];

      // Update workflow state
      const updatedWorkflowState = chatWorkflowService.updateWorkflowState(
        currentChat.workflow_state,
        'revise_brief'
      );

      // Update database
      const { error: updateError } = await supabase
        .from('video_chats')
        .update({
          messages: finalMessages,
          workflow_state: updatedWorkflowState,
          updated_at: new Date().toISOString()
        })
        .eq('id', chatId);

      if (updateError) {
        console.error('🔴 BRIEF REVISION: Update error:', updateError);
        throw updateError;
      }

      console.log('🟢 BRIEF REVISION: Success');
      
    } catch (error) {
      console.error('🔴 BRIEF REVISION: Error:', error);
      throw error;
    }
  };

  // Handle video revision request
  const handleVideoRevision = async (chatId: string, userRequest: string, currentChat: VideoChat): Promise<void> => {
    try {
      console.log('🔵 VIDEO REVISION: Starting for chat:', chatId);
      
      // Remove loading messages
      const messagesWithoutLoading = currentChat.messages.filter(msg => msg.type !== 'loading');
      
      const revisionMessage = await chatWorkflowService.handleRevisionRequest(userRequest);
      const finalMessages = [...messagesWithoutLoading, revisionMessage];

      // Update workflow state
      const updatedWorkflowState = chatWorkflowService.updateWorkflowState(
        currentChat.workflow_state,
        'request_revision'
      );

      // Update database
      const { error: updateError } = await supabase
        .from('video_chats')
        .update({
          status: 'revision',
          messages: finalMessages,
          workflow_state: updatedWorkflowState,
          updated_at: new Date().toISOString()
        })
        .eq('id', chatId);

      if (updateError) {
        console.error('🔴 VIDEO REVISION: Update error:', updateError);
        throw updateError;
      }

      console.log('🟢 VIDEO REVISION: Success');
      
    } catch (error) {
      console.error('🔴 VIDEO REVISION: Error:', error);
      throw error;
    }
  };

  // Handle general conversation
  const handleGeneralConversation = async (chatId: string, content: string, currentChat: VideoChat): Promise<void> => {
    try {
      console.log('🔵 CONVERSATION: Starting for chat:', chatId);
      
      // Prepare chat history for AI
      const chatHistory = currentChat.messages
        .filter(msg => msg.type !== 'loading' && msg.role !== 'system')
        .map(msg => ({
          role: msg.role,
          content: msg.content
        }));
      
      // Add current message to history
      chatHistory.push({ role: 'user', content });
      
      // Generate AI response
      const aiResponse = await chatWorkflowService.generateChatResponse(chatHistory);
      
      // Remove loading messages
      const messagesWithoutLoading = currentChat.messages.filter(msg => msg.type !== 'loading');
      
      // Add AI response
      const aiMessage: ChatMessage = {
        id: `msg_${Date.now()}_ai`,
        role: 'assistant',
        content: aiResponse.replace(/\*\*/g, '').replace(/\*/g, ''), // Clean up any remaining markdown
        timestamp: new Date().toISOString(),
        type: 'text'
      };

      const finalMessages = [...messagesWithoutLoading, aiMessage];

      // Update database
      const { error: updateError } = await supabase
        .from('video_chats')
        .update({
          messages: finalMessages,
          updated_at: new Date().toISOString()
        })
        .eq('id', chatId);

      if (updateError) {
        console.error('🔴 CONVERSATION: Update error:', updateError);
        throw updateError;
      }

      console.log('🟢 CONVERSATION: Success');
      
    } catch (error) {
      console.error('🔴 CONVERSATION: Error:', error);
      throw error;
    }
  };

  // Start video production with live updates
  const startVideoProduction = async (chatId: string): Promise<void> => {
    try {
      console.log('🔵 PRODUCTION: Starting for chat:', chatId);
      
      // Update status to generating
      await updateChatState(chatId, 'generating', { 
        phase: 'production',
        last_action: 'production_started'
      });

      // Add initial production status message
      const initialStatusMessage = chatWorkflowService.createProductionStartMessage();
      await addMessageToChat(chatId, initialStatusMessage);

      const steps = [
        { id: 'script', name: 'Script Planning', duration: 3000 },
        { id: 'analysis', name: 'Product Analysis', duration: 2500 },
        { id: 'frames', name: 'Frame Generation', duration: 4000 },
        { id: 'voiceover', name: 'Voiceover Creation', duration: 3500 },
        { id: 'music', name: 'Music Composition', duration: 2000 },
        { id: 'assembly', name: 'Final Assembly', duration: 3000 }
      ];
      
      // Process each step with live updates
      for (let i = 0; i < steps.length; i++) {
        const step = steps[i];
        const progress = Math.round(((i + 1) / steps.length) * 100);
        
        // Update the production status message
        const statusUpdateMessage = chatWorkflowService.updateProductionStatusMessage(step.id, progress);
        
        // Update the existing production status message instead of adding new ones
        const { data: currentChat, error: fetchError } = await supabase
          .from('video_chats')
          .select('messages')
          .eq('id', chatId)
          .single();

        if (!fetchError && currentChat) {
          const messages = Array.isArray(currentChat.messages) ? currentChat.messages : [];
          const updatedMessages = messages.map(msg => 
            msg.type === 'production_status' ? statusUpdateMessage : msg
          );

          await supabase
            .from('video_chats')
            .update({
              messages: updatedMessages,
              updated_at: new Date().toISOString()
            })
            .eq('id', chatId);
        }
        
        // Simulate step processing
        await new Promise(resolve => setTimeout(resolve, step.duration));
      }

      // Generate mock video URL
      const mockVideoUrl = 'https://vimeo.com/1099766412';
      
      // Remove production status message and add video
      const { data: finalChat, error: finalFetchError } = await supabase
        .from('video_chats')
        .select('messages')
        .eq('id', chatId)
        .single();

      if (!finalFetchError && finalChat) {
        const messages = Array.isArray(finalChat.messages) ? finalChat.messages : [];
        const messagesWithoutStatus = messages.filter(msg => msg.type !== 'production_status');
        
        // Add video delivery message
        const videoMessage = chatWorkflowService.createVideoDeliveryMessage(mockVideoUrl);
        const postProductionMessage = chatWorkflowService.createPostProductionMessage();
        
        const finalMessages = [...messagesWithoutStatus, videoMessage, postProductionMessage];

        await supabase
          .from('video_chats')
          .update({
            messages: finalMessages,
            video_url: mockVideoUrl,
            status: 'completed',
            workflow_state: {
              phase: 'delivery',
              last_action: 'video_delivered',
              brief_approved: true,
              revision_count: 0,
              context: {}
            },
            updated_at: new Date().toISOString()
          })
          .eq('id', chatId);
      }

      console.log('🟢 PRODUCTION: Completed successfully');
      
    } catch (error) {
      console.error('🔴 PRODUCTION: Error:', error);
      await addErrorMessage(chatId, 'Sorry, there was an error during video production. Please contact support.');
    }
  };

  // Add error message
  const addErrorMessage = async (chatId: string, errorText: string): Promise<void> => {
    try {
      const errorMessage: ChatMessage = {
        id: `msg_${Date.now()}_error`,
        role: 'system',
        content: `❌ **Error:** ${errorText}`,
        timestamp: new Date().toISOString(),
        type: 'text'
      };

      await addMessageToChat(chatId, errorMessage);
    } catch (error) {
      console.error('🔴 Failed to add error message:', error);
    }
  };

  return {
    chats,
    activeChat,
    loading,
    error,
    setActiveChat,
    createNewChat,
    sendMessage,
    approveAndStartProduction,
    refetch: fetchChats
  };
}