import React from 'react';

// Organization Schema
export const OrganizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "VidCom AI",
  "url": "https://vidcom.ai",
  "logo": "https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png",
  "description": "Transform your product images into cinematic marketing videos using AI. Professional videos in minutes, not days.",
  "foundingDate": "2024",
  "contactPoint": {
    "@type": "ContactPoint",
    "email": "help.vidcom@gmail.com",
    "contactType": "customer service",
    "availableLanguage": ["English"]
  },
  "sameAs": [
    "https://vidcom.ai"
  ],
  "address": {
    "@type": "PostalAddress",
    "addressCountry": "US"
  }
};

// Service Schema
export const ServiceSchema = {
  "@context": "https://schema.org",
  "@type": "Service",
  "name": "AI Product Video Generation",
  "description": "Professional product marketing video creation using advanced AI technology",
  "provider": {
    "@type": "Organization",
    "name": "VidCom AI",
    "url": "https://vidcom.ai"
  },
  "serviceType": "Video Marketing",
  "areaServed": "US",
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "AI Video Packages",
    "itemListElement": [
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": "Basic Package"
        },
        "price": "49",
        "priceCurrency": "USD",
        "description": "Basic subscription with essential features"
      },
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": "Pro Package"
        },
        "price": "99",
        "priceCurrency": "USD",
        "description": "Professional subscription with advanced features"
      },
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": "Elite Package"
        },
        "price": "249",
        "priceCurrency": "USD",
        "description": "Elite subscription with premium features"
      }
    ]
  }
};

// FAQ Schema
export const FAQSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is VidCom AI?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "VidCom AI is a service for creating professional product marketing videos using advanced AI technology. We transform your product images into stunning promotional videos."
      }
    },
    {
      "@type": "Question",
      "name": "How long does it take to create a video?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Video generation typically takes 10-30 minutes from the moment you submit your request and images."
      }
    },
    {
      "@type": "Question",
      "name": "What types of videos do you create?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "We create product marketing videos optimized for all platforms: TikTok, Instagram Reels, YouTube Shorts, Facebook, and more. Each video is tailored for the specific platform."
      }
    },
    {
      "@type": "Question",
      "name": "What's included in the price?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Each package includes: custom video creation, professional creative direction, professional editing, full support throughout the process, and revision options."
      }
    }
  ]
};

// Pricing Schema
export const PricingSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "VidCom AI Pricing Plans",
  "description": "Choose the perfect VidCom AI plan for your business. Monthly subscriptions starting at $29 or flexible credit packages.",
  "url": "https://vidcom.ai/pricing",
  "mainEntity": {
    "@type": "Product",
    "name": "VidCom AI Video Generation Service",
    "offers": [
      {
        "@type": "Offer",
        "name": "Starter Plan",
        "price": "29",
        "priceCurrency": "USD",
        "description": "Perfect for small businesses starting with AI video marketing"
      },
      {
        "@type": "Offer",
        "name": "Creator Plan", 
        "price": "49",
        "priceCurrency": "USD",
        "description": "Ideal for content creators and growing businesses"
      },
      {
        "@type": "Offer",
        "name": "Business Plan",
        "price": "89", 
        "priceCurrency": "USD",
        "description": "Advanced features for professional businesses"
      },
      {
        "@type": "Offer",
        "name": "Agency Plan",
        "price": "199",
        "priceCurrency": "USD", 
        "description": "Ultimate package for agencies and enterprise-level production"
      }
    ]
  }
};

// Breadcrumb Schema
export const BreadcrumbSchema = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://vidcom.ai"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Pricing",
      "item": "https://vidcom.ai#pricing"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "Examples",
      "item": "https://vidcom.ai#examples"
    }
  ]
};

interface StructuredDataProps {
  schema: object;
}

const StructuredData: React.FC<StructuredDataProps> = ({ schema }) => {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
};

export default StructuredData;