import React, { useState } from 'react';
import { X, Check, Star, Zap, Crown, CreditCard, ArrowRight, Info, Shield, Clock, Sparkles } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useSubscription } from '../hooks/useSubscription';
import { useVideoCredits } from '../hooks/useVideoCredits';
import { formatPrice, getCreditPackages, getSubscriptionPlans } from '../stripe-config';
import CheckoutButton from './checkout/CheckoutButton';

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthRequired?: () => void;
}

const PricingModal: React.FC<PricingModalProps> = ({ isOpen, onClose, onAuthRequired }) => {
  const { user } = useAuth();
  const { subscription, hasActiveSubscription } = useSubscription();
  const { credits } = useVideoCredits();
  const [activeTab, setActiveTab] = useState<'subscriptions' | 'credits'>('subscriptions');

  if (!isOpen) return null;

  const subscriptionPlans = getSubscriptionPlans();
  const creditPackages = getCreditPackages();

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Dark Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-xl"
        onClick={onClose}
        aria-hidden="true"
      />
      
      {/* Modal Container */}
      <div className="relative flex min-h-full items-center justify-center p-2 lg:p-4">
        <div className="relative w-full max-w-6xl max-h-[98vh] lg:max-h-[95vh] bg-gray-900/95 backdrop-blur-xl border border-gray-700/50 rounded-2xl lg:rounded-3xl overflow-hidden shadow-2xl">
          
          {/* Header */}
          <header className="relative px-4 lg:px-6 py-3 lg:py-4 border-b border-gray-700/50 bg-gradient-to-r from-gray-900 to-gray-800">
            <button
              onClick={onClose}
              className="absolute top-2 lg:top-3 right-3 lg:right-4 p-2 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded-xl transition-all duration-200"
              aria-label="Close pricing modal"
            >
              <X size={18} />
            </button>
            
            <div className="text-center">
              <h1 className="text-lg lg:text-xl font-bold text-white mb-2">
                Choose Your Plan
              </h1>
              
              {/* Current Status */}
              {user && (
                <div className="inline-flex items-center gap-2 bg-gray-800/60 backdrop-blur-sm rounded-xl px-3 lg:px-4 py-1 lg:py-2 border border-gray-600/50">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-xs font-medium text-gray-200">
                    {hasActiveSubscription() ? 'Active Subscription' : `${credits?.available_credits || 0} Credits Available`}
                  </span>
                </div>
              )}
            </div>
          </header>

          {/* Tab Navigation */}
          <nav className="border-b border-gray-700/50 bg-gray-800/50" role="tablist">
            <div className="max-w-4xl mx-auto px-4 lg:px-8">
              <div className="flex" style={{ display: user ? 'flex' : 'block' }}>
                <button
                  role="tab"
                  aria-selected={activeTab === 'subscriptions'}
                  onClick={() => setActiveTab('subscriptions')}
                  className={`${user ? 'flex-1' : 'w-full'} py-3 lg:py-4 px-3 lg:px-6 text-center font-semibold transition-all duration-200 border-b-2 text-sm lg:text-base ${
                    activeTab === 'subscriptions'
                      ? 'border-electric-400 text-electric-400 bg-electric-400/10'
                      : 'border-transparent text-gray-400 hover:text-electric-400 hover:bg-electric-400/5'
                  }`}
                >
                  <div className="flex items-center justify-center gap-2">
                    <Crown size={16} />
                    <span className="hidden sm:inline">Monthly Plans</span>
                    <span className="sm:hidden">Plans</span>
                    <span className="hidden sm:inline text-xs bg-electric-500 text-white px-2 py-1 rounded-lg">
                      Best Value
                    </span>
                  </div>
                </button>
                
                {user && (
                  <button
                  role="tab"
                  aria-selected={activeTab === 'credits'}
                  onClick={() => setActiveTab('credits')}
                  className={`flex-1 py-3 lg:py-4 px-3 lg:px-6 text-center font-semibold transition-all duration-200 border-b-2 text-sm lg:text-base ${
                    activeTab === 'credits'
                      ? 'border-electric-400 text-electric-400 bg-electric-400/10'
                      : 'border-transparent text-gray-400 hover:text-electric-400 hover:bg-electric-400/5'
                  }`}
                >
                  <div className="flex items-center justify-center gap-2">
                    <Zap size={16} />
                    <span className="hidden sm:inline">Top Up Credits</span>
                    <span className="sm:hidden">Credits</span>
                  </div>
                </button>
                )}
              </div>
            </div>
          </nav>

          {/* Content Area */}
          <main className="max-h-[65vh] lg:max-h-[60vh] overflow-y-auto bg-gray-900">
            <div className="max-w-5xl mx-auto p-4 lg:p-8">
              
              {/* Subscriptions Tab */}
              {activeTab === 'subscriptions' && (
                <section role="tabpanel" aria-labelledby="subscriptions-tab">
                  <div className="text-center mb-4 lg:mb-8">
                    <h2 className="text-lg lg:text-xl font-bold text-white mb-2">
                      Monthly Subscriptions
                    </h2>
                    <p className="text-xs lg:text-sm text-gray-400 max-w-2xl mx-auto">
                      Get monthly credits and unlimited video creation
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-6 mb-4 lg:mb-8">
                    {subscriptionPlans.map((plan, index) => (
                      <article 
                        key={plan.id}
                        className={`relative bg-gray-800/60 backdrop-blur-sm border rounded-xl lg:rounded-2xl p-3 lg:p-6 transition-all duration-300 hover:scale-105 hover:bg-gray-800/80 ${
                          index === 1 
                            ? 'border-electric-400/50 shadow-lg shadow-electric-400/20' 
                            : 'border-gray-600/50 hover:border-gray-500/50'
                        }`}
                      >
                        {/* Popular Badge */}
                        {index === 1 && (
                          <div className="absolute -top-2 lg:-top-3 left-1/2 transform -translate-x-1/2">
                            <span className="bg-gradient-to-r from-electric-500 to-electric-600 text-white px-2 lg:px-3 py-1 rounded-lg lg:rounded-xl text-xs font-bold flex items-center gap-1 shadow-lg">
                              <Star size={10} />
                              <span className="hidden sm:inline">Most Popular</span>
                              <span className="sm:hidden">Popular</span>
                            </span>
                          </div>
                        )}

                        {/* Plan Header */}
                        <header className="text-center mb-3 lg:mb-6">
                          <div className={`w-10 lg:w-12 h-10 lg:h-12 rounded-xl flex items-center justify-center mx-auto mb-2 lg:mb-3 ${
                            index === 0 ? 'bg-gradient-to-br from-blue-500 to-blue-600' :
                            index === 1 ? 'bg-gradient-to-br from-electric-500 to-electric-600' :
                            index === 2 ? 'bg-gradient-to-br from-purple-500 to-purple-600' :
                            'bg-gradient-to-br from-orange-500 to-orange-600'
                          }`}>
                            <Crown className="text-white" size={16} />
                          </div>
                          <h3 className="text-base lg:text-lg font-bold text-white mb-1 lg:mb-2">
                            {plan.name}
                          </h3>
                          <div className="mb-2">
                            <span className="text-lg lg:text-2xl font-bold text-white">
                              {formatPrice(plan.price, plan.currency)}
                            </span>
                            <span className="text-sm text-gray-400">/month</span>
                          </div>
                          <p className="text-xs text-electric-400 font-semibold bg-electric-400/10 inline-block px-2 lg:px-3 py-1 rounded-lg border border-electric-400/20">
                            {plan.credits} credits monthly
                          </p>
                        </header>

                        {/* Key Features */}
                        <div className="mb-3 lg:mb-6">
                          <div className="grid grid-cols-2 gap-1 lg:gap-2 text-xs text-gray-300">
                            <div className="flex items-center gap-1">
                              <div className="w-1 h-1 bg-electric-400 rounded-full"></div>
                              <span>{plan.products} products</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <div className="w-1 h-1 bg-electric-400 rounded-full"></div>
                              <span>{plan.videos} videos</span>
                            </div>
                          </div>
                        </div>

                        {/* Features List - Compact */}
                        <ul className="space-y-1 lg:space-y-1.5 mb-3 lg:mb-6" role="list">
                          {plan.features.slice(0, 3).map((feature, featureIndex) => (
                            <li key={featureIndex} className="flex items-start gap-2">
                              <Check className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" aria-hidden="true" />
                              <span className="text-xs text-gray-300 leading-relaxed line-clamp-2">{feature}</span>
                            </li>
                          ))}
                        </ul>

                        {/* CTA Button */}
                        <CheckoutButton
                          priceId={plan.priceId}
                          productName={plan.name}
                          mode={plan.mode}
                          onAuthRequired={onAuthRequired}
                          className={`w-full py-2 lg:py-3 px-3 lg:px-4 font-bold text-xs lg:text-sm transition-all duration-200 hover:scale-105 rounded-lg lg:rounded-xl ${
                            index === 1
                              ? 'bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white shadow-lg shadow-electric-500/25'
                              : 'bg-gray-700/50 hover:bg-gray-600/50 text-gray-200 border border-gray-600/50 hover:border-gray-500/50'
                          }`}
                        >
                          <span className="flex items-center justify-center gap-2">
                            <span className="hidden sm:inline">{index === 1 ? 'Start Creating' : 'Get Started'}</span>
                            <span className="sm:hidden">{index === 1 ? 'Start' : 'Get'}</span>
                            <ArrowRight size={14} />
                          </span>
                        </CheckoutButton>
                      </article>
                    ))}
                  </div>

                  {/* Subscription Benefits */}
                  <div className="bg-gray-800/40 backdrop-blur-sm border border-gray-700/50 rounded-xl lg:rounded-2xl p-4 lg:p-6">
                    <h3 className="text-base lg:text-lg font-bold text-white mb-4 lg:mb-6 text-center">
                      Why Choose a Subscription?
                    </h3>
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-6">
                      <div className="text-center">
                        <div className="w-8 lg:w-10 h-8 lg:h-10 rounded-lg lg:rounded-xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center mx-auto mb-2 lg:mb-3">
                          <Shield className="w-5 h-5 text-white" />
                        </div>
                        <h4 className="font-bold text-white mb-2 text-sm">Best Value</h4>
                        <p className="text-xs text-gray-400 leading-relaxed">
                          <span className="hidden sm:inline">Lower cost per video with monthly credits</span>
                          <span className="sm:hidden">Lower cost per video</span>
                        </p>
                      </div>
                      <div className="text-center">
                        <div className="w-8 lg:w-10 h-8 lg:h-10 rounded-lg lg:rounded-xl bg-gradient-to-br from-electric-500 to-electric-600 flex items-center justify-center mx-auto mb-2 lg:mb-3">
                          <Clock className="w-5 h-5 text-white" />
                        </div>
                        <h4 className="font-bold text-white mb-2 text-sm">Never Run Out</h4>
                        <p className="text-xs text-gray-400 leading-relaxed">
                          <span className="hidden sm:inline">Fresh credits every month automatically</span>
                          <span className="sm:hidden">Monthly credits</span>
                        </p>
                      </div>
                      <div className="text-center">
                        <div className="w-8 lg:w-10 h-8 lg:h-10 rounded-lg lg:rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center mx-auto mb-2 lg:mb-3">
                          <Star className="w-5 h-5 text-white" />
                        </div>
                        <h4 className="font-bold text-white mb-2 text-sm">Priority Support</h4>
                        <p className="text-xs text-gray-400 leading-relaxed">
                          <span className="hidden sm:inline">Faster processing and dedicated help</span>
                          <span className="sm:hidden">Priority support</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </section>
              )}

              {/* Credits Tab */}
              {activeTab === 'credits' && user && (
                <section role="tabpanel" aria-labelledby="credits-tab">
                  <div className="text-center mb-4 lg:mb-8">
                    <h2 className="text-lg lg:text-xl font-bold text-white mb-2">
                      Top Up Your Credits
                    </h2>
                    <p className="text-xs lg:text-sm text-gray-400 max-w-2xl mx-auto">
                      Add more credits to your account for extra videos
                    </p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 lg:gap-6 mb-4 lg:mb-8">
                    {creditPackages.map((pack, index) => (
                      <article 
                        key={pack.id}
                        className={`relative bg-gray-800/60 backdrop-blur-sm border rounded-xl lg:rounded-2xl p-3 lg:p-6 transition-all duration-300 hover:scale-105 hover:bg-gray-800/80 ${
                          index === 1 
                            ? 'border-electric-400/50 shadow-lg shadow-electric-400/20' 
                            : 'border-gray-600/50 hover:border-gray-500/50'
                        }`}
                      >
                        {/* Best Value Badge */}
                        {index === 1 && (
                          <div className="absolute -top-2 lg:-top-3 left-1/2 transform -translate-x-1/2">
                            <span className="bg-gradient-to-r from-electric-500 to-electric-600 text-white px-2 lg:px-3 py-1 rounded-lg lg:rounded-xl text-xs font-bold flex items-center gap-1">
                              💎 Best Value
                            </span>
                          </div>
                        )}

                        {/* Package Header */}
                        <header className="text-center mb-3 lg:mb-6">
                          <div className="w-12 lg:w-14 h-12 lg:h-14 rounded-lg lg:rounded-xl bg-gradient-to-br from-electric-500 to-electric-600 flex items-center justify-center mx-auto mb-2 lg:mb-3 shadow-lg">
                            <span className="text-lg lg:text-xl font-bold text-white">
                              {pack.credits}
                            </span>
                          </div>
                          <h3 className="text-base lg:text-lg font-bold text-white mb-1 lg:mb-2">
                            {pack.name}
                          </h3>
                          <div className="mb-2">
                            <span className="text-lg lg:text-2xl font-bold text-white">
                              {formatPrice(pack.price, pack.currency)}
                            </span>
                          </div>
                          <p className="text-xs text-electric-400 font-semibold bg-electric-400/10 inline-block px-2 lg:px-3 py-1 rounded-lg border border-electric-400/20">
                            <span className="hidden sm:inline">₪{(pack.price / pack.credits!).toFixed(1)} per video</span>
                            <span className="sm:hidden">₪{(pack.price / pack.credits!).toFixed(1)}/video</span>
                          </p>
                        </header>

                        {/* Features */}
                        <ul className="space-y-1 lg:space-y-1.5 mb-3 lg:mb-6" role="list">
                          {pack.features.slice(0, 3).map((feature, featureIndex) => (
                            <li key={featureIndex} className="flex items-start gap-2">
                              <Check className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" aria-hidden="true" />
                              <span className="text-xs text-gray-300 leading-relaxed line-clamp-2">{feature}</span>
                            </li>
                          ))}
                        </ul>

                        {/* CTA Button */}
                        <CheckoutButton
                          priceId={pack.priceId}
                          productName={pack.name}
                          mode={pack.mode}
                          onAuthRequired={onAuthRequired}
                          className={`w-full py-3 lg:py-3 px-3 lg:px-4 font-bold text-sm lg:text-sm transition-all duration-200 hover:scale-105 rounded-lg lg:rounded-xl min-h-[44px] flex items-center justify-center ${
                            index === 1
                              ? 'bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white shadow-lg shadow-electric-500/25'
                              : 'bg-gray-700/50 hover:bg-gray-600/50 text-gray-200 border border-gray-600/50 hover:border-gray-500/50'
                          }`}
                        >
                          Top Up Now
                        </CheckoutButton>
                      </article>
                    ))}
                  </div>

                  {/* Credits Info */}
                  <div className="bg-gray-800/40 backdrop-blur-sm border border-gray-700/50 rounded-xl lg:rounded-2xl p-4 lg:p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-8 lg:w-10 h-8 lg:h-10 rounded-lg lg:rounded-xl bg-gradient-to-br from-electric-500 to-electric-600 flex items-center justify-center flex-shrink-0">
                        <Info className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-white mb-2 lg:mb-3 text-sm lg:text-base">
                          How Credits Work
                        </h3>
                        <ul className="text-xs lg:text-sm text-gray-300 space-y-1 lg:space-y-2 leading-relaxed">
                          <li className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 bg-electric-400 rounded-full"></div>
                            Each video creation costs 10 credits
                          </li>
                          <li className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 bg-electric-400 rounded-full"></div>
                            Video revisions cost 5 credits each
                          </li>
                          <li className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 bg-electric-400 rounded-full"></div>
                            Credits never expire
                          </li>
                          <li className="flex items-center gap-2 hidden lg:flex">
                            <div className="w-1.5 h-1.5 bg-electric-400 rounded-full"></div>
                            Perfect for extra videos beyond subscription
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </section>
              )}
            </div>
          </main>

          {/* Footer */}
          <footer className="bg-gray-800/60 backdrop-blur-sm px-4 lg:px-8 py-4 lg:py-6 border-t border-gray-700/50">
            <div className="max-w-4xl mx-auto">
              <div className="flex flex-col lg:flex-row items-center justify-between gap-3 lg:gap-4">
                <div className="text-center lg:text-left">
                  <p className="text-sm text-gray-300">
                    <span className="hidden sm:inline">Need help choosing? Contact us at </span>
                    <span className="sm:hidden">Contact: </span>
                    <a 
                      href="mailto:help.vidcom@gmail.com" 
                      className="text-electric-400 hover:text-electric-300 font-semibold transition-colors"
                    >
                      help.vidcom@gmail.com
                    </a>
                  </p>
                </div>
                
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Shield size={14} />
                  <span className="hidden sm:inline">Secure payment with Stripe</span>
                  <span className="sm:hidden">Secure payment</span>
                </div>
              </div>
              
              {/* Money Back Guarantee */}
              <div className="mt-4 text-center">
                <div className="inline-flex items-center gap-2 bg-green-500/10 text-green-400 px-3 lg:px-4 py-2 rounded-lg lg:rounded-xl text-xs lg:text-sm font-semibold border border-green-500/20">
                  <Check size={14} />
                  <span className="hidden sm:inline">30-day money-back guarantee</span>
                  <span className="sm:hidden">30-day guarantee</span>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
  );
};

export default PricingModal;