import React, { useState } from 'react';
import { Eye, EyeOff, Mail, Lock, LogIn, ArrowRight, Home } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';
import SEOHead from './SEOHead';

const LoginPage: React.FC = () => {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setAlert(null);

    if (!email.trim() || !password.trim()) {
      setAlert({ type: 'error', message: 'Please fill in all fields' });
      setLoading(false);
      return;
    }

    try {
      const { error } = await signIn(email, password);
      if (error) {
        setAlert({ type: 'error', message: error.message });
      } else {
        setAlert({ type: 'success', message: 'Welcome back!' });
        setTimeout(() => {
          navigate('/dashboard');
        }, 1000);
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'An unexpected error occurred. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen neo-cyber-bg relative">
      <SEOHead
        title="Sign In | VidCom AI - Access Your Video Dashboard"
        description="Sign in to your VidCom AI account to access your video projects, manage credits, and create professional product videos with AI."
        keywords="VidCom AI login, sign in, video dashboard, AI video account"
        canonicalUrl="https://vidcom.ai/login"
      />

      {/* Background Auras */}
      <div className="cyber-aura-1"></div>
      <div className="cyber-aura-2"></div>
      <div className="cyber-aura-3"></div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between p-4 lg:p-6">
        <div className="flex items-center gap-6">
          <img 
            src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
            alt="VidCom AI" 
            className="h-16 lg:h-20 w-auto object-contain"
          />
          
          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6">
            <a
              href="/"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              Home
            </a>
            <a
              href="/faq"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              FAQ
            </a>
            <a
              href="/contact"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              Contact
            </a>
            <a
              href="/pricing"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              Pricing
            </a>
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-electric-600 font-semibold text-sm lg:text-base">
            Sign In
          </span>
          <a
            href="/signup"
            className="btn-cyber-primary py-2 px-4 lg:px-6 font-semibold text-sm lg:text-base shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Get Started
          </a>
        </div>
      </header>

      <div className="relative z-10 flex items-center justify-center min-h-[calc(100vh-120px)] px-4">
        <div className="w-full max-w-md">
          {/* Login Form */}
          <div className="card-cyber p-8">
            <div className="text-center mb-8">
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2 heading-cyber">
                Welcome Back
              </h1>
              <p className="text-gray-700 text-cyber">
                Sign in to your VidCom AI account
              </p>
            </div>

            {alert && (
              <Alert
                type={alert.type}
                message={alert.message}
                onClose={() => setAlert(null)}
                className="mb-6"
              />
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-900">
                  Email Address
                </label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 flex items-center justify-center">
                    <Mail className="text-electric-600" size={14} />
                  </div>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full pl-14 pr-4 py-3.5 input-cyber text-base"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-900">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 flex items-center justify-center">
                    <Lock className="text-electric-600" size={14} />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full pl-14 pr-14 py-3.5 input-cyber text-base"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 hover:bg-electric-300/30 flex items-center justify-center text-electric-600 hover:text-electric-700 transition-all duration-200"
                  >
                    {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 px-6 btn-cyber-primary font-semibold flex items-center justify-center gap-3 text-base hover-cyber micro-cyber glow-cyber-electric disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <LoadingSpinner size="sm" />
                    Signing In...
                  </>
                ) : (
                  <>
                    <LogIn size={16} />
                    Sign In
                    <ArrowRight size={16} />
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 text-center space-y-4">
              <a
                href="/reset-password"
                className="text-electric-600 hover:text-electric-700 transition-colors text-sm font-medium"
              >
                Forgot your password?
              </a>
              
              <div className="border-t border-gray-200 pt-4">
                <p className="text-gray-600 text-sm mb-3">
                  Don't have an account?
                </p>
                <a
                  href="/signup"
                  className="btn-cyber-secondary py-3 px-6 font-semibold inline-flex items-center gap-2"
                >
                  Create Account
                  <ArrowRight size={16} />
                </a>
              </div>
            </div>
          </div>

          {/* Back to Home */}
          <div className="text-center mt-8">
            <a
              href="/"
              className="text-gray-600 hover:text-electric-600 transition-colors inline-flex items-center gap-2 font-medium"
            >
              <Home size={16} />
              Back to Home
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;