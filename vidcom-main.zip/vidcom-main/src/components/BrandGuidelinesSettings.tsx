import React, { useState, useEffect } from 'react';
import { Palette, Upload, Save, X, Eye, Type, Zap, Clock, Sparkles } from 'lucide-react';
import { useBrandGuidelines, BrandGuidelines } from '../hooks/useBrandGuidelines';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';

const BrandGuidelinesSettings: React.FC = () => {
  const { user } = useAuth();
  const { brandGuidelines, loading, createOrUpdate } = useBrandGuidelines();
  const [formData, setFormData] = useState({
    logo_url: '',
    primary_color: '#5EE3FF',
    secondary_color: '#B18CFF',
    accent_color: '#FFD8BE',
    font_family: 'Satoshi',
    title_style: 'bold',
    body_style: 'regular',
    mood: 'professional',
    pace: 'medium',
    transitions: 'smooth',
    default_prompts: [] as string[]
  });
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [newPrompt, setNewPrompt] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  useEffect(() => {
    if (brandGuidelines) {
      setFormData({
        logo_url: brandGuidelines.logo_url || '',
        primary_color: brandGuidelines.primary_color || '#5EE3FF',
        secondary_color: brandGuidelines.secondary_color || '#B18CFF',
        accent_color: brandGuidelines.accent_color || '#FFD8BE',
        font_family: brandGuidelines.font_family || 'Satoshi',
        title_style: brandGuidelines.title_style || 'bold',
        body_style: brandGuidelines.body_style || 'regular',
        mood: brandGuidelines.mood || 'professional',
        pace: brandGuidelines.pace || 'medium',
        transitions: brandGuidelines.transitions || 'smooth',
        default_prompts: brandGuidelines.default_prompts || []
      });
    }
  }, [brandGuidelines]);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setAlert({ type: 'error', message: 'Logo file must be smaller than 5MB' });
      return;
    }

    if (!file.type.startsWith('image/')) {
      setAlert({ type: 'error', message: 'Please upload an image file' });
      return;
    }

    setLogoFile(file);
    
    // Create preview URL
    const previewUrl = URL.createObjectURL(file);
    setFormData(prev => ({ ...prev, logo_url: previewUrl }));
  };

  const uploadLogoToSupabase = async (file: File): Promise<string> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    const timestamp = Date.now();
    const fileExtension = file.name.split('.').pop();
    const fileName = `brand-logos/${user.id}/logo_${timestamp}.${fileExtension}`;

    const { data, error } = await supabase.storage
      .from('video-request-images')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: true
      });

    if (error) {
      throw new Error(`Error uploading logo: ${error.message}`);
    }

    const { data: urlData } = supabase.storage
      .from('video-request-images')
      .getPublicUrl(fileName);

    if (!urlData?.publicUrl) {
      throw new Error('Failed to get public URL for logo');
    }

    return urlData.publicUrl;
  };

  const handleAddPrompt = () => {
    if (!newPrompt.trim()) return;
    
    setFormData(prev => ({
      ...prev,
      default_prompts: [...prev.default_prompts, newPrompt.trim()]
    }));
    setNewPrompt('');
  };

  const handleRemovePrompt = (index: number) => {
    setFormData(prev => ({
      ...prev,
      default_prompts: prev.default_prompts.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);
    setIsSubmitting(true);

    try {
      let logoUrl = formData.logo_url;

      // Upload logo if a new file was selected
      if (logoFile) {
        setAlert({ type: 'info', message: 'Uploading logo...' });
        logoUrl = await uploadLogoToSupabase(logoFile);
      }

      const guidelinesData = {
        ...formData,
        logo_url: logoUrl,
      };

      await createOrUpdate(guidelinesData);
      setAlert({ type: 'success', message: 'Brand guidelines saved successfully!' });
      setLogoFile(null);
    } catch (error) {
      console.error('Error saving brand guidelines:', error);
      setAlert({ 
        type: 'error', 
        message: error instanceof Error ? error.message : 'Failed to save brand guidelines' 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-4 lg:space-y-6">
      {alert && (
        <Alert
          type={alert.type}
          message={alert.message}
          onClose={() => setAlert(null)}
        />
      )}

      {/* Header */}
      <div>
        <h2 className="text-xl lg:text-2xl font-bold dev-heading">Brand Guidelines</h2>
        <p className="text-sm lg:text-base dev-text">Customize your brand settings to ensure consistent video styling</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 lg:space-y-8">
        {/* Logo Section */}
        <div className="card-dev p-4 lg:p-6">
          <h3 className="text-base lg:text-lg font-semibold dev-heading mb-3 lg:mb-4 flex items-center gap-2">
            <Upload size={20} />
            Brand Logo
          </h3>
          
          <div className="flex flex-col sm:flex-row items-start gap-4 lg:gap-6">
            {/* Logo Preview */}
            <div className="w-20 lg:w-24 h-20 lg:h-24 bg-dev-tertiary rounded-lg border border-dev-light flex items-center justify-center overflow-hidden mx-auto sm:mx-0">
              {formData.logo_url ? (
                <img
                  src={formData.logo_url}
                  alt="Brand Logo"
                  className="w-full h-full object-contain"
                />
              ) : (
                <Palette className="w-6 lg:w-8 h-6 lg:h-8 text-gray-500" />
              )}
            </div>

            {/* Upload Controls */}
            <div className="flex-1 text-center sm:text-left">
              <input
                type="file"
                id="logo-upload"
                accept="image/*"
                onChange={handleLogoUpload}
                className="hidden"
              />
              <label
                htmlFor="logo-upload"
                className="btn-dev-secondary py-2 px-3 lg:px-4 font-semibold cursor-pointer inline-flex items-center gap-2 text-sm lg:text-base"
              >
                <Upload size={16} />
                Upload Logo
              </label>
              <p className="text-xs dev-text-muted mt-2">
                PNG, JPG, SVG up to 5MB. Recommended: 200x200px
              </p>
            </div>
          </div>
        </div>

        {/* Colors Section */}
        <div className="card-dev p-4 lg:p-6">
          <h3 className="text-base lg:text-lg font-semibold dev-heading mb-3 lg:mb-4 flex items-center gap-2">
            <Palette size={20} />
            Brand Colors
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 lg:gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                Primary Color
              </label>
              <div className="flex items-center gap-2 lg:gap-3">
                <input
                  type="color"
                  value={formData.primary_color}
                  onChange={(e) => setFormData(prev => ({ ...prev, primary_color: e.target.value }))}
                  className="w-10 lg:w-12 h-10 lg:h-12 rounded-lg border border-dev-light cursor-pointer"
                />
                <input
                  type="text"
                  value={formData.primary_color}
                  onChange={(e) => setFormData(prev => ({ ...prev, primary_color: e.target.value }))}
                  className="flex-1 px-2 lg:px-3 py-2 input-dev text-xs lg:text-sm"
                  placeholder="#5EE3FF"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                Secondary Color
              </label>
              <div className="flex items-center gap-2 lg:gap-3">
                <input
                  type="color"
                  value={formData.secondary_color}
                  onChange={(e) => setFormData(prev => ({ ...prev, secondary_color: e.target.value }))}
                  className="w-10 lg:w-12 h-10 lg:h-12 rounded-lg border border-dev-light cursor-pointer"
                />
                <input
                  type="text"
                  value={formData.secondary_color}
                  onChange={(e) => setFormData(prev => ({ ...prev, secondary_color: e.target.value }))}
                  className="flex-1 px-2 lg:px-3 py-2 input-dev text-xs lg:text-sm"
                  placeholder="#B18CFF"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                Accent Color
              </label>
              <div className="flex items-center gap-2 lg:gap-3">
                <input
                  type="color"
                  value={formData.accent_color}
                  onChange={(e) => setFormData(prev => ({ ...prev, accent_color: e.target.value }))}
                  className="w-10 lg:w-12 h-10 lg:h-12 rounded-lg border border-dev-light cursor-pointer"
                />
                <input
                  type="text"
                  value={formData.accent_color}
                  onChange={(e) => setFormData(prev => ({ ...prev, accent_color: e.target.value }))}
                  className="flex-1 px-2 lg:px-3 py-2 input-dev text-xs lg:text-sm"
                  placeholder="#FFD8BE"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Typography Section */}
        <div className="card-dev p-4 lg:p-6">
          <h3 className="text-base lg:text-lg font-semibold dev-heading mb-3 lg:mb-4 flex items-center gap-2">
            <Type size={20} />
            Typography
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 lg:gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                Font Family
              </label>
              <select
                value={formData.font_family}
                onChange={(e) => setFormData(prev => ({ ...prev, font_family: e.target.value }))}
                className="w-full px-2 lg:px-3 py-2 input-dev text-sm lg:text-base"
              >
                <option value="Satoshi">Satoshi</option>
                <option value="Inter">Inter</option>
                <option value="Roboto">Roboto</option>
                <option value="Open Sans">Open Sans</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Poppins">Poppins</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                Title Style
              </label>
              <select
                value={formData.title_style}
                onChange={(e) => setFormData(prev => ({ ...prev, title_style: e.target.value }))}
                className="w-full px-2 lg:px-3 py-2 input-dev text-sm lg:text-base"
              >
                <option value="bold">Bold</option>
                <option value="semibold">Semi Bold</option>
                <option value="medium">Medium</option>
                <option value="regular">Regular</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                Body Style
              </label>
              <select
                value={formData.body_style}
                onChange={(e) => setFormData(prev => ({ ...prev, body_style: e.target.value }))}
                className="w-full px-2 lg:px-3 py-2 input-dev text-sm lg:text-base"
              >
                <option value="regular">Regular</option>
                <option value="medium">Medium</option>
                <option value="light">Light</option>
              </select>
            </div>
          </div>
        </div>

        {/* Video Style Section */}
        <div className="card-dev p-4 lg:p-6">
          <h3 className="text-base lg:text-lg font-semibold dev-heading mb-3 lg:mb-4 flex items-center gap-2">
            <Sparkles size={20} />
            Video Style Preferences
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 lg:gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                Mood
              </label>
              <select
                value={formData.mood}
                onChange={(e) => setFormData(prev => ({ ...prev, mood: e.target.value }))}
                className="w-full px-2 lg:px-3 py-2 input-dev text-sm lg:text-base"
              >
                <option value="professional">Professional</option>
                <option value="energetic">Energetic</option>
                <option value="calm">Calm</option>
                <option value="luxury">Luxury</option>
                <option value="playful">Playful</option>
                <option value="minimalist">Minimalist</option>
                <option value="bold">Bold</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                Pace
              </label>
              <select
                value={formData.pace}
                onChange={(e) => setFormData(prev => ({ ...prev, pace: e.target.value }))}
                className="w-full px-2 lg:px-3 py-2 input-dev text-sm lg:text-base"
              >
                <option value="slow">Slow</option>
                <option value="medium">Medium</option>
                <option value="fast">Fast</option>
                <option value="dynamic">Dynamic</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                Transitions
              </label>
              <select
                value={formData.transitions}
                onChange={(e) => setFormData(prev => ({ ...prev, transitions: e.target.value }))}
                className="w-full px-2 lg:px-3 py-2 input-dev text-sm lg:text-base"
              >
                <option value="smooth">Smooth</option>
                <option value="sharp">Sharp</option>
                <option value="dynamic">Dynamic</option>
                <option value="minimal">Minimal</option>
              </select>
            </div>
          </div>
        </div>

        {/* Default Prompts Section */}
        <div className="card-dev p-4 lg:p-6">
          <h3 className="text-base lg:text-lg font-semibold dev-heading mb-3 lg:mb-4 flex items-center gap-2">
            <Zap size={20} />
            Default Prompts
          </h3>
          <p className="text-sm dev-text mb-3 lg:mb-4">
            Add guidelines that will be automatically included in every video generation
          </p>
          
          {/* Add New Prompt */}
          <div className="flex flex-col sm:flex-row gap-2 lg:gap-3 mb-3 lg:mb-4">
            <input
              type="text"
              value={newPrompt}
              onChange={(e) => setNewPrompt(e.target.value)}
              placeholder="e.g., Always include call-to-action at the end"
              className="flex-1 px-2 lg:px-3 py-2 input-dev text-sm"
            />
            <button
              type="button"
              onClick={handleAddPrompt}
              disabled={!newPrompt.trim()}
              className="btn-dev-secondary py-2 px-3 lg:px-4 font-semibold disabled:opacity-50 text-sm lg:text-base"
            >
              Add
            </button>
          </div>

          {/* Existing Prompts */}
          <div className="space-y-1 lg:space-y-2">
            {formData.default_prompts.map((prompt, index) => (
              <div key={index} className="flex items-center gap-2 lg:gap-3 p-2 lg:p-3 bg-dev-tertiary rounded-lg">
                <span className="flex-1 text-sm dev-text-light">{prompt}</span>
                <button
                  type="button"
                  onClick={() => handleRemovePrompt(index)}
                  className="text-red-400 hover:text-red-300 transition-colors p-1"
                >
                  <X size={16} />
                </button>
              </div>
            ))}
            
            {formData.default_prompts.length === 0 && (
              <div className="text-center py-4 lg:py-6 text-sm dev-text-muted">
                No default prompts added yet
              </div>
            )}
          </div>
        </div>

        {/* Preview Section */}
        <div className="card-dev p-4 lg:p-6">
          <h3 className="text-base lg:text-lg font-semibold dev-heading mb-3 lg:mb-4 flex items-center gap-2">
            <Eye size={20} />
            Preview
          </h3>
          
          <div className="p-3 lg:p-4 rounded-lg border border-dev-light" style={{
            backgroundColor: formData.secondary_color + '10',
            borderColor: formData.primary_color + '30'
          }}>
            <div className="flex items-center gap-2 lg:gap-3 mb-2 lg:mb-3">
              {formData.logo_url && (
                <img
                  src={formData.logo_url}
                  alt="Brand Logo Preview"
                  className="w-6 lg:w-8 h-6 lg:h-8 object-contain"
                />
              )}
              <h4 
                className="text-sm lg:text-base font-semibold"
                style={{ 
                  color: formData.primary_color,
                  fontFamily: formData.font_family,
                  fontWeight: formData.title_style === 'bold' ? 'bold' : formData.title_style === 'semibold' ? '600' : '500'
                }}
              >
                Your Brand Video Title
              </h4>
            </div>
            <p 
              className="text-xs lg:text-sm"
              style={{ 
                color: formData.accent_color,
                fontFamily: formData.font_family,
                fontWeight: formData.body_style === 'medium' ? '500' : formData.body_style === 'light' ? '300' : '400'
              }}
            >
              This is how your video text will look with your brand guidelines applied.
            </p>
            <div className="mt-2 lg:mt-3 text-xs dev-text-muted">
              Mood: {formData.mood} • Pace: {formData.pace} • Transitions: {formData.transitions}
            </div>
            
            {/* Default Prompts Preview */}
            {formData.default_prompts.length > 0 && (
              <div className="mt-2 lg:mt-3 p-2 bg-dev-primary rounded-lg">
                <p className="text-xs font-semibold dev-text-light mb-1">Default Guidelines:</p>
                <ul className="text-xs dev-text-muted space-y-1">
                  {formData.default_prompts.slice(0, 3).map((prompt, index) => (
                    <li key={index}>• {prompt}</li>
                  ))}
                  {formData.default_prompts.length > 3 && (
                    <li>• ... and {formData.default_prompts.length - 3} more</li>
                  )}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-center lg:justify-end">
          <button
            type="submit"
            disabled={isSubmitting}
            className="btn-dev-primary py-2 lg:py-3 px-6 lg:px-8 font-semibold flex items-center gap-2 text-sm lg:text-base w-full sm:w-auto justify-center"
          >
            {isSubmitting ? (
              <>
                <LoadingSpinner size="sm" />
                Saving...
              </>
            ) : (
              <>
                <Save size={16} />
                Save Brand Guidelines
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default BrandGuidelinesSettings;