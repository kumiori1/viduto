import React, { useState } from 'react';
import { 
  User, 
  Shield, 
  Trash2, 
  CreditCard,
  HelpCircle,
  ExternalLink,
  Eye,
  EyeOff,
  Lock,
  Mail
} from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useVideoCredits } from '../hooks/useVideoCredits';
import { useSubscription } from '../hooks/useSubscription';
import { supabase } from '../lib/supabase';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';

const SettingsTab: React.FC = () => {
  const { user, signOut } = useAuth();
  const { credits } = useVideoCredits();
  const { subscription } = useSubscription();
  
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);

    if (!passwordData.newPassword || passwordData.newPassword.length < 6) {
      setAlert({ type: 'error', message: 'New password must be at least 6 characters long' });
      return;
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setAlert({ type: 'error', message: 'New passwords do not match' });
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({
        password: passwordData.newPassword
      });

      if (error) {
        setAlert({ type: 'error', message: error.message });
      } else {
        setAlert({ type: 'success', message: 'Password updated successfully!' });
        setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
        setShowChangePassword(false);
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'Failed to update password' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      return;
    }

    const confirmText = prompt('Type "DELETE" to confirm account deletion:');
    if (confirmText !== 'DELETE') {
      setAlert({ type: 'error', message: 'Account deletion cancelled' });
      return;
    }

    setIsLoading(true);
    try {
      // Here you would implement account deletion logic
      setAlert({ type: 'info', message: 'Account deletion request submitted. You will receive an email confirmation.' });
    } catch (error) {
      setAlert({ type: 'error', message: 'Failed to delete account' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4 lg:space-y-6 max-w-4xl">
      {alert && (
        <Alert
          type={alert.type}
          message={alert.message}
          onClose={() => setAlert(null)}
        />
      )}

      {/* Header */}
      <div>
        <h2 className="text-xl lg:text-2xl font-bold dev-heading">Settings</h2>
        <p className="text-sm lg:text-base dev-text">Manage your account preferences and security settings</p>
      </div>

      {/* Account Information */}
      <div className="card-dev p-4 lg:p-6">
        <h3 className="text-base lg:text-lg font-semibold dev-heading mb-3 lg:mb-4 flex items-center gap-2">
          <User size={20} />
          Account Information
        </h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 lg:gap-4">
          <div>
            <label className="block text-sm font-semibold mb-2 dev-text-light">Email Address</label>
            <input
              type="email"
              value={user?.email || ''}
              disabled
              className="w-full px-3 lg:px-4 py-2 lg:py-3 input-dev opacity-50 text-sm lg:text-base"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2 dev-text-light">Account Created</label>
            <input
              type="text"
              value={user?.created_at ? new Date(user.created_at).toLocaleDateString() : 'N/A'}
              disabled
              className="w-full px-3 lg:px-4 py-2 lg:py-3 input-dev opacity-50 text-sm lg:text-base"
            />
          </div>
        </div>

        {/* Account Stats */}
        <div className="mt-4 lg:mt-6 grid grid-cols-3 gap-3 lg:gap-4">
          <div className="bg-dev-tertiary rounded-lg p-3 lg:p-4 text-center">
            <div className="text-lg lg:text-2xl font-bold text-electric-300 mb-1">{credits?.available_credits || 0}</div>
            <div className="text-sm dev-text-muted">Available Credits</div>
          </div>
          <div className="bg-dev-tertiary rounded-lg p-3 lg:p-4 text-center">
            <div className="text-lg lg:text-2xl font-bold text-electric-300 mb-1">{credits?.total_used || 0}</div>
            <div className="text-sm dev-text-muted">Credits Used</div>
          </div>
          <div className="bg-dev-tertiary rounded-lg p-3 lg:p-4 text-center">
            <div className="text-lg lg:text-2xl font-bold text-electric-300 mb-1">
              {subscription?.subscription_status === 'active' ? 'Active' : 'None'}
            </div>
            <div className="text-sm dev-text-muted">Subscription</div>
          </div>
        </div>
      </div>

      {/* Security Settings */}
      <div className="card-dev p-4 lg:p-6">
        <h3 className="text-base lg:text-lg font-semibold dev-heading mb-3 lg:mb-4 flex items-center gap-2">
          <Shield size={20} />
          Security & Privacy
        </h3>
        
        <div className="space-y-3 lg:space-y-4">
          {/* Change Password */}
          <div>
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm lg:text-base font-semibold dev-text-light">Password</h4>
                <p className="text-sm dev-text-muted">Update your account password</p>
              </div>
              <button
                onClick={() => setShowChangePassword(!showChangePassword)}
                className="btn-dev-secondary py-2 px-3 lg:px-4 font-semibold text-sm lg:text-base"
              >
                <span className="hidden sm:inline">{showChangePassword ? 'Cancel' : 'Change Password'}</span>
                <span className="sm:hidden">{showChangePassword ? 'Cancel' : 'Change'}</span>
              </button>
            </div>

            {showChangePassword && (
              <form onSubmit={handleChangePassword} className="mt-3 lg:mt-4 space-y-3 lg:space-y-4 p-3 lg:p-4 bg-dev-tertiary rounded-lg">
                <div>
                  <label className="block text-sm font-semibold mb-2 dev-text-light">Current Password</label>
                  <div className="relative">
                    <input
                      type={showPasswords.current ? 'text' : 'password'}
                      value={passwordData.currentPassword}
                      onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
                      className="w-full px-3 lg:px-4 py-2 lg:py-3 pr-10 lg:pr-12 input-dev text-sm lg:text-base"
                      placeholder="Enter current password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPasswords(prev => ({ ...prev, current: !prev.current }))}
                      className="absolute right-2 lg:right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-blue-400"
                    >
                      {showPasswords.current ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2 dev-text-light">New Password</label>
                  <div className="relative">
                    <input
                      type={showPasswords.new ? 'text' : 'password'}
                      value={passwordData.newPassword}
                      onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
                      className="w-full px-3 lg:px-4 py-2 lg:py-3 pr-10 lg:pr-12 input-dev text-sm lg:text-base"
                      placeholder="Enter new password (min 6 characters)"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPasswords(prev => ({ ...prev, new: !prev.new }))}
                      className="absolute right-2 lg:right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-blue-400"
                    >
                      {showPasswords.new ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2 dev-text-light">Confirm New Password</label>
                  <div className="relative">
                    <input
                      type={showPasswords.confirm ? 'text' : 'password'}
                      value={passwordData.confirmPassword}
                      onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                      className="w-full px-3 lg:px-4 py-2 lg:py-3 pr-10 lg:pr-12 input-dev text-sm lg:text-base"
                      placeholder="Confirm new password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPasswords(prev => ({ ...prev, confirm: !prev.confirm }))}
                      className="absolute right-2 lg:right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-blue-400"
                    >
                      {showPasswords.confirm ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="btn-dev-primary py-2 px-3 lg:px-4 font-semibold flex items-center gap-2 text-sm lg:text-base w-full sm:w-auto justify-center"
                >
                  {isLoading ? (
                    <>
                      <LoadingSpinner size="sm" />
                      Updating...
                    </>
                  ) : (
                    <>
                      <Lock size={16} />
                      Update Password
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Billing & Subscription */}
      <div className="card-dev p-4 lg:p-6">
        <h3 className="text-base lg:text-lg font-semibold dev-heading mb-3 lg:mb-4 flex items-center gap-2">
          <CreditCard size={20} />
          Billing & Subscription
        </h3>
        
        <div className="space-y-3 lg:space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 lg:p-4 bg-dev-tertiary rounded-lg gap-2 sm:gap-0">
            <div>
              <h4 className="text-sm lg:text-base font-semibold dev-text-light">Current Plan</h4>
              <p className="text-sm dev-text-muted">
                {subscription?.subscription_status === 'active' ? 'Active Subscription' : 'Pay-as-you-go'}
              </p>
            </div>
            <button className="btn-dev-secondary py-2 px-3 lg:px-4 font-semibold text-sm lg:text-base">
              Manage Billing
            </button>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 lg:p-4 bg-dev-tertiary rounded-lg gap-2 sm:gap-0">
            <div>
              <h4 className="text-sm lg:text-base font-semibold dev-text-light">Usage This Month</h4>
              <p className="text-sm dev-text-muted">
                {credits?.total_used || 0} credits used
              </p>
            </div>
            <button className="btn-dev-ghost text-electric-300 hover:text-electric-400 text-sm lg:text-base">
              View Details
            </button>
          </div>
        </div>
      </div>

      {/* Support */}
      <div className="card-dev p-4 lg:p-6">
        <h3 className="text-base lg:text-lg font-semibold dev-heading mb-3 lg:mb-4 flex items-center gap-2">
          <HelpCircle size={20} />
          Support & Help
        </h3>
        
        <div className="space-y-3 lg:space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm lg:text-base font-semibold dev-text-light">Contact Support</h4>
              <p className="text-sm dev-text-muted">Get help with your account or videos</p>
            </div>
            <a
              href="mailto:help.vidcom@gmail.com"
              className="btn-dev-secondary py-2 px-3 lg:px-4 font-semibold inline-flex items-center gap-2 text-sm lg:text-base"
            >
              <Mail size={16} />
              <span className="hidden lg:inline">help.vidcom@gmail.com</span>
              <span className="lg:hidden">Email</span>
            </a>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm lg:text-base font-semibold dev-text-light">Documentation</h4>
              <p className="text-sm dev-text-muted">Learn how to create better videos</p>
            </div>
            <button className="btn-dev-ghost text-electric-300 hover:text-electric-400 flex items-center gap-2 text-sm lg:text-base">
              <ExternalLink size={16} />
              <span className="hidden sm:inline">View Docs</span>
              <span className="sm:hidden">Docs</span>
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm lg:text-base font-semibold dev-text-light">System Status</h4>
              <p className="text-sm dev-text-muted">Check if all services are operational</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span className="text-xs lg:text-sm text-green-400 font-medium">
                <span className="hidden sm:inline">All Systems Operational</span>
                <span className="sm:hidden">Online</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="card-dev p-4 lg:p-6 border-red-500/20">
        <h3 className="text-base lg:text-lg font-semibold text-red-400 mb-3 lg:mb-4 flex items-center gap-2">
          <Trash2 size={20} />
          Danger Zone
        </h3>
        
        <div className="space-y-3 lg:space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 lg:p-4 bg-red-500/10 border border-red-500/20 rounded-lg gap-2 sm:gap-0">
            <div>
              <h4 className="text-sm lg:text-base font-semibold text-red-400">Delete Account</h4>
              <p className="text-sm text-red-300">Permanently delete your account and all data</p>
            </div>
            <button
              onClick={handleDeleteAccount}
              disabled={isLoading}
              className="bg-red-500 hover:bg-red-600 text-white py-2 px-3 lg:px-4 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 text-sm lg:text-base"
            >
              <Trash2 size={16} />
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsTab;