import React, { useState, useRef, useEffect } from 'react';
import { Wand2, Upload, ArrowRight, User, Settings, CreditCard, Zap, Target, Sparkles, X, Eye, EyeOff, Mail, Lock, UserPlus, LogIn, Video, Clock, CheckCircle, LogOut, Menu, Plus, Send, Package, Palette, HelpCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useVideoCredits } from '../hooks/useVideoCredits';
import { useVideoChat, VideoChat as VideoChatType } from '../hooks/useVideoChat';
import { useProducts } from '../hooks/useProducts';
import { useFacebookPixel } from '../hooks/useFacebookPixel';
import { supabase } from '../lib/supabase';
import { formatPrice, getCreditPackages, getSubscriptionPlans } from '../stripe-config';
import CheckoutButton from './checkout/CheckoutButton';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';
import PricingModal from './PricingModal';
import ProductSelectionModal from './ProductSelectionModal';
import VideoChat from './VideoChat';

const HomePage: React.FC = () => {
  const { user, signIn, signUp, signOut } = useAuth();
  const navigate = useNavigate();
  const { credits } = useVideoCredits();
  const { chats, activeChat, setActiveChat, createNewChat } = useVideoChat();
  const { products } = useProducts();
  const { trackVideoRequest } = useFacebookPixel();
  
  const [prompt, setPrompt] = useState('');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('signup');
  const [showSidebar, setShowSidebar] = useState(false);
  const [showPricing, setShowPricing] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);
  const [videoLength, setVideoLength] = useState<'15' | '30' | '60'>('30');
  const [showProductSelection, setShowProductSelection] = useState(false);
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  
  // Check for selected product from localStorage on component mount
  useEffect(() => {
    const selectedProduct = localStorage.getItem('selectedProduct');
    if (selectedProduct && user) {
      try {
        const product = JSON.parse(selectedProduct);
        // Clear the stored selection
        localStorage.removeItem('selectedProduct');
        // Show alert about selected product
        setAlert({ 
          type: 'info', 
          message: `Using saved product: ${product.name}. Describe your video below.` 
        });
      } catch (error) {
        console.error('Error parsing selected product:', error);
        localStorage.removeItem('selectedProduct');
      }
    }
  }, [user]);

  // Listen for pricing modal events
  useEffect(() => {
    const handleShowPricing = () => setShowPricing(true);
    window.addEventListener('show-pricing', handleShowPricing);
    return () => window.removeEventListener('show-pricing', handleShowPricing);
  }, []);

  const enhancePrompt = async () => {
    if (!prompt.trim()) return;
    
    setIsEnhancing(true);
    try {
      const response = await fetch('/api/enhance-prompt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt: prompt.trim() }),
      });
      
      if (response.ok) {
        const { enhancedPrompt } = await response.json();
        setPrompt(enhancedPrompt);
      } else {
        throw new Error('Failed to enhance prompt');
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'Failed to enhance prompt. Please try again.' });
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAlert(null);
    
    try {
      if (authMode === 'login') {
        const { error } = await signIn(email, password);
        if (error) {
          setAlert({ type: 'error', message: error.message });
        } else {
          setShowAuth(false);
          setAlert({ type: 'success', message: 'Welcome back!' });
        }
      } else {
        const { error } = await signUp(email, password);
        if (error) {
          // Change to warning for known database issues that don't prevent account creation
          if (error.message.includes('Database error saving new user') || error.message.includes('unexpected_failure')) {
            console.warn('Signup database warning (account likely created):', error);
          } else {
            console.error('Signup error in HomePage:', error);
          }
          // Check for specific database error that indicates successful user creation
          if (error.message.includes('Database error saving new user') || error.message.includes('unexpected_failure')) {
            setAlert({ type: 'success', message: 'Account created successfully! Please sign in.' });
            setAuthMode('login');
            setEmail('');
            setPassword('');
          } else {
            setAlert({ type: 'error', message: error.message });
          }
        } else {
          setShowAuth(false);
          setAlert({ type: 'success', message: 'Welcome! Your account has been created.' });
          setEmail('');
          setPassword('');
        }
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'Unable to create account. Please try again or contact support.' });
    } finally {
      setAuthLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setImageFiles(files);
  };

  const handleRemoveImage = (index: number) => {
    setImageFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleGenerate = async () => {
    // If user is not logged in, save the request and show auth
    if (!user) {
      setShowAuth(true);
      return;
    }

    if (!prompt.trim()) {
      setAlert({ type: 'error', message: 'Please describe what video you want to create' });
      return;
    }

    // Always show product selection modal first
    setShowProductSelection(true);
  };

  const handleCreateNewProduct = async (product: any) => {
    // Check credits for new product (10 credits in demo mode)
    if (!credits || credits.available_credits < 10) {
      setAlert({ type: 'error', message: 'You need 10 credits to create a new product' });
      setShowPricing(true);
      return;
    }

    // Create video with the new product
    await createVideoWithNewProduct(product);
  };

  const handleUseExistingProduct = async (product: any) => {
    setShowProductSelection(false);
    
    // Check credits for existing product (10 credits)
    if (!credits || credits.available_credits < 10) {
      setAlert({ type: 'error', message: 'You need 10 credits to create a video with existing product' });
      setShowPricing(true);
      return;
    }

    await createVideoWithExistingProduct(product);
  };

  const createVideoWithNewProduct = async (product: any) => {
    setIsGenerating(true);
    setAlert({ type: 'info', message: 'Creating your video chat with new product...' });

    try {
      const chatDescription = `Using new product: @${product.reference_tag}\n\nDescription: ${prompt}`;
      const newChat = await createNewChat(prompt, chatDescription);
      
      if (newChat) {
        setActiveChat(newChat);
        setPrompt('');
        setAlert(null);
        
        trackVideoRequest({
          video_title: newChat.title || 'New Video',
          target_platform: 'new_product'
        });
      }
    } catch (error) {
      console.error('Error creating video with new product:', error);
      setAlert({ type: 'error', message: 'Failed to create video. Please try again.' });
    } finally {
      setIsGenerating(false);
    }
  };

  const createVideoWithExistingProduct = async (product: any) => {
    setIsGenerating(true);
    setAlert({ type: 'info', message: 'Creating your video chat with existing product...' });

    try {
      const chatDescription = `Using saved product: @${product.reference_tag}\n\nDescription: ${prompt}`;
      const newChat = await createNewChat(prompt, chatDescription);
      
      if (newChat) {
        setActiveChat(newChat);
        setPrompt('');
        setAlert(null);
        
        trackVideoRequest({
          video_title: newChat.title || 'New Video',
          target_platform: 'existing_product'
        });
      }
    } catch (error) {
      console.error('Error creating video with existing product:', error);
      setAlert({ type: 'error', message: 'Failed to create video. Please try again.' });
    } finally {
      setIsGenerating(false);
    }
  };


  const createVideoFromHomepage = async () => {
    setIsGenerating(true);
    setAlert({ type: 'info', message: 'Creating your video chat...' });

    try {
      // Create new chat with product information
      const chatDescription = `Product images uploaded\n\nDescription: ${prompt}`;
        
      const newChat = await createNewChat(prompt, chatDescription);
      
      if (newChat) {
        // Set the new chat as active immediately
        setActiveChat(newChat);
        console.log('🟢 Chat created and opened immediately:', newChat.id);
        
        // Clear the form
        setPrompt('');
        
        // Clear the alert
        setAlert(null);
        
        // Track event
        trackVideoRequest({
          video_title: newChat.title || 'New Video',
          target_platform: 'product_images'
        });
      }
    } catch (error) {
      console.error('Error creating video from homepage:', error);
      setAlert({ type: 'error', message: 'Failed to create video. Please try again.' });
    } finally {
      setIsGenerating(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'briefing':
        return <Clock className="w-3 h-3 text-yellow-400" />;
      case 'approved':
        return <CheckCircle className="w-3 h-3 text-blue-400" />;
      case 'generating':
        return <div className="w-3 h-3 rounded-full bg-blue-400 animate-pulse" />;
      case 'completed':
        return <CheckCircle className="w-3 h-3 text-green-400" />;
      case 'revision':
        return <Clock className="w-3 h-3 text-orange-400" />;
      default:
        return <div className="w-3 h-3 rounded-full bg-gray-400" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'briefing':
        return 'Briefing';
      case 'approved':
        return 'Approved';
      case 'generating':
        return 'Generating';
      case 'completed':
        return 'Completed';
      case 'revision':
        return 'Revision';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="h-screen overflow-hidden neo-cyber-bg relative touch-none flex">
      {/* Layered Cyber Aura Background */}
      <div className="cyber-aura-1"></div>
      <div className="cyber-aura-2"></div>
      <div className="cyber-aura-3"></div>
      <div className="cyber-aura-4"></div>
      <div className="cyber-aura-5"></div>

      {/* Chat Interface - Show when activeChat exists */}
      {activeChat && (
        <div className="fixed inset-0 bg-dev-primary flex flex-col z-50">
          <VideoChat
            key={`chat-${activeChat.id}-${activeChat.updated_at}`}
            chat={activeChat}
            onBack={() => setActiveChat(null)}
            onOpenMenu={() => setShowSidebar(true)}
            showSidebar={showSidebar}
            onCloseSidebar={() => setShowSidebar(false)}
            chats={chats}
            onChatSelect={(chat) => {
              setActiveChat(chat);
              setShowSidebar(false);
            }}
            credits={credits}
            setShowPricing={setShowPricing}
          />
        </div>
      )}

      {/* Mobile Menu for Non-Logged Users */}
      {showSidebar && !activeChat && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm animate-fade-in" 
            onClick={() => setShowSidebar(false)}
          ></div>
          
          {/* Dropdown Menu */}
          <div className="absolute left-0 top-0 h-full w-80 max-w-[85vw] bg-dev-secondary border-r border-dev flex flex-col shadow-2xl transform transition-transform duration-300 ease-out">
            {!user ? (
              /* Navigation Menu for Non-Logged Users */
              <div className="p-4 border-b border-dev flex-shrink-0">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                  <img 
                    src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
                    alt="VidCom AI" 
                    className="h-8 w-auto object-contain"
                  />
                  <button
                    onClick={() => setShowSidebar(false)}
                    className="btn-dev-ghost p-2 hover:bg-dev-tertiary rounded-lg transition-colors"
                  >
                    <X size={20} />
                  </button>
                </div>
                
                <nav className="space-y-2">
                  <a
                    href="/"
                    onClick={() => setShowSidebar(false)}
                    className="block py-3 px-4 text-lg font-semibold dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    Home
                  </a>

                  <a
                    href="/pricing"
                    onClick={() => setShowSidebar(false)}
                    className="block py-3 px-4 text-lg font-semibold dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    Pricing
                  </a>

                  <a
                    href="/contact"
                    onClick={() => setShowSidebar(false)}
                    className="block py-3 px-4 text-lg font-semibold dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    Contact
                  </a>

                  <a
                    href="/faq"
                    onClick={() => setShowSidebar(false)}
                    className="block py-3 px-4 text-lg font-semibold dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    FAQ
                  </a>
                </nav>
              </div>
            ) : (
              /* Full Menu for Logged Users */
              <>
                {/* Header */}
                <div className="p-4 border-b border-dev flex-shrink-0">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <img 
                        src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
                        alt="VidCom AI" 
                        className="h-8 w-auto object-contain"
                      />
                    </div>
                    <button
                      onClick={() => setShowSidebar(false)}
                      className="btn-dev-ghost p-2 hover:bg-dev-tertiary rounded-lg transition-colors"
                    >
                      <X size={20} />
                    </button>
                  </div>
                  
                  {/* User Info */}
                  <div className="flex items-center gap-3 p-3 card-dev">
                    <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                      <User size={14} className="text-electric-300" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm dev-text-light font-medium truncate">{user.email}</p>
                      <p className="text-xs text-electric-300">{credits?.available_credits || 0} credits</p>
                    </div>
                  </div>
                </div>

                {/* New Project Button */}
                <div className="p-4 flex-shrink-0">
                  <button
                    onClick={() => {
                      setPrompt('');
                      setShowSidebar(false);
                    }}
                    className="w-full py-3 px-4 bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <Plus size={16} />
                    New Project
                  </button>
                </div>

                {/* Recent Chats */}
                <div className="flex-1 min-h-0 overflow-hidden px-4 pb-4">
                  <div className="mb-3">
                    <h3 className="text-sm font-medium dev-text-light flex items-center gap-2">
                      <Video size={16} className="text-electric-300" />
                      Recent Projects
                    </h3>
                  </div>
                  
                  <div className="h-full overflow-y-auto space-y-2">
                    {chats.length > 0 ? (
                      chats.map((chat) => (
                        <button
                          key={chat.id}
                          onClick={() => {
                            if (user) {
                              setActiveChat(chat);
                              setShowSidebar(false);
                            }
                          }}
                          className="w-full text-left p-3 rounded-md transition-colors card-dev hover:bg-dev-tertiary"
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <Video size={12} className="text-electric-400" />
                            <span className="text-sm font-medium truncate dev-text">{chat.title}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(chat.status)}
                            <span className="text-xs dev-text-muted">{getStatusText(chat.status)}</span>
                          </div>
                          <div className="text-xs dev-text-muted mt-1">
                            {new Date(chat.created_at).toLocaleDateString()}
                          </div>
                        </button>
                      ))
                    ) : (
                      <div className="text-center py-4 px-3 bg-dev-tertiary rounded-lg border border-dev-light">
                        <Video size={24} className="text-gray-500 mx-auto mb-2" />
                        <p className="text-xs dev-text-muted">No projects yet</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Menu */}
                <div className="p-4 border-t border-dev space-y-1 flex-shrink-0">
                  <button
                    onClick={() => {
                      navigate('/dashboard');
                      setTimeout(() => {
                        const event = new CustomEvent('setDashboardTab', { detail: 'products' });
                        window.dispatchEvent(event);
                      }, 100);
                      setShowSidebar(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    <Package size={16} />
                    My Products
                  </button>
                  <button
                    onClick={() => {
                      navigate('/dashboard');
                      setTimeout(() => {
                        const event = new CustomEvent('setDashboardTab', { detail: 'brand' });
                        window.dispatchEvent(event);
                      }, 100);
                      setShowSidebar(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    <Palette size={16} />
                    Brand Guidelines
                  </button>
                  <button
                    onClick={() => {
                      navigate('/dashboard');
                      setTimeout(() => {
                        const event = new CustomEvent('setDashboardTab', { detail: 'subscription' });
                        window.dispatchEvent(event);
                      }, 100);
                      setShowSidebar(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    <CreditCard size={16} />
                    Manage Subscription
                  </button>
                  <button
                    onClick={() => {
                      navigate('/dashboard');
                      setTimeout(() => {
                        const event = new CustomEvent('setDashboardTab', { detail: 'settings' });
                        window.dispatchEvent(event);
                      }, 100);
                      setShowSidebar(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    <Settings size={16} />
                    Settings
                  </button>
                  <button
                    onClick={signOut}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-gray-800 rounded-lg transition-all duration-200"
                  >
                    <LogOut size={16} />
                    Log Out
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Homepage Content - Show when no activeChat */}
      {!activeChat && (
        <div className="flex-1 flex flex-col overflow-x-hidden w-full">
          {/* Mobile Sidebar Menu */}
          {showSidebar && !activeChat && user && (
            <div className="fixed inset-0 z-50">
              {/* Backdrop */}
              <div 
                className="absolute inset-0 bg-black/50 backdrop-blur-sm" 
                onClick={() => setShowSidebar(false)}
              />
              
              {/* Sidebar */}
              <div className="absolute left-0 top-0 h-full w-80 max-w-[85vw] bg-dev-secondary border-r border-dev flex flex-col shadow-2xl transform transition-transform duration-300 ease-out">
                {/* Header */}
                <div className="p-4 border-b border-dev flex-shrink-0">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <img 
                        src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
                        alt="VidCom AI" 
                        className="h-8 w-auto object-contain"
                      />
                    </div>
                    <button
                      onClick={() => setShowSidebar(false)}
                      className="btn-dev-ghost p-2 hover:bg-dev-tertiary rounded-lg transition-colors"
                    >
                      <X size={20} />
                    </button>
                  </div>
                  
                  {/* User Info */}
                  <div className="flex items-center gap-3 p-3 card-dev">
                    <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                      <User size={14} className="text-electric-300" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm dev-text-light font-medium truncate">{user.email}</p>
                      <p className="text-xs text-electric-300">{credits?.available_credits || 0} credits</p>
                    </div>
                  </div>
                </div>

                {/* New Project Button */}
                <div className="p-4 flex-shrink-0">
                  <button
                    onClick={() => {
                      setPrompt('');
                      setShowSidebar(false);
                    }}
                    className="w-full py-3 px-4 bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <Plus size={16} />
                    New Project
                  </button>
                </div>

                {/* Recent Chats */}
                <div className="flex-1 min-h-0 overflow-hidden px-4 pb-4">
                  <div className="mb-3">
                    <h3 className="text-sm font-medium dev-text-light flex items-center gap-2">
                      <Video size={16} className="text-electric-300" />
                      Recent Projects
                    </h3>
                  </div>
                  
                  <div className="h-full overflow-y-auto space-y-2">
                    {chats.length > 0 ? (
                      chats.map((chat) => (
                        <button
                          key={chat.id}
                          onClick={() => {
                            if (user) {
                              setActiveChat(chat);
                              setShowSidebar(false);
                            }
                          }}
                          className="w-full text-left p-3 rounded-md transition-colors card-dev hover:bg-dev-tertiary"
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <Video size={12} className="text-electric-400" />
                            <span className="text-sm font-medium truncate dev-text">{chat.title}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(chat.status)}
                            <span className="text-xs dev-text-muted">{getStatusText(chat.status)}</span>
                          </div>
                          <div className="text-xs dev-text-muted mt-1">
                            {new Date(chat.created_at).toLocaleDateString()}
                          </div>
                        </button>
                      ))
                    ) : (
                      <div className="text-center py-4 px-3 bg-dev-tertiary rounded-lg border border-dev-light">
                        <Video size={24} className="text-gray-500 mx-auto mb-2" />
                        <p className="text-xs dev-text-muted">No projects yet</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Menu */}
                <div className="p-4 border-t border-dev space-y-1 flex-shrink-0">
                  <button
                    onClick={() => {
                      navigate('/dashboard');
                      setTimeout(() => {
                        const event = new CustomEvent('setDashboardTab', { detail: 'products' });
                        window.dispatchEvent(event);
                      }, 100);
                      setShowSidebar(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    <Package size={16} />
                    My Products
                  </button>
                  <button
                    onClick={() => {
                      navigate('/dashboard');
                      setTimeout(() => {
                        const event = new CustomEvent('setDashboardTab', { detail: 'brand' });
                        window.dispatchEvent(event);
                      }, 100);
                      setShowSidebar(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    <Palette size={16} />
                    Brand Guidelines
                  </button>
                  <button
                    onClick={() => {
                      navigate('/dashboard');
                      setTimeout(() => {
                        const event = new CustomEvent('setDashboardTab', { detail: 'subscription' });
                        window.dispatchEvent(event);
                      }, 100);
                      setShowSidebar(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    <CreditCard size={16} />
                    Manage Subscription
                  </button>
                  <button
                    onClick={() => {
                      navigate('/dashboard');
                      setTimeout(() => {
                        const event = new CustomEvent('setDashboardTab', { detail: 'settings' });
                        window.dispatchEvent(event);
                      }, 100);
                      setShowSidebar(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    <Settings size={16} />
                    Settings
                  </button>
                  <button
                    onClick={signOut}
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-dev-tertiary rounded-lg transition-all duration-200"
                  >
                    <LogOut size={16} />
                    Log Out
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Header - Mobile Only Shows Menu Button When Logged In */}
          <header className="relative z-10 flex items-center justify-between p-4 lg:p-6 flex-shrink-0">
            <div className="p-4 flex-shrink-0">
              <div className="flex items-center gap-3">
                <a href="/" className="cursor-pointer">
                  <img 
                    src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
                    alt="VidCom" 
                    className="h-4 lg:h-6 w-auto object-contain hover:opacity-80 transition-opacity"
                  />
                </a>
                <span className="text-xl lg:text-2xl font-bold text-black heading-cyber">
                  VidCom
                </span>
              </div>
              
              {/* Navigation Links - Desktop Only */}
              {!user && (
                <nav className="hidden lg:flex items-center gap-6 ml-8">
                  <button
                    onClick={() => window.location.href = '/pricing'}
                    className="text-black hover:text-electric-600 transition-all duration-200 text-base font-bold"
                  >
                    Pricing
                  </button>
                  <button
                    onClick={() => window.location.href = '/faq'}
                    className="text-black hover:text-electric-600 transition-all duration-200 text-base font-bold"
                  >
                    FAQ
                  </button>
                  <button
                    onClick={() => window.location.href = '/contact'}
                    className="text-black hover:text-electric-600 transition-all duration-200 text-base font-bold"
                  >
                    Contact
                  </button>
                </nav>
              )}
            </div>

            <div className="flex items-center gap-2 lg:gap-4">
              {/* Menu Button for Logged In Users */}
              {user && (
                <button
                  className="p-3 hover:bg-white/10 rounded-xl transition-all duration-200 min-w-[44px] min-h-[44px] flex items-center justify-center"
                  onClick={() => {
                    console.log('Menu button clicked!');
                    setShowSidebar(true);
                  }}
                >
                  <Menu className="w-5 h-5 text-gray-900 hover:text-electric-600" />
                </button>
              )}
              
              {!user && (
                <>
                  <button
                    className="block py-3 px-4 text-lg font-semibold dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-xl transition-all duration-200"
                    onClick={() => setShowAuth(true)}
                  >
                    Start Creating
                  </button>
                  
                  {/* Menu Button - Right side */}
                  <button
                    className="p-3 hover:bg-white/10 rounded-xl transition-all duration-200 min-w-[44px] min-h-[44px] flex items-center justify-center"
                    onClick={() => {
                      console.log('Menu button clicked for non-logged users!');
                      // On desktop, show auth modal instead of sidebar
                      if (window.innerWidth >= 1024) {
                        setShowAuth(true);
                      } else {
                        setShowSidebar(true);
                      }
                    }}
                  >
                    <Menu className="w-5 h-5 text-gray-900 hover:text-electric-600" />
                  </button>
                </>
              )}
            </div>
          </header>

          {/* Main Content - Clean Mobile Layout */}
          <main className="relative z-10 flex flex-col items-center px-3 lg:px-5 flex-1 min-h-0 py-2 lg:py-4 justify-center overflow-y-auto overflow-x-hidden w-full">
            {/* Hero Section */}
            <div className="text-center mb-3 lg:mb-4 max-w-4xl flex-shrink-0 w-full overflow-x-hidden">
              <h1 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold mb-2 lg:mb-3 text-gray-900 px-4 animate-fade-cyber text-balance leading-tight">
                Your Product. Your Video. One Chat.
              </h1>
              <p className="text-sm sm:text-base lg:text-lg text-gray-700 font-normal max-w-2xl mx-auto px-4 animate-fade-cyber text-balance mb-4 lg:mb-6" style={{ animationDelay: '0.1s' }}>
                Turn your product images to short-form marketing videos by chatting with AI.
              </p>
            </div>

            {/* Main Interface Card */}
            <div className="w-full max-w-2xl card-cyber p-3 lg:p-4 space-y-3 lg:space-y-4 mx-4 lg:mx-0 flex-shrink-0 animate-slide-cyber overflow-x-hidden">
              {/* Prompt Input */}
              <div>
                <div className="relative">
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Describe the video you want to create..."
                    rows={3}
                    className="w-full h-32 lg:h-36 input-cyber pl-32 pr-20 text-base lg:text-lg resize-none overflow-y-auto"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        if (prompt.trim() && !isGenerating) {
                          handleGenerate();
                        }
                      }
                    }}
                  />
                  {/* Enhance Button - Left Side */}
                  <button
                    onClick={enhancePrompt}
                    disabled={!prompt.trim() || isEnhancing}
                    className="absolute left-3 bottom-3 px-3 py-2 text-xs font-medium text-electric-500 hover:text-electric-600 disabled:text-gray-400 disabled:cursor-not-allowed rounded-lg transition-all duration-200 hover:bg-electric-300/10 bg-white/80 backdrop-blur-sm border border-electric-200/50"
                  >
                    {isEnhancing ? (
                      <LoadingSpinner size="sm" />
                    ) : (
                      'Enhance with AI'
                    )}
                  </button>
                  {/* Send Button */}
                  <button
                    onClick={handleGenerate}
                    disabled={isGenerating || !prompt.trim()}
                    className="absolute right-3 bottom-3 p-2 bg-lavender-500 hover:bg-lavender-600 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-all duration-200 hover:scale-105 shadow-lg"
                    title="Generate video"
                  >
                    {isGenerating ? (
                      <LoadingSpinner size="sm" />
                    ) : (
                      <Send size={16} />
                    )}
                  </button>
                </div>
              </div>

              {/* Free Video Text */}
              <div className="text-center mt-4">
                <p className="text-lg font-bold text-gray-900 heading-cyber">
                  First video is FREE!
                </p>
                <p className="text-sm text-gray-600 text-cyber">
                  No credit card needed.
                </p>
              </div>
            </div>
          </main>

          {/* Auth Modal */}
          {showAuth && (
            <div className="fixed inset-0 modal-cyber-backdrop flex items-center justify-center p-4 z-50 overflow-x-hidden">
              <div className="modal-cyber-content p-6 lg:p-8 w-full max-w-md">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h2 className="text-xl lg:text-2xl font-bold text-black mb-1 heading-cyber">
                      {authMode === 'login' ? 'Welcome Back' : 'Get Started'}
                    </h2>
                    <p className="text-sm text-cyber-soft">
                      {authMode === 'login' ? 'Sign in to your account' : 'Create your account to start creating videos'}
                    </p>
                  </div>
                  <button
                    onClick={() => setShowAuth(false)}
                    className="text-gray-500 hover:text-electric-600 transition-all duration-200 p-2 hover:bg-electric-300/10 rounded-xl hover:scale-105"
                  >
                    <X size={20} />
                  </button>
                </div>

                {alert && (
                  <Alert
                    type={alert.type}
                    message={alert.message}
                    onClose={() => setAlert(null)}
                    className="mb-4"
                  />
                )}

                <form onSubmit={handleAuth} className="space-y-4">
                  <div>
                    <div className="relative">
                      <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 flex items-center justify-center">
                        <Mail className="text-electric-600" size={14} />
                      </div>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Email address"
                        className="w-full pl-14 pr-4 py-3.5 input-cyber text-base"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="relative">
                      <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 flex items-center justify-center">
                        <Lock className="text-electric-600" size={14} />
                      </div>
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Password"
                        className="w-full pl-14 pr-14 py-3.5 input-cyber text-base"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-electric-600 transition-colors"
                      >
                        {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={authLoading}
                    className="w-full py-3.5 px-4 bg-gradient-to-r from-lavender-500 to-lavender-600 hover:from-lavender-600 hover:to-lavender-700 disabled:from-gray-400 disabled:to-gray-500 text-white rounded-xl font-semibold transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:scale-105 disabled:transform-none disabled:cursor-not-allowed text-base"
                  >
                    {authLoading ? (
                      <>
                        <LoadingSpinner size="sm" />
                        {authMode === 'login' ? 'Signing In...' : 'Creating Account...'}
                      </>
                    ) : (
                      <>
                        {authMode === 'login' ? <LogIn size={16} /> : <UserPlus size={16} />}
                        {authMode === 'login' ? 'Sign In' : 'Create Account'}
                      </>
                    )}
                  </button>
                </form>

                <div className="mt-5 text-center">
                  <button
                    onClick={() => setAuthMode(authMode === 'login' ? 'signup' : 'login')}
                    className="text-cyber-soft hover:text-electric-600 transition-all duration-200 text-sm font-medium"
                  >
                    {authMode === 'login' ? "Don't Have an Account? Sign Up" : "Already Have an Account? Sign In"}
                  </button>
                </div>
              </div>
            </div>
          )}

          {showProductSelection && (
            <ProductSelectionModal
              isOpen={showProductSelection}
              onClose={() => setShowProductSelection(false)}
              onSelectNewProduct={handleCreateNewProduct}
              onSelectExistingProduct={handleUseExistingProduct}
              userCredits={credits?.available_credits || 0}
            />
          )}

          {/* Pricing Modal */}
          {showPricing && (
            <div className="fixed inset-0 modal-cyber-backdrop flex items-center justify-center p-4 lg:p-6 z-50 overflow-hidden overflow-x-hidden">
              <div className="modal-cyber-content p-4 lg:p-8 w-full max-w-7xl h-[95vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-6 lg:mb-8">
                  <div>
                    <h2 className="text-xl lg:text-3xl font-bold text-black mb-2 heading-cyber-large">Choose Your Plan</h2>
                    <p className="text-sm lg:text-base text-cyber-soft font-normal">Start Creating Professional Product Videos Today</p>
                  </div>
                  <button
                    onClick={() => setShowPricing(false)}
                    className="text-gray-500 hover:text-electric-600 transition-all duration-200 p-3 hover:bg-electric-300/10 rounded-2xl hover:scale-105"
                  >
                    <X size={24} />
                  </button>
                </div>
              </div>
            </div>
          )}

          <ProductSelectionModal
            isOpen={showProductSelection}
            onClose={() => setShowProductSelection(false)}
            onSelectNewProduct={handleCreateNewProduct}
            onSelectExistingProduct={handleUseExistingProduct}
            userCredits={credits?.available_credits || 0}
          />

          <PricingModal
            isOpen={showPricing}
            onClose={() => setShowPricing(false)}
            onAuthRequired={() => setShowAuth(true)}
          />
        </div>
      )}
    </div>
  );
};

export default HomePage;