import React, { useState } from 'react';
import { Crown, Check, Star, Zap, ArrowRight, Shield, Clock, Sparkles, CreditCard, Home } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useSubscription } from '../hooks/useSubscription';
import { useVideoCredits } from '../hooks/useVideoCredits';
import { formatPrice, getCreditPackages, getSubscriptionPlans } from '../stripe-config';
import CheckoutButton from './checkout/CheckoutButton';
import SEOHead from './SEOHead';
import { PricingSchema } from './StructuredData';

const PricingPage: React.FC = () => {
  const { user } = useAuth();
  const { subscription, hasActiveSubscription } = useSubscription();
  const { credits } = useVideoCredits();
  const [activeTab, setActiveTab] = useState<'subscriptions' | 'credits'>('subscriptions');
  const [showAuth, setShowAuth] = useState(false);

  const subscriptionPlans = getSubscriptionPlans();
  const creditPackages = getCreditPackages();

  return (
    <div className="min-h-screen neo-cyber-bg relative">
      <SEOHead
        title="Pricing Plans | VidCom AI - AI Video Generation Packages"
        description="Choose the perfect VidCom AI plan for your business. Monthly subscriptions starting at $29 or flexible credit packages. Create professional product videos with AI."
        keywords="VidCom AI pricing, AI video generation plans, video marketing packages, subscription plans, video credits"
        canonicalUrl="https://vidcom.ai/pricing"
        structuredData={PricingSchema}
      />

      {/* Background Auras */}
      <div className="cyber-aura-1"></div>
      <div className="cyber-aura-2"></div>
      <div className="cyber-aura-3"></div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between p-4 lg:p-6">
        <div className="flex items-center gap-6">
          <img 
            src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
            alt="VidCom AI" 
            className="h-16 lg:h-20 w-auto object-contain"
          />
          
          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6">
            <a
              href="/"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              Home
            </a>
            <a
              href="/faq"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              FAQ
            </a>
            <a
              href="/contact"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              Contact
            </a>
            <span className="text-electric-600 font-semibold text-base">
              Pricing
            </span>
          </nav>
        </div>

        <div className="flex items-center gap-3">
          {!user ? (
            <>
              <a
                href="/login"
                className="text-black hover:text-electric-600 transition-all duration-200 text-sm lg:text-base font-semibold px-3 lg:px-4 py-2 rounded-xl hover:bg-electric-100/50"
              >
                Sign In
              </a>
              <a
                href="/signup"
                className="btn-cyber-primary py-2 px-4 lg:px-6 font-semibold text-sm lg:text-base shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Get Started
              </a>
            </>
          ) : (
            <a
              href="/dashboard"
              className="btn-cyber-primary py-2 px-4 font-semibold flex items-center gap-2 text-sm lg:text-base"
            >
              <Home size={16} />
              Dashboard
            </a>
          )}
        </div>
      </header>

      <div className="relative z-10 max-w-7xl mx-auto px-4 py-8 lg:py-12">
        {/* Page Header */}
        <div className="text-center mb-8 lg:mb-12">
          <h1 className="text-3xl lg:text-5xl font-bold text-gray-900 mb-4 heading-cyber-large">
            Choose Your Perfect Plan
          </h1>
          <p className="text-lg lg:text-xl text-gray-700 max-w-3xl mx-auto text-cyber-large">
            Start creating professional product videos with AI. Monthly subscriptions or flexible credit packages.
          </p>
          
          {/* Current Status */}
          {user && (
            <div className="mt-6 inline-flex items-center gap-2 bg-electric-100 rounded-2xl px-4 py-2 border border-electric-200">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-sm font-medium text-electric-700">
                {hasActiveSubscription() ? 'Active Subscription' : `${credits?.available_credits || 0} Credits Available`}
              </span>
            </div>
          )}
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8 lg:mb-12">
          <div className="text-center">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2 heading-cyber">
              Monthly Subscription Plans
            </h2>
            <p className="text-base lg:text-lg text-gray-700 text-cyber-large">
              Choose the perfect plan for your video creation needs
            </p>
          </div>
        </div>

        {/* Subscription Plans */}
        <section>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 mb-12">
            {subscriptionPlans.map((plan, index) => (
              <div 
                key={plan.id}
                className={`relative card-cyber p-6 lg:p-8 transition-all duration-300 hover:scale-105 ${
                  index === 1 ? 'border-electric-400/50 shadow-lg shadow-electric-400/20' : ''
                }`}
              >
                {/* Popular Badge */}
                {index === 1 && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-electric-500 to-electric-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg">
                      <Star size={14} />
                      Most Popular
                    </span>
                  </div>
                )}

                {/* Plan Header */}
                <div className="text-center mb-6">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 ${
                    index === 0 ? 'bg-gradient-to-br from-blue-500 to-blue-600' :
                    index === 1 ? 'bg-gradient-to-br from-electric-500 to-electric-600' :
                    index === 2 ? 'bg-gradient-to-br from-purple-500 to-purple-600' :
                    'bg-gradient-to-br from-orange-500 to-orange-600'
                  } shadow-lg`}>
                    <Crown className="text-white" size={24} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2 heading-cyber">
                    {plan.name}
                  </h3>
                  <div className="mb-3">
                    <span className="text-3xl font-bold text-gray-900">
                      {formatPrice(plan.price, plan.currency)}
                    </span>
                    <span className="text-gray-600">/month</span>
                  </div>
                  <p className="text-sm text-electric-600 font-semibold bg-electric-100 inline-block px-3 py-1 rounded-lg">
                    {plan.credits} credits monthly
                  </p>
                </div>

                {/* Key Stats */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-lg font-bold text-gray-900">{plan.products}</div>
                    <div className="text-xs text-gray-600">Products</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-lg font-bold text-gray-900">{plan.videos}</div>
                    <div className="text-xs text-gray-600">Videos</div>
                  </div>
                </div>

                {/* Features */}
                <ul className="space-y-2 mb-8">
                  {plan.features.slice(0, 5).map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                <CheckoutButton
                  priceId={plan.priceId}
                  productName={plan.name}
                  mode={plan.mode}
                  onAuthRequired={() => setShowAuth(true)}
                  className={`w-full py-4 px-6 font-bold text-base transition-all duration-200 hover:scale-105 rounded-2xl ${
                    index === 1
                      ? 'bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white shadow-lg shadow-electric-500/25'
                      : 'btn-cyber-outline'
                  }`}
                >
                  <span className="flex items-center justify-center gap-2">
                    {index === 1 ? 'Start Creating' : 'Get Started'}
                    <ArrowRight size={16} />
                  </span>
                </CheckoutButton>
              </div>
            ))}
          </div>

          {/* Subscription Benefits */}
          <div className="card-cyber p-8 mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center heading-cyber">
              Why Choose a Monthly Subscription?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Shield className="text-white" size={24} />
                </div>
                <h3 className="font-bold text-gray-900 mb-3 heading-cyber">Best Value</h3>
                <p className="text-gray-700 text-cyber">
                  Lower cost per video with monthly credits and priority processing
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-electric-500 to-electric-600 flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Clock className="text-white" size={24} />
                </div>
                <h3 className="font-bold text-gray-900 mb-3 heading-cyber">Never Run Out</h3>
                <p className="text-gray-700 text-cyber">
                  Fresh credits every month automatically, no need to worry about running out
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Star className="text-white" size={24} />
                </div>
                <h3 className="font-bold text-gray-900 mb-3 heading-cyber">Priority Support</h3>
                <p className="text-gray-700 text-cyber">
                  Faster processing, dedicated support, and exclusive features
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <div className="mt-16 card-cyber p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center heading-cyber">
            Frequently Asked Questions
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-bold text-gray-900 mb-2">Can I cancel anytime?</h3>
              <p className="text-gray-700 text-sm">Yes! Cancel your subscription anytime. You'll keep access until the end of your billing period.</p>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-2">Do credits expire?</h3>
              <p className="text-gray-700 text-sm">No, credits never expire. Use them whenever you need to create videos.</p>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-2">Can I upgrade my plan?</h3>
              <p className="text-gray-700 text-sm">Yes! Upgrade or downgrade your plan anytime from your dashboard.</p>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-2">What's included in each video?</h3>
              <p className="text-gray-700 text-sm">Professional editing, music, voiceover, and optimization for your chosen platform.</p>
            </div>
          </div>
          
          <div className="text-center mt-8">
            <a
              href="/faq"
              className="btn-cyber-secondary py-3 px-6 font-semibold inline-flex items-center gap-2"
            >
              View All FAQs
              <ArrowRight size={16} />
            </a>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center card-cyber p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 heading-cyber">
            Ready to Start Creating?
          </h2>
          <p className="text-gray-700 mb-6 text-cyber-large">
            Join thousands of businesses creating professional product videos with AI
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href={user ? "/dashboard" : "/signup"}
              className="btn-cyber-primary py-3 px-6 font-semibold inline-flex items-center justify-center gap-2 text-base"
            >
              <Sparkles size={16} />
              {user ? "Go to Dashboard" : "Start Free Trial"}
            </a>
            <a
              href="/contact"
              className="btn-cyber-secondary py-3 px-6 font-semibold inline-flex items-center justify-center gap-2 text-base"
            >
              <CreditCard size={16} />
              Contact Sales
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PricingPage;