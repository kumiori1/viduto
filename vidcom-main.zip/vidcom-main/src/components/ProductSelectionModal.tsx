import React, { useState } from 'react';
import { Package, Plus, X, ArrowRight, Sparkles, Upload, Save, Camera, Grid3X3, ChevronDown, ChevronUp } from 'lucide-react';
import { useProducts, Product, CreateProductData } from '../hooks/useProducts';
import { supabase } from '../lib/supabase';
import { isSupabaseConfigured } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';

interface ProductSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectNewProduct: (product: Product) => void;
  onSelectExistingProduct: (product: Product) => void;
  userCredits: number;
}

const ProductSelectionModal: React.FC<ProductSelectionModalProps> = ({
  isOpen,
  onClose,
  onSelectNewProduct,
  onSelectExistingProduct,
  userCredits
}) => {
  const { user } = useAuth();
  const { products, loading, canCreateProduct, getProductLimits, createProduct } = useProducts();
  const [formData, setFormData] = useState({
    name: '',
    imageFiles: [] as File[]
  });
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showExistingProducts, setShowExistingProducts] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  if (!isOpen) return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    console.log('🔵 handleImageUpload called');
    const files = e.target.files;
    console.log('🔵 Files from input:', files);
    if (!files || files.length === 0) {
      console.log('🔴 No files selected');
      return;
    }

    const fileArray = Array.from(files);
    console.log('🔵 Files selected:', fileArray.length);

    // Validation
    if (fileArray.length > 10) {
      setAlert({ type: 'error', message: 'Maximum 10 images allowed per product' });
      return;
    }
    
    for (const file of fileArray) {
      if (file.size > 10 * 1024 * 1024) {
        setAlert({ type: 'error', message: `File ${file.name} is larger than 10MB` });
        return;
      }
      
      if (!file.type.startsWith('image/')) {
        setAlert({ type: 'error', message: `File ${file.name} is not an image` });
        return;
      }
    }
    
    // Update state
    console.log('🔵 Updating formData with files:', fileArray.length);
    setFormData(prev => ({ ...prev, imageFiles: fileArray }));
    console.log('🔵 Updated formData with', fileArray.length, 'files');
    
    // Clear the input value so the same files can be selected again
    e.target.value = '';
  };

  const handleRemoveImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      imageFiles: prev.imageFiles.filter((_, i) => i !== index)
    }));
  };

  const uploadImagesToSupabase = async (files: File[]): Promise<string[]> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    const uploadedUrls: string[] = [];

    try {
      for (const file of files) {
        const timestamp = Date.now();
        const randomString = Math.random().toString(36).substring(2, 15);
        const fileExtension = file.name.split('.').pop();
        const uniqueFileName = `products/${user.id}/${timestamp}_${randomString}.${fileExtension}`;

        const { data, error } = await supabase.storage
          .from('video-request-images')
          .upload(uniqueFileName, file, {
            cacheControl: '3600',
            upsert: false
          });

        if (error) {
          throw new Error(`Error uploading ${file.name}: ${error.message}`);
        }

        const { data: urlData } = supabase.storage
          .from('video-request-images')
          .getPublicUrl(uniqueFileName);

        if (urlData?.publicUrl) {
          uploadedUrls.push(urlData.publicUrl);
        } else {
          throw new Error(`Failed to get public URL for ${file.name}`);
        }
      }

      return uploadedUrls;
    } catch (error) {
      console.error('Error in uploadImagesToSupabase:', error);
      throw error;
    }
  };

  const handleCreateProduct = async () => {
    setAlert(null);

    if (!formData.name.trim()) {
      setAlert({ type: 'error', message: 'Product name is required' });
      return;
    }

    if (!formData.imageFiles?.length) {
      setAlert({ type: 'error', message: 'At least one product image is required' });
      return;
    }

    if (userCredits < 10) {
      setAlert({ type: 'error', message: 'You need 10 credits to create a new product' });
      return;
    }

    console.log('🔵 Creating product with:', {
      name: formData.name,
      imageCount: formData.imageFiles.length,
      userCredits
    });

    setIsSubmitting(true);

    try {
      setAlert({ type: 'info', message: 'Uploading images...' });
      
      // In demo mode, use placeholder images
      const imageUrls = formData.imageFiles.map((_, index) => 
        `https://images.pexels.com/photos/${90946 + index}/pexels-photo-${90946 + index}.jpeg?auto=compress&cs=tinysrgb&w=400`
      );
      const imageNames = formData.imageFiles.map(f => f.name);

      const productData = {
        name: formData.name,
        description: '',
        reference_tag: formData.name.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, ''),
        image_urls: imageUrls,
        image_names: imageNames,
        metadata: {}
      };

      const newProduct = await createProduct(productData);
      
      if (newProduct) {
        setAlert({ type: 'success', message: 'Product created successfully!' });
        
        setTimeout(() => {
          onClose();
          onSelectNewProduct(newProduct);
        }, 1000);
      }

    } catch (error) {
      console.error('Error creating product:', error);
      setAlert({ 
        type: 'error', 
        message: error instanceof Error ? error.message : 'Failed to create product' 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSelectExisting = () => {
    if (!selectedProduct) {
      setAlert({ type: 'error', message: 'Please select a product first' });
      return;
    }

    if (userCredits < 10) {
      setAlert({ type: 'error', message: 'You need 10 credits to create a video with existing product' });
      return;
    }

    onSelectExistingProduct(selectedProduct);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xl grid place-items-center z-50 p-4 sm:p-6" style={{
      paddingLeft: 'max(16px, env(safe-area-inset-left))',
      paddingRight: 'max(16px, env(safe-area-inset-right))',
      paddingTop: 'max(16px, env(safe-area-inset-top))',
      paddingBottom: 'max(16px, env(safe-area-inset-bottom))'
    }}>
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg max-h-[calc(100vh-32px)] overflow-hidden flex flex-col box-border">
        
        {/* Header - Fixed */}
        <div className="px-3 py-2 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-base font-bold text-gray-900">Add Your Product</h1>
              <p className="text-xs text-gray-600">Upload images and create</p>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 rounded-lg transition-colors flex-shrink-0"
            >
              <X size={16} className="text-gray-500" />
            </button>
          </div>
        </div>

        {/* Alert - Fixed */}
        {alert && (
          <div className="px-3 pt-2 flex-shrink-0">
            <Alert
              type={alert.type}
              message={alert.message}
              onClose={() => setAlert(null)}
            />
          </div>
        )}

        {/* Main Content - Scrollable */}
        <div className="flex-1 min-h-0 px-3 py-2 space-y-2 overflow-y-auto">
          
          {/* Primary Option: Create New Product */}
          <div className="space-y-2">
            
            {/* Image Upload */}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Images
              </label>
              
              {/* Upload Area */}
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center hover:border-electric-400 hover:bg-electric-50/30 transition-all duration-200 cursor-pointer group w-full box-border">
                <input
                  type="file"
                  id="product-images"
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                  disabled={isSubmitting}
                  className="hidden"
                />
                <label htmlFor="product-images" className="cursor-pointer block">
                  <div className="w-6 h-6 mx-auto mb-1 rounded-lg bg-electric-100 flex items-center justify-center group-hover:bg-electric-200 transition-colors">
                    <Camera className="w-3 h-3 text-electric-600" />
                  </div>
                  <h3 className="text-sm font-semibold text-gray-900">Upload Photos</h3>
                  <p className="text-xs text-gray-500">PNG, JPG up to 10MB</p>
                </label>
              </div>

              
              {/* Debug Info */}
              {formData.imageFiles && formData.imageFiles.length > 0 && (
                <div className="mt-2 text-xs text-green-600 font-medium">
                  ✓ {formData.imageFiles.length} image{formData.imageFiles.length !== 1 ? 's' : ''} selected
                </div>
              )}
              
              {/* Image Grid */}
              {formData.imageFiles && formData.imageFiles.length > 0 && (
                <div className="mt-3 space-y-2">
                  <div className="grid grid-cols-8 gap-0.5">
                    {formData.imageFiles.map((file, index) => (
                      <div key={index} className="relative inline-block w-full">
                        <div className="aspect-square bg-gray-100 rounded overflow-hidden border border-gray-200 w-full relative">
                          <img
                            src={URL.createObjectURL(file)}
                            alt={`Product ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                          <button
                            type="button"
                            onClick={() => handleRemoveImage(index)}
                            className="absolute top-1 right-1 w-4 h-4 min-w-4 min-h-4 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center transition-all duration-200 shadow-sm opacity-80 hover:opacity-100"
                            style={{ fontSize: '8px', lineHeight: '1' }}
                          >
                            <X size={8} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Product Details */}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ 
                  ...prev, 
                  name: e.target.value,
                  reference_tag: e.target.value.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '')
                }))}
                placeholder="e.g., Headphones Pro"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-electric-500 focus:border-electric-500 transition-all box-border text-gray-900 bg-white"
               style={{ position: 'relative', zIndex: 10 }}
              />
            </div>

            {/* Create Button */}
            <button
              onClick={handleCreateProduct}
              disabled={isSubmitting || !formData.name.trim() || !formData.imageFiles || formData.imageFiles.length === 0 || userCredits < 10}
              className={`w-full py-2.5 px-4 font-bold text-sm rounded-lg transition-all duration-200 flex items-center justify-center gap-2 box-border ${
                isSubmitting || !formData.name.trim() || !formData.imageFiles || formData.imageFiles.length === 0 || userCredits < 10
                  ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  : 'bg-lavender-500 text-white hover:bg-lavender-600 hover:scale-105 shadow-lg hover:shadow-xl'
              }`}
             style={{ position: 'relative', zIndex: 10 }}
            >
              {isSubmitting ? (
                <>
                  <LoadingSpinner size="sm" />
                  Creating...
                </>
              ) : (
                <>
                  <Save size={14} />
                  Create (10 Credits)
                  <ArrowRight size={14} />
                </>
              )}
            </button>

          </div>

          {/* Divider */}
          <div className="my-2 flex items-center">
            <div className="flex-1 border-t border-gray-200"></div>
            <span className="px-4 text-sm text-gray-500 font-medium">OR</span>
            <div className="flex-1 border-t border-gray-200"></div>
          </div>

          {/* Secondary Option: Use Existing Product */}
          <div>
            <div className="w-full p-2 border border-gray-200 rounded-lg bg-lavender-50/30">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-lavender-500 to-lavender-600 flex items-center justify-center shadow-lg flex-shrink-0">
                  <Package className="w-3 h-3 text-white" />
                </div>
                <div className="text-left flex-1 min-w-0">
                  <h3 className="text-sm font-bold text-gray-900">Use Existing Product</h3>
                  <p className="text-xs text-gray-600">{products.length} saved products</p>
                </div>
                <div className="bg-lavender-100 text-lavender-700 px-2 py-1 rounded-lg text-xs font-semibold flex-shrink-0">
                  10 Credits
                </div>
              </div>

              {/* Existing Products List - Always Visible */}
              <div className="border border-gray-200 rounded-lg overflow-hidden w-full">
                {loading ? (
                  <div className="flex justify-center py-2">
                    <LoadingSpinner size="lg" />
                  </div>
                ) : products.length > 0 ? (
                  <div className="max-h-32 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                    {products.map((product) => (
                      <button
                        key={product.id}
                        onClick={() => setSelectedProduct(product)}
                        className={`w-full text-left p-2 border-b border-gray-100 last:border-b-0 transition-all duration-200 box-border ${
                          selectedProduct?.id === product.id
                            ? 'bg-lavender-50 border-lavender-200'
                            : 'hover:bg-gray-50'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 bg-gray-100 rounded-md overflow-hidden border border-gray-200 flex-shrink-0">
                            {product.image_urls.length > 0 ? (
                              <img
                                src={product.image_urls[0]}
                                alt={product.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <Package className="w-3 h-3 text-gray-400" />
                              </div>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="text-xs font-semibold text-gray-900 truncate">{product.name}</h3>
                            <p className="text-xs text-gray-600">{product.image_urls.length} images</p>
                          </div>
                          {selectedProduct?.id === product.id && (
                            <div className="w-3 h-3 rounded-full bg-lavender-500 flex items-center justify-center flex-shrink-0">
                              <div className="w-1 h-1 bg-white rounded-full"></div>
                            </div>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-3">
                    <Package size={16} className="text-gray-300 mx-auto mb-1" />
                    <p className="text-sm text-gray-500 font-medium">No saved products yet</p>
                    <p className="text-xs text-gray-400">Create one above</p>
                  </div>
                )}

                {/* Use Selected Button */}
                {products.length > 0 && (
                  <div className="p-2 bg-gray-50 border-t border-gray-200">
                    <button
                      onClick={handleSelectExisting}
                      disabled={!selectedProduct || userCredits < 10}
                      className={`w-full py-2 px-3 font-bold text-xs rounded-lg transition-all duration-200 flex items-center justify-center gap-2 box-border ${
                        selectedProduct && userCredits >= 10
                          ? 'bg-lavender-500 text-white hover:bg-lavender-600 hover:scale-105 shadow-lg hover:shadow-xl'
                          : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                      }`}
                    >
                      <Package size={12} />
                      {selectedProduct ? 'Use Selected' : 'Select Product'}
                      <ArrowRight size={12} />
                    </button>
                    
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default ProductSelectionModal;