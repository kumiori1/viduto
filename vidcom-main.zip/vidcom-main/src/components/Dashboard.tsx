import React, { useState, useEffect } from 'react';
import { 
  Wand2, 
  User, 
  Settings, 
  CreditCard, 
  Video, 
  Plus, 
  Send, 
  Upload, 
  X, 
  CheckCircle, 
  Clock, 
  Play,
  Eye,
  Download,
  LogOut,
  Package,
  ArrowRight,
  Sparkles,
  Menu,
  Palette
} from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useVideoCredits } from '../hooks/useVideoCredits';
import { useVideoChat } from '../hooks/useVideoChat';
import { useSubscription } from '../hooks/useSubscription';
import { useFacebookPixel } from '../hooks/useFacebookPixel';
import { products, formatPrice, getCreditPackages, getSubscriptionPlans } from '../stripe-config';
import CheckoutButton from './checkout/CheckoutButton';
import VideoChat from './VideoChat';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';
import PricingModal from './PricingModal';
import MyProducts from './MyProducts';
import BrandGuidelinesSettings from './BrandGuidelinesSettings';
import SettingsTab from './SettingsTab';

interface DashboardProps {
  initialTab?: 'chats' | 'products' | 'brand' | 'settings';
}

const Dashboard: React.FC<DashboardProps> = ({ initialTab = 'chats' }) => {
  const { user, signOut } = useAuth();
  const { chatId } = useParams();
  const navigate = useNavigate();
  const { credits, useCredit, refetch: refetchCredits } = useVideoCredits();
  const { chats, activeChat, setActiveChat, createNewChat } = useVideoChat();
  const { subscription } = useSubscription();
  const { trackVideoRequest } = useFacebookPixel();

  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [activeTab, setActiveTab] = useState<'chats' | 'products' | 'brand' | 'settings'>(initialTab);

  const [showProductSelection, setShowProductSelection] = useState(false);
  const [showPricing, setShowPricing] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  // Listen for pricing modal events
  useEffect(() => {
    const handleShowPricing = () => setShowPricing(true);
    window.addEventListener('show-pricing', handleShowPricing);
    return () => window.removeEventListener('show-pricing', handleShowPricing);
  }, []);

  // Handle URL-based chat selection
  useEffect(() => {
    if (chatId && chats.length > 0 && !activeChat) {
      const chat = chats.find(c => c.id === chatId);
      if (chat) {
        setActiveChat(chat);
        setActiveTab('chats');
      } else {
        console.log('🔴 DASHBOARD: Chat not found for ID:', chatId);
      }
    }
  }, [chatId, chats, activeChat, setActiveChat]);

  // Debug realtime updates
  useEffect(() => {
    console.log('🔵 DASHBOARD: Chats updated:', {
      chatsCount: chats.length,
      activeChatId: activeChat?.id,
      activeChatStatus: activeChat?.status,
      activeChatMessagesCount: activeChat?.messages.length,
      timestamp: new Date().toISOString()
    });
  }, [chats, activeChat]);

  // Update URL when active chat changes
  useEffect(() => {
    if (activeChat) {
      navigate(`/dashboard/chat/${activeChat.id}`, { replace: true });
    } else if (activeTab !== 'chats') {
      navigate(`/dashboard/${activeTab}`, { replace: true });
    } else {
      navigate('/dashboard', { replace: true });
    }
  }, [activeChat, activeTab, navigate]);
  
  // Mobile tab navigation
  const handleTabChange = (tab: 'chats' | 'products' | 'brand' | 'settings' | 'subscription') => {
    setActiveTab(tab);
    setActiveChat(null);
    setShowMobileSidebar(false);
    navigate(`/dashboard/${tab}`, { replace: true });
  };

  const enhancePrompt = async () => {
    if (!prompt.trim()) return;
    
    setIsEnhancing(true);
    try {
      const response = await fetch('/api/enhance-prompt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt: prompt.trim() }),
      });
      
      if (response.ok) {
        const { enhancedPrompt } = await response.json();
        setPrompt(enhancedPrompt);
        setAlert({ type: 'success', message: 'Prompt enhanced successfully!' });
      } else {
        throw new Error('Failed to enhance prompt');
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'Failed to enhance prompt. Please try again.' });
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    if (files.length === 0) return;
    
    const allFiles = [...imageFiles, ...files];
    
    if (allFiles.length > 10) {
      setAlert({ type: 'error', message: 'Maximum 10 images allowed' });
      return;
    }
    
    for (const file of allFiles) {
      if (file.size > 10 * 1024 * 1024) {
        setAlert({ type: 'error', message: `File ${file.name} is larger than 10MB` });
        return;
      }
      
      if (!file.type.startsWith('image/')) {
        setAlert({ type: 'error', message: `File ${file.name} is not an image` });
        return;
      }
    }
    
    setImageFiles(allFiles);
    e.target.value = '';
  };

  const handleRemoveImage = (indexToRemove: number) => {
    setImageFiles(prev => prev.filter((_, index) => index !== indexToRemove));
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setAlert({ type: 'error', message: 'Please describe what video you want to create' });
      return;
    }

    if (imageFiles.length < 3) {
      setAlert({ type: 'error', message: 'Please upload at least 3 product images' });
      return;
    }

    if (!credits || credits.available_credits < 10) {
      setShowPricing(true);
      setAlert({ type: 'error', message: 'You need 10 credits to create a new video' });
      return;
    }

    // Show immediate feedback
    setAlert({ type: 'info', message: 'Creating your video chat...' });

    try {
      // Create new chat - this now returns immediately
      const newChat = await createNewChat(prompt, 'Product images uploaded');
      
      if (newChat) {
        // Set the new chat as active immediately
        setActiveChat(newChat);
        console.log('🟢 Chat created and displayed immediately');
        
        // Clear the form immediately
        setPrompt('');
        setImageFiles([]);
        
        // Clear the alert
        setAlert(null);
      }
      
      // Track event
      trackVideoRequest({
        video_title: newChat?.title || 'New Video',
        target_platform: 'product_images'
      });
      
      // Refresh credits
      refetchCredits();
      
    } catch (error) {
      console.error('Error generating video:', error);
      setAlert({ type: 'error', message: 'Failed to generate video. Please try again.' });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'briefing':
        return <Clock className="w-3 h-3 text-yellow-300" />;
      case 'approved':
        return <CheckCircle className="w-3 h-3 text-electric-300" />;
      case 'generating':
        return <div className="w-3 h-3 rounded-full bg-electric-300 animate-pulse" />;
      case 'completed':
        return <CheckCircle className="w-3 h-3 text-green-300" />;
      case 'revision':
        return <Clock className="w-3 h-3 text-orange-300" />;
      default:
        return <div className="w-3 h-3 rounded-full bg-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'briefing':
        return 'Briefing';
      case 'approved':
        return 'Approved';
      case 'generating':
        return 'Generating';
      case 'completed':
        return 'Completed';
      case 'revision':
        return 'Revision';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="h-screen dark-developer-theme flex overflow-hidden">
      {/* Mobile Header - Only show when not in chat */}
      {!activeChat && (
        <div className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-dev-secondary border-b border-dev p-4 flex items-center justify-between" style={{ paddingTop: 'max(1rem, env(safe-area-inset-top))' }}>
          <div className="flex items-center gap-3">
            <img 
              src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
              alt="VidCom AI" 
              className="h-6 w-auto object-contain"
            />
          </div>
          <button
            onClick={() => setShowMobileSidebar(true)}
            className="p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-200 border border-white/20 min-w-[44px] min-h-[44px] flex items-center justify-center"
          >
            <Menu size={18} className="text-white" />
          </button>
        </div>
      )}

      {/* Mobile Sidebar Overlay */}
      {showMobileSidebar && (
        <div className="fixed inset-0 z-50">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm" 
            onClick={() => setShowMobileSidebar(false)}
          />
          
          {/* Sidebar */}
          <div className="absolute left-0 top-0 h-full w-80 max-w-[85vw] bg-dev-secondary border-r border-dev flex flex-col shadow-2xl transform transition-transform duration-300 ease-out">
            {/* Sidebar Header */}
            <div className="p-4 border-b border-dev flex-shrink-0">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <img 
                    src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
                    alt="VidCom AI" 
                    className="h-8 w-auto object-contain"
                  />
                </div>
                <button
                  onClick={() => setShowMobileSidebar(false)}
                  className="btn-dev-ghost p-2"
                >
                  <X size={20} />
                </button>
              </div>
              
              {/* User Info */}
              {user && (
                <div className="flex items-center gap-3 p-3 card-dev">
                  <div className="w-8 h-8 rounded-full bg-electric-500/20 flex items-center justify-center flex-shrink-0">
                    <User size={14} className="text-electric-300" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm dev-text-light font-medium truncate">{user.email}</p>
                    <p className="text-xs text-electric-300">{credits?.available_credits || 0} credits</p>
                  </div>
                </div>
              )}
            </div>

            {/* New Project Button */}
            <div className="p-4 flex-shrink-0">
              <button
                onClick={() => {
                  window.location.href = '/';
                }}
                className="w-full py-3 px-4 bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:scale-105 min-h-[44px]"
              >
                <Plus size={16} />
                New Project
              </button>
            </div>

            {/* Projects List */}
            <div className="px-4 flex-1 min-h-0 overflow-hidden pb-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium dev-text-light flex items-center gap-2">
                  <Video size={16} className="text-electric-300" />
                  Recent Projects
                </h3>
                <span className="text-xs text-electric-300 font-medium bg-dev-tertiary px-2 py-1 rounded">{chats.length}</span>
              </div>
              
              {chats.length > 0 ? (
                <div className="h-full overflow-y-auto space-y-1">
                  {chats.map((chat) => (
                    <button
                      key={chat.id}
                      onClick={() => {
                        setActiveChat(chat);
                        setShowMobileSidebar(false);
                        // Ensure we navigate to the chat URL
                        navigate(`/dashboard/chat/${chat.id}`, { replace: true });
                      }}
                      className={`w-full text-left p-3 rounded-md transition-colors ${
                        activeChat?.id === chat.id
                          ? 'glass-cyber-dark border border-electric-300/20'
                          : 'card-dev hover:bg-dev-tertiary'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <Video size={12} className={activeChat?.id === chat.id ? 'text-electric-300' : 'text-electric-400'} />
                        <span className={`text-sm font-medium truncate ${activeChat?.id === chat.id ? 'dev-text-light' : 'dev-text'}`}>{chat.title}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(chat.status)}
                        <span className={`text-xs ${activeChat?.id === chat.id ? 'dev-text' : 'dev-text-muted'}`}>{getStatusText(chat.status)}</span>
                      </div>
                      <div className="text-xs dev-text-muted mt-1">
                        {new Date(chat.created_at).toLocaleDateString()}
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 px-3 bg-dev-tertiary rounded-lg border border-dev-light">
                  <Video size={24} className="text-gray-500 mx-auto mb-2" />
                  <p className="text-xs dev-text-muted">No projects yet</p>
                </div>
              )}
            </div>

            {/* Sidebar Footer */}
            <div className="p-4 border-t border-dev space-y-1 flex-shrink-0">
              <button
                onClick={() => {
                  setActiveTab('products');
                  setActiveChat(null);
                  setShowMobileSidebar(false);
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <Package size={16} />
                My Products
              </button>
              <button
                onClick={() => {
                  setActiveTab('brand');
                  setActiveChat(null);
                  setShowMobileSidebar(false);
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <Palette size={16} />
                Brand Guidelines
              </button>
              <button
                onClick={() => {
                  setActiveTab('subscription');
                  setActiveChat(null);
                  setShowMobileSidebar(false);
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <CreditCard size={16} />
                My Subscription
              </button>
              <button
                onClick={() => {
                  setActiveTab('settings');
                  setActiveChat(null);
                  setShowMobileSidebar(false);
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <Settings size={16} />
                Settings
              </button>
              <button
                onClick={signOut}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <LogOut size={16} />
                Log Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Left Sidebar - Desktop Only */}
      <div className="hidden lg:flex w-80 bg-dev-secondary border-r border-dev flex-col">
        {/* Sidebar Header */}
        <div className="p-4 border-b border-dev flex-shrink-0">
          <div className="flex items-center gap-3 mb-4">
            <img 
              src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
              alt="VidCom AI" 
              className="h-8 w-auto object-contain"
            />
          </div>
          
          {/* User Info */}
          {user && (
            <div className="flex items-center gap-3 p-3 card-dev">
              <div className="w-7 h-7 rounded-full bg-electric-500/20 flex items-center justify-center flex-shrink-0">
                <User size={14} className="text-electric-300" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm dev-text-light font-medium truncate">{user.email}</p>
                <p className="text-xs text-electric-300">{credits?.available_credits || 0} credits</p>
              </div>
            </div>
          )}
        </div>

        {/* New Project Button */}
        <div className="p-4 flex-shrink-0">
          <button
            onClick={() => {
              window.location.href = '/';
            }}
            className="w-full py-3 px-4 bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:scale-105 min-h-[44px]"
          >
            <Plus size={16} />
            New Project
          </button>
        </div>

        {/* Projects List */}
        <div className="px-4 flex-1 min-h-0 overflow-hidden pb-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium dev-text-light">Recent Projects</h3>
            <span className="text-xs text-electric-300 font-medium bg-dev-tertiary px-2 py-1 rounded">{chats.length}</span>
          </div>
          <div className="h-full overflow-y-auto space-y-1">
            {chats.map((chat) => (
              <button
                key={chat.id}
                onClick={() => setActiveChat(chat)}
                className={`w-full text-left p-3 rounded-md transition-colors ${
                  activeChat?.id === chat.id
                    ? 'glass-cyber-dark border border-electric-300/20'
                    : 'card-dev hover:bg-dev-tertiary'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Video size={12} className={activeChat?.id === chat.id ? 'text-electric-300' : 'text-electric-400'} />
                  <span className={`text-sm font-medium truncate ${activeChat?.id === chat.id ? 'dev-text-light' : 'dev-text'}`}>{chat.title}</span>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(chat.status)}
                  <span className={`text-xs ${activeChat?.id === chat.id ? 'dev-text' : 'dev-text-muted'}`}>{getStatusText(chat.status)}</span>
                </div>
                <div className="text-xs dev-text-muted mt-1">
                  {new Date(chat.created_at).toLocaleDateString()}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-dev space-y-1 flex-shrink-0">
          <button
            onClick={() => {
              window.location.href = '/dashboard?tab=products';
            }}
            className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
          >
            <Package size={16} />
            My Products
          </button>
          <button
            onClick={() => {
              window.location.href = '/dashboard?tab=brand';
            }}
            className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
          >
            <Palette size={16} />
            Brand Guidelines
          </button>
          <button
            onClick={() => setShowPricing(true)}
            className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
          >
            <CreditCard size={16} />
            Manage Subscription
          </button>
          <button
            onClick={() => {
              setActiveTab('settings');
              setActiveChat(null);
            }}
            className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
          >
            <Settings size={16} />
            Settings
          </button>
          <button
            onClick={signOut}
            className="w-full flex items-center gap-3 px-3 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-dev-tertiary rounded-lg transition-all duration-200"
          >
            <LogOut size={16} />
            Log Out
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {activeChat && activeTab === 'chats' ? (
          <VideoChat
            key={`chat-${activeChat.id}-${activeChat.updated_at}`}
            chat={activeChat}
            onBack={() => setActiveChat(null)}
            onOpenMenu={() => setShowMobileSidebar(true)}
            setShowPricing={setShowPricing}
            useCredit={useCredit}
          />
        ) : activeTab === 'products' ? (
          <div className="flex-1 overflow-y-auto p-4 lg:p-6">
            <MyProducts 
              credits={credits}
              setShowPricing={setShowPricing}
            />
          </div>
        ) : activeTab === 'brand' ? (
          <div className="flex-1 overflow-y-auto p-4 lg:p-6">
            <BrandGuidelinesSettings />
          </div>
        ) : activeTab === 'settings' ? (
          <div className="flex-1 overflow-y-auto p-4 lg:p-6" style={{ paddingTop: 'max(5rem, calc(4rem + env(safe-area-inset-top)))' }}>
            <SettingsTab />
          </div>
        ) : activeTab === 'subscription' ? (
          <div className="flex-1 overflow-y-auto p-4 lg:p-6" style={{ paddingTop: 'max(5rem, calc(4rem + env(safe-area-inset-top)))' }}>
            <SubscriptionTab 
              subscription={subscription}
              credits={credits}
              onShowPricing={() => setShowPricing(true)}
            />
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-4 lg:p-6" style={{ paddingTop: 'max(5rem, calc(4rem + env(safe-area-inset-top)))' }}>
            <div className="text-center">
              <div className="w-16 h-16 rounded-lg bg-electric-500/20 flex items-center justify-center mx-auto mb-4">
                <Wand2 className="text-electric-300" size={24} />
              </div>
              <h2 className="text-lg lg:text-xl font-semibold dev-heading mb-2">Ready to Create?</h2>
              <p className="text-sm dev-text mb-4 lg:mb-6">Start a new video project with AI assistance</p>
              <button
                onClick={() => {
                  navigate('/');
                }}
                className="bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white py-3 lg:py-4 px-6 lg:px-8 font-semibold flex items-center gap-2 lg:gap-3 mx-auto text-base lg:text-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 rounded-lg"
              >
                <Plus size={16} className="lg:w-5 lg:h-5" />
                New Project
                <ArrowRight size={16} className="lg:w-5 lg:h-5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Pricing Modal */}
      <PricingModal
        isOpen={showPricing}
        onClose={() => setShowPricing(false)}
        onAuthRequired={() => {}}
      />
    </div>
  );
};

export default Dashboard;