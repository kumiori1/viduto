import React from 'react';
import { ChevronDown, ChevronUp, HelpCircle, Zap, CreditCard, Video, Clock, Shield, Star } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
  category: 'general' | 'pricing' | 'technical' | 'support';
}

const faqData: FAQItem[] = [
  // General Questions
  {
    question: "What is VidCom AI?",
    answer: "VidCom AI is an AI-powered platform that transforms your product images into professional marketing videos. Simply upload your product photos, describe what you want, and our AI creates stunning videos optimized for social media platforms like TikTok, Instagram, Facebook, and YouTube.",
    category: "general"
  },
  {
    question: "How does the video generation process work?",
    answer: "It's simple: 1) Upload 3-10 product images, 2) Describe your video concept in natural language, 3) Our AI analyzes your brief and creates a professional video, 4) Review and request changes if needed. The entire process takes 5-10 minutes.",
    category: "general"
  },
  {
    question: "What types of videos can you create?",
    answer: "We create product marketing videos optimized for all major platforms: TikTok ads, Instagram Reels, YouTube Shorts, Facebook ads, and more. Each video is tailored for the specific platform's requirements and best practices.",
    category: "general"
  },
  {
    question: "Do I get a free trial?",
    answer: "Yes! Every new user receives 40 free credits (enough to create 1 product and 1 complete video) to try our service. No credit card required for the trial.",
    category: "general"
  },

  // Pricing Questions
  {
    question: "How does the credit system work?",
    answer: "Credits are used for video creation: New video = 10 credits, Video revision = 3 credits, Adding new product = 30 credits. Credits never expire and can be used anytime.",
    category: "pricing"
  },
  {
    question: "What's the difference between subscription plans?",
    answer: "Starter ($29): 1 product + 3 videos + 30 credits monthly. Creator ($49): 2 products + 6 videos + 60 credits monthly. Business ($89): 4 products + 12 videos + 120 credits monthly. Agency ($199): 8 products + 25 videos + 250 credits monthly.",
    category: "pricing"
  },
  {
    question: "Can I buy additional credits?",
    answer: "Yes! You can purchase credit packages anytime: 25 credits for $19, 60 credits for $39, or 150 credits for $89. These are perfect for extra videos beyond your subscription.",
    category: "pricing"
  },
  {
    question: "Can I cancel my subscription anytime?",
    answer: "Absolutely! You can cancel your subscription at any time. You'll continue to have access until the end of your current billing period, and any unused credits remain in your account.",
    category: "pricing"
  },

  // Technical Questions
  {
    question: "What image formats do you accept?",
    answer: "We accept JPG, PNG, and WebP formats. Each image should be under 10MB. For best results, use high-resolution images (at least 1080px) with good lighting and clear product visibility.",
    category: "technical"
  },
  {
    question: "How long does video generation take?",
    answer: "Video generation typically takes 5-10 minutes. You'll see real-time progress updates during the creation process, including script planning, 3D modeling, frame generation, and final assembly.",
    category: "technical"
  },
  {
    question: "What video formats and sizes do you provide?",
    answer: "We provide videos in MP4 format optimized for each platform: 9:16 for TikTok/Instagram Stories, 1:1 for Instagram posts, 16:9 for YouTube, and custom sizes as needed. All videos are delivered in HD quality.",
    category: "technical"
  },
  {
    question: "Can I request changes to my video?",
    answer: "Yes! After your video is generated, you can chat with our AI to request specific changes like different music, pacing, text modifications, or visual adjustments. Each revision costs 3 credits.",
    category: "technical"
  },

  // Support Questions
  {
    question: "How can I contact support?",
    answer: "You can reach our support team at help.vidcom@gmail.com. We typically respond within 24 hours. Subscription users get priority support with faster response times.",
    category: "support"
  },
  {
    question: "Do you offer refunds?",
    answer: "Yes! We offer a 30-day money-back guarantee. If you're not satisfied with our service, contact us within 30 days for a full refund.",
    category: "support"
  },
  {
    question: "Is my data secure?",
    answer: "Absolutely! We use enterprise-grade security with encrypted data storage, secure payment processing through Stripe, and never share your content with third parties. Your product images and videos are private and secure.",
    category: "support"
  },
  {
    question: "Can I use the videos commercially?",
    answer: "Yes! All videos created with VidCom AI come with full commercial usage rights. You can use them for advertising, social media marketing, websites, and any other business purposes.",
    category: "support"
  }
];

const FAQPage: React.FC = () => {
  const [openItems, setOpenItems] = React.useState<Set<number>>(new Set());
  const [activeCategory, setActiveCategory] = React.useState<string>('all');

  const toggleItem = (index: number) => {
    const newOpenItems = new Set(openItems);
    if (newOpenItems.has(index)) {
      newOpenItems.delete(index);
    } else {
      newOpenItems.add(index);
    }
    setOpenItems(newOpenItems);
  };

  const categories = [
    { id: 'all', name: 'All Questions', icon: HelpCircle },
    { id: 'general', name: 'General', icon: Star },
    { id: 'pricing', name: 'Pricing', icon: CreditCard },
    { id: 'technical', name: 'Technical', icon: Video },
    { id: 'support', name: 'Support', icon: Shield }
  ];

  const filteredFAQs = activeCategory === 'all' 
    ? faqData 
    : faqData.filter(item => item.category === activeCategory);

  return (
    <div className="min-h-screen neo-cyber-bg relative">
      {/* Background Auras */}
      <div className="cyber-aura-1"></div>
      <div className="cyber-aura-2"></div>
      <div className="cyber-aura-3"></div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 py-8 lg:py-12">
        {/* Header */}
        <div className="text-center mb-8 lg:mb-12">
          <img 
            src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
            alt="VidCom AI" 
            className="h-20 lg:h-28 w-auto object-contain mx-auto mb-6"
          />
          <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4 heading-cyber-large">
            Frequently Asked Questions
          </h1>
          <p className="text-lg text-gray-700 max-w-2xl mx-auto text-cyber-large">
            Everything you need to know about VidCom AI and creating professional product videos
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 lg:gap-4 mb-8 lg:mb-12">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-2xl font-semibold transition-all duration-200 text-sm lg:text-base ${
                  activeCategory === category.id
                    ? 'bg-electric-500 text-white shadow-lg'
                    : 'bg-white/60 text-gray-700 hover:bg-white/80 border border-electric-200/50'
                }`}
              >
                <Icon size={16} />
                {category.name}
              </button>
            );
          })}
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {filteredFAQs.map((item, index) => (
            <div key={index} className="card-cyber p-6 transition-all duration-200">
              <button
                onClick={() => toggleItem(index)}
                className="w-full flex items-center justify-between text-left"
              >
                <h3 className="text-lg font-semibold text-gray-900 heading-cyber pr-4">
                  {item.question}
                </h3>
                <div className="flex-shrink-0">
                  {openItems.has(index) ? (
                    <ChevronUp className="text-electric-500" size={20} />
                  ) : (
                    <ChevronDown className="text-electric-500" size={20} />
                  )}
                </div>
              </button>
              
              {openItems.has(index) && (
                <div className="mt-4 pt-4 border-t border-electric-200/30">
                  <p className="text-gray-700 leading-relaxed text-cyber-large">
                    {item.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="mt-12 text-center card-cyber p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 heading-cyber">
            Still Have Questions?
          </h2>
          <p className="text-gray-700 mb-6 text-cyber-large">
            Our support team is here to help you succeed with video marketing
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="mailto:help.vidcom@gmail.com"
              className="btn-cyber-primary py-3 px-6 font-semibold flex items-center justify-center gap-2 text-base"
            >
              <HelpCircle size={16} />
              Contact Support
            </a>
            <button
              onClick={() => window.location.href = '/'}
              className="btn-cyber-secondary py-3 px-6 font-semibold flex items-center justify-center gap-2 text-base"
            >
              <Video size={16} />
              Try Free Video
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQPage;