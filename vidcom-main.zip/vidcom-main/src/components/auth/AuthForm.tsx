import React, { useState } from 'react';
import { Eye, EyeOff, Mail, Lock, UserPlus, LogIn, X } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import LoadingSpinner from '../ui/LoadingSpinner';
import Alert from '../ui/Alert';

interface AuthFormProps {
  mode: 'login' | 'signup';
  onModeChange: (mode: 'login' | 'signup') => void;
  onClose: () => void;
}

const AuthForm: React.FC<AuthFormProps> = ({ mode, onModeChange, onClose }) => {
  const { signIn, signUp } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const validatePassword = (password: string) => {
    if (password.length < 8) {
      return 'Password must be at least 8 characters long';
    }
    if (!/[A-Z]/.test(password)) {
      return 'Password must contain at least one uppercase letter';
    }
    if (!/[a-z]/.test(password)) {
      return 'Password must contain at least one lowercase letter';
    }
    if (!/\d/.test(password)) {
      return 'Password must contain at least one number';
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
      return 'Password must contain at least one special character';
    }
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setAlert(null);

    // Validate email
    if (!email.trim()) {
      setAlert({ type: 'error', message: 'Please enter your email address' });
      setLoading(false);
      return;
    }

    // Validate password
    if (!password.trim()) {
      setAlert({ type: 'error', message: 'Please enter your password' });
      setLoading(false);
      return;
    }

    // Additional validation for signup
    if (mode === 'signup') {
      const passwordError = validatePassword(password);
      if (passwordError) {
        setAlert({ type: 'error', message: passwordError });
        setLoading(false);
        return;
      }
    }

    try {
      if (mode === 'login') {
        const { error } = await signIn(email, password);
        if (error) {
          setAlert({ type: 'error', message: error.message });
        } else {
          setAlert({ type: 'success', message: 'Welcome back!' });
          setTimeout(() => {
            onClose();
          }, 1000);
        }
      } else {
        const { error } = await signUp(email, password);
        if (error) {
          // Check for specific database error that indicates successful user creation
          if (error.message.includes('Database error saving new user') || error.message.includes('unexpected_failure')) {
            setAlert({ type: 'success', message: 'Account created successfully! Please sign in.' });
            setTimeout(() => {
              onModeChange('login');
              setEmail('');
              setPassword('');
            }, 1500);
          } else {
            setAlert({ type: 'error', message: error.message });
          }
        } else {
          setAlert({ type: 'success', message: 'Account created successfully!' });
          setTimeout(() => {
            onClose();
            setEmail('');
            setPassword('');
          }, 1000);
        }
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'An unexpected error occurred. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 modal-cyber-backdrop flex items-center justify-center p-4 z-50">
      <div className="modal-cyber-content p-6 lg:p-8 w-full max-w-md">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-xl lg:text-2xl font-bold text-black mb-1 heading-cyber">
              {mode === 'login' ? 'Welcome Back' : 'Get Started'}
            </h2>
            <p className="text-sm text-cyber-soft">
              {mode === 'login' ? 'Sign in to your account' : 'Create your account to start creating videos'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-electric-600 transition-all duration-200 p-2 hover:bg-electric-300/10 rounded-xl hover:scale-105"
          >
            <X size={20} />
          </button>
        </div>

        {alert && (
          <Alert
            type={alert.type}
            message={alert.message}
            onClose={() => setAlert(null)}
            className="mb-4"
          />
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <div className="relative">
              <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 flex items-center justify-center">
                <Mail className="text-electric-600" size={14} />
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email address"
                className="w-full pl-14 pr-4 py-3.5 input-cyber text-base"
                required
              />
            </div>
          </div>

          <div>
            <div className="relative">
              <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 flex items-center justify-center">
                <Lock className="text-electric-600" size={14} />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="w-full pl-14 pr-14 py-3.5 input-cyber text-base"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 hover:bg-electric-300/30 flex items-center justify-center text-electric-600 hover:text-electric-700 transition-all duration-200"
              >
                {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
            {mode === 'signup' && (
              <div className="mt-2 text-xs text-gray-600 space-y-1">
                <p>Password must contain:</p>
                <ul className="list-disc list-inside space-y-0.5 ml-2">
                  <li>At least 8 characters</li>
                  <li>One uppercase letter (A-Z)</li>
                  <li>One lowercase letter (a-z)</li>
                  <li>One number (0-9)</li>
                  <li>One special character (!@#$%^&*)</li>
                </ul>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 px-6 btn-cyber-primary font-semibold flex items-center justify-center gap-3 text-base hover-cyber micro-cyber glow-cyber-electric"
          >
            {loading ? (
              <>
                <LoadingSpinner size="sm" />
                {mode === 'login' ? 'Signing In...' : 'Creating Account...'}
              </>
            ) : (
              <>
                {mode === 'login' ? <LogIn size={16} /> : <UserPlus size={16} />}
                {mode === 'login' ? 'Sign In' : 'Create Account'}
              </>
            )}
          </button>
        </form>

        <div className="mt-5 text-center">
          <button
            onClick={() => onModeChange(mode === 'login' ? 'signup' : 'login')}
            className="text-cyber-soft hover:text-electric-600 transition-all duration-200 text-sm font-medium"
          >
            {mode === 'login' ? "Don't Have an Account? Sign Up" : "Already Have an Account? Sign In"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthForm;