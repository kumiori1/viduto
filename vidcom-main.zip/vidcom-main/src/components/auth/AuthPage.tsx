import React, { useState } from 'react';
import { X, Moon, Sun } from 'lucide-react';
import AuthForm from './AuthForm';
import ForgotPasswordForm from './ForgotPasswordForm';

interface AuthPageProps {
  onBackToHome: () => void;
  onSuccess?: () => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  initialMode?: 'login' | 'signup';
}

const AuthPage: React.FC<AuthPageProps> = ({ onBackToHome, onSuccess, darkMode, toggleDarkMode, initialMode = 'login' }) => {
  const [authMode, setAuthMode] = useState<'login' | 'signup'>(initialMode);
  const [currentView, setCurrentView] = useState<'auth' | 'forgot-password'>('auth');

  return (
    <div className="dark-developer-theme min-h-screen flex items-center justify-center" dir="rtl">
      <div className="max-w-md w-full mx-4">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center items-center gap-3 mb-4">
            <button
              onClick={onBackToHome}
              className="btn-dev-ghost p-3 hover:scale-110"
              title="חזור לדף הראשי"
            >
              <X size={20} />
            </button>
            <img 
              src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
              alt="VidCom AI" 
              className="h-24 w-auto object-contain"
            />
            <button
              onClick={toggleDarkMode}
              className="btn-dev-ghost p-3"
            >
              <Moon size={20} className="text-yellow-400" />
            </button>
          </div>
        </div>

        {/* Auth Form */}
        {currentView === 'auth' ? (
          <AuthForm
            mode={authMode}
            onToggleMode={() => setAuthMode(authMode === 'login' ? 'signup' : 'login')}
            onForgotPassword={() => setCurrentView('forgot-password')}
            onSuccess={onSuccess}
            darkMode={darkMode}
          />
        ) : (
          <ForgotPasswordForm
            onBackToLogin={() => setCurrentView('auth')}
            darkMode={darkMode}
          />
        )}

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-sm dev-text-muted">
            © 2024 VidCom AI. כל הזכויות שמורות.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;