import React, { useState } from 'react';
import { Mail, ArrowRight, ArrowLeft, Send, CheckCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import Alert from '../ui/Alert';
import LoadingSpinner from '../ui/LoadingSpinner';

interface ForgotPasswordFormProps {
  onBackToLogin: () => void;
  darkMode?: boolean;
}

const ForgotPasswordForm: React.FC<ForgotPasswordFormProps> = ({ onBackToLogin, darkMode = false }) => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isEmailSent, setIsEmailSent] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'warning' | 'info'; message: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);
    
    if (!email.trim()) {
      setAlert({ type: 'error', message: 'אנא הכנס כתובת אימייל' });
      return;
    }

    if (!email.includes('@')) {
      setAlert({ type: 'error', message: 'אנא הכנס כתובת אימייל תקינה' });
      return;
    }

    setIsLoading(true);
    
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) {
        setAlert({ type: 'error', message: error.message });
      } else {
        setIsEmailSent(true);
        setAlert({ 
          type: 'success', 
          message: 'קישור לאיפוס סיסמה נשלח לכתובת האימייל שלך. אנא בדוק את תיבת הדואר שלך.' 
        });
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'אירעה שגיאה. אנא נסה שוב.' });
    } finally {
      setIsLoading(false);
    }
  };

  if (isEmailSent) {
    return (
      <div className={`rounded-2xl p-8 shadow-2xl transition-colors duration-300 ${
        darkMode ? 'bg-gray-800 border border-gray-700' : 'bg-white'
      }`}>
        <div className="text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="text-green-600" size={40} />
          </div>
          
          <h2 className={`text-2xl font-bold mb-4 ${
            darkMode ? 'text-white' : 'text-gray-900'
          }`} style={{ fontFamily: 'Geist Sans, sans-serif' }}>
            אימייל נשלח בהצלחה!
          </h2>
          
          <p className={`mb-6 leading-relaxed ${
            darkMode ? 'text-gray-300' : 'text-gray-600'
          }`} style={{ fontFamily: 'Geist Sans, sans-serif' }}>
            שלחנו קישור לאיפוס סיסמה לכתובת:<br />
            <strong className="text-blue-600">{email}</strong>
          </p>

          <div className={`bg-blue-50 rounded-lg p-4 mb-6 text-right ${
            darkMode ? 'bg-blue-900/20 border border-blue-700' : 'border border-blue-200'
          }`}>
            <h3 className={`font-semibold mb-2 ${
              darkMode ? 'text-blue-300' : 'text-blue-900'
            }`}>
              מה הלאה?
            </h3>
            <ul className={`text-sm space-y-1 ${
              darkMode ? 'text-blue-300' : 'text-blue-700'
            }`}>
              <li>• בדוק את תיבת הדואר שלך (כולל תיקיית ספאם)</li>
              <li>• לחץ על הקישור באימייל</li>
              <li>• הכנס סיסמה חדשה</li>
              <li>• חזור להתחבר עם הסיסמה החדשה</li>
            </ul>
          </div>

          <div className="space-y-3">
            <button
              onClick={onBackToLogin}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center gap-2"
            >
              <ArrowLeft size={20} />
              חזור להתחברות
            </button>
            
            <button
              onClick={() => {
                setIsEmailSent(false);
                setEmail('');
                setAlert(null);
              }}
              className={`w-full py-3 px-6 rounded-lg font-semibold transition-all duration-300 border ${
                darkMode 
                  ? 'border-gray-600 text-gray-300 hover:bg-gray-700' 
                  : 'border-gray-300 text-gray-700 hover:bg-gray-50'
              }`}
            >
              שלח שוב
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`rounded-2xl p-8 shadow-2xl transition-colors duration-300 ${
      darkMode ? 'bg-gray-800 border border-gray-700' : 'bg-white'
    }`}>
      <div className="text-center mb-6">
        <h2 className={`text-2xl font-bold mb-2 ${
          darkMode ? 'text-white' : 'text-gray-900'
        }`} style={{ fontFamily: 'Satoshi, sans-serif' }}>
          שכחת סיסמה?
        </h2>
        <p className={`${
          darkMode ? 'text-gray-300' : 'text-gray-600'
        }`} style={{ fontFamily: 'Satoshi, sans-serif' }}>
          הכנס את כתובת האימייל שלך ונשלח לך קישור לאיפוס סיסמה
        </p>
      </div>

      {alert && (
        <Alert
          type={alert.type}
          message={alert.message}
          onClose={() => setAlert(null)}
          className="mb-6"
        />
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Email Field */}
        <div>
          <label className={`block text-sm font-semibold mb-2 ${
            darkMode ? 'text-gray-200' : 'text-gray-700'
          }`}>
            כתובת אימייל
          </label>
          <div className="relative">
            <Mail className={`absolute right-3 top-1/2 transform -translate-y-1/2 ${
              darkMode ? 'text-gray-400' : 'text-gray-500'
            }`} size={20} />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="הכנס כתובת אימייל"
              className={`w-full pr-12 pl-4 py-3 rounded-lg border transition-all duration-300 ${
                darkMode
                  ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500'
                  : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500 focus:border-blue-500'
              } focus:ring-2 focus:ring-blue-500/20 focus:outline-none`}
            />
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading}
          className={`w-full py-3 px-6 rounded-lg font-semibold text-white transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center gap-2 ${
            isLoading
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700'
          }`}
        >
          {isLoading ? (
            <>
              <LoadingSpinner size="sm" />
              שולח...
            </>
          ) : (
            <>
              <Send size={20} />
              שלח קישור לאיפוס
              <ArrowRight size={20} />
            </>
          )}
        </button>
      </form>

      {/* Back to Login */}
      <div className="mt-6 text-center">
        <button 
          onClick={onBackToLogin}
          className="text-blue-600 hover:text-blue-700 font-semibold transition-colors flex items-center justify-center gap-2 mx-auto"
        >
          <ArrowLeft size={18} />
          חזור להתחברות
        </button>
      </div>
    </div>
  );
};

export default ForgotPasswordForm;