import React, { useState, useEffect } from 'react';
import { Lock, Eye, EyeOff, CheckCircle, ArrowRight, Home } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import Alert from '../ui/Alert';
import LoadingSpinner from '../ui/LoadingSpinner';
import SEOHead from '../SEOHead';

const ResetPasswordPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'warning' | 'info'; message: string } | null>(null);

  useEffect(() => {
    // Check if we have the required parameters for password reset
    const accessToken = searchParams.get('access_token');
    const type = searchParams.get('type');
    
    if (!accessToken || type !== 'recovery') {
      setAlert({ 
        type: 'error', 
        message: 'קישור לא תקין או פג תוקף. אנא בקש קישור חדש לאיפוס סיסמה.' 
      });
    }
  }, [searchParams]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);
    
    if (!password.trim()) {
      setAlert({ type: 'error', message: 'אנא הכנס סיסמה חדשה' });
      return;
    }

    if (password.length < 6) {
      setAlert({ type: 'error', message: 'הסיסמה חייבת להכיל לפחות 6 תווים' });
      return;
    }

    if (password !== confirmPassword) {
      setAlert({ type: 'error', message: 'הסיסמאות אינן תואמות' });
      return;
    }

    setIsLoading(true);
    
    try {
      const { error } = await supabase.auth.updateUser({
        password: password
      });

      if (error) {
        setAlert({ type: 'error', message: error.message });
      } else {
        setIsSuccess(true);
        setAlert({ 
          type: 'success', 
          message: 'הסיסמה עודכנה בהצלחה! מעביר אותך להתחברות...' 
        });
        
        // Redirect to login after 3 seconds
        setTimeout(() => {
          navigate('/', { replace: true });
        }, 3000);
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'אירעה שגיאה. אנא נסה שוב.' });
    } finally {
      setIsLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4" dir="rtl">
        <SEOHead
          title="סיסמה עודכנה בהצלחה | VidCom AI"
          description="הסיסמה שלך עודכנה בהצלחה. כעת תוכל להתחבר עם הסיסמה החדשה."
          canonicalUrl="https://vidcom.ai/reset-password"
        />
        
        <div className="max-w-md w-full">
          <div className="bg-white rounded-2xl p-8 shadow-2xl text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="text-green-600" size={40} />
            </div>

            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              הסיסמה עודכנה בהצלחה!
            </h1>

            <p className="text-gray-600 mb-6 leading-relaxed">
              הסיסמה שלך עודכנה בהצלחה. כעת תוכל להתחבר עם הסיסמה החדשה.
            </p>

            <div className="bg-blue-50 rounded-lg p-4 mb-6">
              <p className="text-sm text-blue-700">
                מעביר אותך לדף הבית תוך מספר שניות...
              </p>
            </div>

            <button
              onClick={() => navigate('/', { replace: true })}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center gap-2"
            >
              <Home size={20} />
              חזור לדף הבית
              <ArrowRight size={20} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="dark-developer-theme min-h-screen flex items-center justify-center p-4" dir="rtl">
      <SEOHead
        title="איפוס סיסמה | VidCom AI"
        description="הכנס סיסמה חדשה לחשבון VidCom AI שלך"
        canonicalUrl="https://vidcom.ai/reset-password"
      />
      
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center items-center gap-3 mb-4">
            <img 
              src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
              alt="VidCom AI" 
              className="h-24 w-auto object-contain"
            />
          </div>
        </div>

        {/* Reset Password Form */}
        <div className="form-dev">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold dev-heading mb-2">
              הכנס סיסמה חדשה
            </h2>
            <p className="dev-text">
              בחר סיסמה חזקה לחשבון שלך
            </p>
          </div>

          {alert && (
            <Alert
              type={alert.type}
              message={alert.message}
              onClose={() => setAlert(null)}
              className="mb-6"
            />
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* New Password Field */}
            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                סיסמה חדשה
              </label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 transform -translate-y-1/2 text-blue-400" size={18} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="הכנס סיסמה חדשה (לפחות 6 תווים)"
                  className="w-full pr-12 pl-12 py-3 input-dev"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-blue-400 transition-colors"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Confirm Password Field */}
            <div>
              <label className="block text-sm font-semibold mb-2 dev-text-light">
                אימות סיסמה
              </label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 transform -translate-y-1/2 text-blue-400" size={18} />
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="הכנס שוב את הסיסמה החדשה"
                  className="w-full pr-12 pl-12 py-3 input-dev"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-blue-400 transition-colors"
                >
                  {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Password Requirements */}
            <div className="bg-dev-tertiary rounded-lg p-4">
              <h4 className="font-semibold dev-text-light mb-2">דרישות סיסמה:</h4>
              <ul className="text-sm dev-text space-y-1">
                <li className={`flex items-center gap-2 ${password.length >= 6 ? 'text-green-600' : ''}`}>
                  <span className={`w-2 h-2 rounded-full ${password.length >= 6 ? 'bg-green-500' : 'bg-gray-300'}`}></span>
                  לפחות 6 תווים
                </li>
                <li className={`flex items-center gap-2 ${password === confirmPassword && password.length > 0 ? 'text-green-600' : ''}`}>
                  <span className={`w-2 h-2 rounded-full ${password === confirmPassword && password.length > 0 ? 'bg-green-500' : 'bg-gray-300'}`}></span>
                  הסיסמאות תואמות
                </li>
              </ul>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-3 px-6 font-semibold text-white transition-all duration-200 flex items-center justify-center gap-2 ${
                isLoading
                  ? 'bg-gray-600 cursor-not-allowed opacity-50'
                  : 'btn-dev-primary'
              }`}
            >
              {isLoading ? (
                <>
                  <LoadingSpinner size="sm" />
                  מעדכן סיסמה...
                </>
              ) : (
                <>
                  <CheckCircle size={20} />
                  עדכן סיסמה
                  <ArrowRight size={20} />
                </>
              )}
            </button>
          </form>

          {/* Back to Home */}
          <div className="mt-6 text-center">
            <button 
              onClick={() => navigate('/', { replace: true })}
              className="text-blue-400 hover:text-blue-300 font-semibold transition-colors"
            >
              חזור לדף הבית
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-sm dev-text-muted">
            © 2024 VidCom AI. כל הזכויות שמורות.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ResetPasswordPage;