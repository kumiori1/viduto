import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  ThumbsUp, 
  Download, 
  ArrowLeft, 
  Clock, 
  CheckCircle, 
  Video, 
  Loader, 
  Bot, 
  User as UserIcon, 
  Menu, 
  Plus, 
  Edit, 
  X, 
  CreditCard, 
  Settings, 
  LogOut,
  Package,
  Palette
} from 'lucide-react';
import { useVideoChat, ChatMessage, VideoChat as VideoChatType } from '../hooks/useVideoChat';
import { useVideoCredits } from '../hooks/useVideoCredits';
import { useAuth } from '../hooks/useAuth';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';

interface VideoChatProps {
  chat: VideoChatType;
  onBack: () => void;
  onOpenMenu?: () => void;
  showSidebar?: boolean;
  onCloseSidebar?: () => void;
  chats?: VideoChatType[];
  onChatSelect?: (chat: VideoChatType) => void;
  credits?: any;
  setShowPricing?: (show: boolean) => void;
}

const VideoChat: React.FC<VideoChatProps> = ({ 
  chat, 
  onBack, 
  onOpenMenu,
  showSidebar = false,
  onCloseSidebar,
  chats = [],
  onChatSelect,
  credits,
  setShowPricing
}) => {
  const { sendMessage, approveAndStartProduction, setActiveChat } = useVideoChat();
  const { useCredit, useCredits, refetch: refetchCredits } = useVideoCredits();
  const { user, signOut } = useAuth();
  const [newMessage, setNewMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isApproving, setIsApproving] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleApproveAndStartProduction = async () => {
    if (!user || !chat) return;
    
    // Check if user has enough credits
    if (!credits || credits.available_credits < 10) {
      setAlert({ type: 'error', message: 'You need 10 credits to start video production.' });
      setShowPricing?.(true);
      return;
    }

    setIsApproving(true);
    setAlert(null);
    
    try {
      console.log('🔵 APPROVE: Starting production directly for chat:', chat.id);
      
      // Deduct credits first
      const success = await useCredits(10);
      if (!success) {
        setAlert({ type: 'error', message: 'Failed to deduct credits. Please try again.' });
        return;
      }
      console.log('🟢 APPROVE: Credits deducted successfully');
      
      // Start production
      await approveAndStartProduction(chat.id);
      
      console.log('🟢 APPROVE: Production started successfully');
      
      // Refresh credits display
      refetchCredits();
    } catch (error) {
      console.error('🔴 APPROVE: Error starting production:', error);
      setAlert({ type: 'error', message: 'Failed to start video production. Please try again.' });
    } finally {
      setIsApproving(false);
    }
  };

  
  // Debug logging for chat updates
  useEffect(() => {
    console.log('🔵 CHAT UI: Chat updated:', {
      id: chat.id,
      status: chat.status,
      messagesCount: chat.messages.length,
      lastUpdate: chat.updated_at,
      workflowPhase: chat.workflow_state?.phase
    });
    
    // Force scroll after chat updates
    setTimeout(scrollToBottom, 200);
  }, [chat]);

  useEffect(() => {
    scrollToBottom();
  }, [chat.messages, chat.messages.length]);

  // Force scroll to bottom when new messages arrive
  useEffect(() => {
    console.log('🔵 CHAT UI: Messages updated, count:', chat.messages.length);
    const timer = setTimeout(() => {
      scrollToBottom();
      // Also try alternative scroll method
      const messagesArea = document.querySelector('.mobile-messages-area');
      if (messagesArea) {
        messagesArea.scrollTop = messagesArea.scrollHeight;
      }
    }, 100);
    return () => clearTimeout(timer);
  }, [chat.messages.length]);

  // Refresh credits after successful operations
  useEffect(() => {
    if (chat.status === 'approved' || chat.status === 'generating' || chat.status === 'completed') {
      refetchCredits();
    }
  }, [chat.status, refetchCredits]);
  const scrollToBottom = () => {
    console.log('🔵 SCROLL: Scrolling to bottom');
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ 
        behavior: 'smooth',
        block: 'end',
        inline: 'nearest'
      });
      console.log('🟢 SCROLL: Scrolled successfully');
    } else {
      console.log('🔴 SCROLL: Ref not found');
      // Alternative scroll method
      const messagesArea = document.querySelector('.mobile-messages-area');
      if (messagesArea) {
        messagesArea.scrollTop = messagesArea.scrollHeight;
        console.log('🟢 SCROLL: Alternative scroll applied');
      }
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || isSending) return;

    const messageToSend = newMessage.trim();
    console.log('🔵 CHAT UI: Sending message:', messageToSend.substring(0, 30));

    setIsSending(true);
    setAlert(null);
    setNewMessage('');
    
    try {
      await sendMessage(chat.id, messageToSend);
      console.log('🟢 CHAT UI: Message sent successfully');
    } catch (error) {
      console.error('🔴 CHAT UI: Error sending message:', error);
      setAlert({ type: 'error', message: 'Failed to send message' });
      setNewMessage(messageToSend); // Restore message on error
    } finally {
      setIsSending(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'briefing':
        return <Clock className="w-3 h-3 text-yellow-400" />;
      case 'approved':
        return <CheckCircle className="w-3 h-3 text-blue-400" />;
      case 'generating':
        return <div className="w-3 h-3 rounded-full bg-blue-400 animate-pulse" />;
      case 'completed':
        return <CheckCircle className="w-3 h-3 text-green-400" />;
      case 'revision':
        return <Clock className="w-3 h-3 text-orange-400" />;
      default:
        return <div className="w-3 h-3 rounded-full bg-gray-400" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'briefing':
        return 'Briefing';
      case 'approved':
        return 'Approved';
      case 'generating':
        return 'Generating';
      case 'completed':
        return 'Completed';
      case 'revision':
        return 'Revision';
      default:
        return 'Unknown';
    }
  };

  const renderMessage = (message: ChatMessage) => {
    const isUser = message.role === 'user';
    const isSystem = message.role === 'system';
    const isLoading = message.type === 'loading';
    const isProductionStatus = message.type === 'production_status';
    const isBrief = message.type === 'brief';

    return (
      <div key={message.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4 lg:mb-6`}>
        <div className={`flex items-start gap-3 lg:gap-4 max-w-[90%] lg:max-w-[85%] ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
          {/* Avatar */}
          <div className={`w-8 lg:w-10 h-8 lg:h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
            isUser 
              ? 'bg-electric-500/20 border border-electric-300/30' 
              : 'bg-dev-tertiary border border-dev-light'
          }`}>
            {isUser ? (
              <UserIcon className="text-electric-300" size={14} />
            ) : (
              <Bot className="text-electric-300" size={14} />
            )}
          </div>
          
          {/* Message Content */}
          <div className={`rounded-lg px-3 lg:px-5 py-3 lg:py-4 text-sm lg:text-base shadow-lg ${
            isUser 
              ? 'glass-cyber-dark border border-electric-300/30 dev-text-light' 
              : isSystem 
                ? isLoading
                  ? 'glass-cyber-dark border border-yellow-400/30 text-yellow-300'
                  : isProductionStatus
                    ? 'glass-cyber-dark border border-electric-300/30 text-electric-300'
                      : 'glass-cyber-dark border border-yellow-400/30 text-yellow-300'
                : isBrief
                  ? 'card-dev-elevated dev-text-light border-l-4 border-l-electric-400 bg-electric-500/5'
                : 'card-dev-elevated dev-text-light'
          }`}>
          
            {isLoading && (
              <div className="flex items-center gap-2 mb-1">
                <LoadingSpinner size="sm" />
                <span className="text-xs font-medium">
                  Processing...
                </span>
              </div>
            )}

            {isProductionStatus && message.metadata && (
              <div className="space-y-4">
                <div className="text-lg font-semibold dev-text-light mb-6 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-electric-500 to-electric-600 flex items-center justify-center shadow-lg">
                    <Video className="text-white" size={16} />
                  </div>
                  {message.content}
                </div>
                
                {/* Enhanced Progress Section */}
                <div className="bg-dev-tertiary/50 rounded-2xl p-6 border border-electric-300/20">
                  {/* Progress Header */}
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-lg font-semibold dev-text-light">Production Progress</span>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-electric-400 rounded-full animate-pulse"></div>
                      <span className="text-2xl font-bold text-electric-300">{message.metadata.progress}%</span>
                    </div>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="w-full bg-dev-primary rounded-full h-4 mb-6 overflow-hidden shadow-inner">
                    <div 
                      className="bg-gradient-to-r from-electric-400 via-electric-500 to-electric-600 h-4 rounded-full transition-all duration-1000 ease-out relative overflow-hidden"
                      style={{ width: `${message.metadata.progress}%` }}
                    >
                      {/* Animated shine effect */}
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse"></div>
                    </div>
                  </div>

                  {/* Steps Grid */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                    {message.metadata.steps?.map((step: any, index: number) => (
                      <div key={step.id} className={`flex items-center gap-3 p-4 rounded-xl transition-all duration-300 ${
                        step.status === 'completed' 
                          ? 'bg-green-500/10 border border-green-400/30 shadow-lg shadow-green-400/10' 
                          : step.status === 'active'
                            ? 'bg-electric-500/10 border border-electric-400/30 shadow-lg shadow-electric-400/20 scale-105'
                            : 'bg-gray-500/5 border border-gray-400/20'
                      }`}>
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-lg ${
                          step.status === 'completed' 
                            ? 'bg-gradient-to-br from-green-500 to-green-600' 
                            : step.status === 'active'
                              ? 'bg-gradient-to-br from-electric-500 to-electric-600'
                              : 'bg-gradient-to-br from-gray-500 to-gray-600'
                        }`}>
                          {step.status === 'completed' ? (
                            <CheckCircle className="w-5 h-5 text-white" />
                          ) : step.status === 'active' ? (
                            <div className="w-3 h-3 bg-white rounded-full animate-pulse" />
                          ) : (
                            <div className="w-3 h-3 bg-white/50 rounded-full" />
                          )}
                        </div>
                        <div className="flex-1">
                          <span className={`text-sm font-semibold block ${
                            step.status === 'completed' 
                              ? 'text-green-300' 
                              : step.status === 'active'
                                ? 'text-electric-300'
                                : 'dev-text-muted'
                          }`}>
                            {step.name}
                          </span>
                          {step.status === 'active' && (
                            <div className="flex items-center gap-2 mt-1">
                              <div className="w-2 h-2 bg-electric-400 rounded-full animate-pulse"></div>
                              <span className="text-xs text-electric-400 font-medium">Processing...</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Current Step Highlight */}
                <div className="mt-4 bg-gradient-to-r from-electric-500/10 to-lavender-500/10 border border-electric-400/30 rounded-xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-electric-500 to-electric-600 flex items-center justify-center shadow-lg">
                      <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                    </div>
                    <div>
                      <span className="text-sm font-semibold text-electric-300 block">Currently Working On</span>
                      <span className="text-lg font-bold dev-text-light">
                        {message.metadata.steps?.find((s: any) => s.id === message.metadata.current_step)?.name}
                      </span>
                    </div>
                    <div className="ml-auto">
                      <LoadingSpinner size="sm" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {isBrief && (
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded-lg bg-electric-500/20 flex items-center justify-center">
                  <Video className="text-electric-500" size={12} />
                </div>
                <span className="text-sm font-semibold text-electric-600">Video Brief</span>
              </div>
            )}
            
            {message.type === 'video' && chat.video_url ? (
              <div className="space-y-2">
                <p className="text-sm lg:text-base font-medium">{message.content}</p>
                <div className="w-full bg-black rounded-lg overflow-hidden border border-dev-light shadow-lg" style={{ height: '60vh' }}>
                  <iframe
                    src={`https://player.vimeo.com/video/${chat.video_url.split('/').pop()}?badge=0&autopause=0&player_id=0&app_id=58479&controls=1&title=0&byline=0&portrait=0`}
                    className="w-full h-full"
                    frameBorder="0"
                    allow="autoplay; fullscreen; picture-in-picture"
                    allowFullScreen
                    title={chat.title}
                  ></iframe>
                </div>
                <div className="flex gap-2">
                  <a
                    href={chat.video_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-3 lg:px-4 py-2 bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white rounded-lg text-xs lg:text-sm font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                  >
                    <Download size={12} />
                    <span className="hidden sm:inline">Download</span>
                  </a>
                </div>
              </div>
            ) : (
              message.type === 'approval_request' ? (
                <div className="space-y-4">
                  <div className="text-base leading-relaxed dev-text-light">
                    {message.content}
                  </div>
                  <button
                    onClick={() => {
                      handleApproveAndStartProduction();
                    }}
                    disabled={isApproving || isSending}
                    className="w-full py-3 px-6 bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white rounded-xl font-semibold text-base transition-all duration-200 flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isApproving ? (
                      <>
                        <LoadingSpinner size="sm" />
                        Starting Production...
                      </>
                    ) : (
                      <>
                        <CheckCircle size={20} />
                        Approve & Generate Video
                        <span className="text-sm opacity-90">(10 credits)</span>
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <div className={`whitespace-pre-wrap leading-relaxed text-base ${isBrief ? 'font-medium' : ''}`}>
                  {message.content}
                </div>
              )
            )}
            
            <div className="text-xs lg:text-sm opacity-60 mt-2 lg:mt-3 dev-text-muted">
              {new Date(message.timestamp).toLocaleTimeString()}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col">
      {/* Mobile Sidebar - Show when in chat */}
      {showSidebar && (
        <div className="fixed inset-0 z-50">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm" 
            onClick={onCloseSidebar}
          />
          
          {/* Sidebar */}
          <div className="absolute left-0 top-0 h-full w-80 bg-dev-secondary border-r border-dev flex flex-col shadow-2xl">
            {/* Sidebar Header */}
            <div className="p-4 border-b border-dev flex-shrink-0">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <img 
                    src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
                    alt="VidCom AI" 
                    className="h-8 w-auto object-contain"
                  />
                </div>
                <button
                  onClick={onCloseSidebar}
                  className="btn-dev-ghost p-2"
                >
                  <X size={20} />
                </button>
              </div>
              
              {/* User Info */}
              {user && (
                <div className="flex items-center gap-3 p-3 card-dev">
                  <div className="w-8 h-8 rounded-full bg-electric-500/20 flex items-center justify-center flex-shrink-0">
                    <UserIcon size={14} className="text-electric-300" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm dev-text-light font-medium truncate">{user.email}</p>
                    <p className="text-xs text-electric-300">{credits?.available_credits || 0} credits</p>
                  </div>
                </div>
              )}
            </div>

            {/* New Project Button */}
            <div className="p-4 flex-shrink-0">
              <button
                onClick={() => {
                  onBack();
                  onCloseSidebar?.();
                }}
                className="w-full py-3 px-4 bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <Plus size={16} />
                New Project
              </button>
            </div>

            {/* Recent Chats */}
            <div className="flex-1 min-h-0 overflow-hidden pb-4">
              <div className="px-4 mb-3">
                <h3 className="text-sm font-medium dev-text-light flex items-center gap-2">
                  <Video size={16} className="text-electric-300" />
                  Recent Projects
                </h3>
              </div>
              
              <div className="px-4 h-full overflow-y-auto">
                {chats.length > 0 ? (
                  <div className="space-y-2">
                  {chats.map((chatItem) => (
                    <button
                      key={chatItem.id}
                      onClick={() => {
                        if (onChatSelect) {
                          onChatSelect(chatItem);
                          onCloseSidebar?.();
                        }
                      }}
                      className={`w-full text-left p-3 rounded-md transition-colors ${
                        chat.id === chatItem.id
                          ? 'glass-cyber-dark border border-electric-300/20'
                          : 'card-dev hover:bg-dev-tertiary'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <Video size={12} className={chat.id === chatItem.id ? 'text-electric-300' : 'text-electric-400'} />
                        <span className={`text-sm font-medium truncate ${chat.id === chatItem.id ? 'dev-text-light' : 'dev-text'}`}>{chatItem.title}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(chatItem.status)}
                        <span className={`text-xs ${chat.id === chatItem.id ? 'dev-text' : 'dev-text-muted'}`}>{getStatusText(chatItem.status)}</span>
                      </div>
                      <div className="text-xs dev-text-muted mt-1">
                        {new Date(chatItem.created_at).toLocaleDateString()}
                      </div>
                    </button>
                  ))}
                  </div>
                ) : (
                <div className="text-center py-4 px-3 bg-dev-tertiary rounded-lg border border-dev-light">
                  <Video size={24} className="text-gray-500 mx-auto mb-2" />
                  <p className="text-xs dev-text-muted">No projects yet</p>
                </div>
                )}
              </div>
            </div>

            {/* Bottom Menu */}
            <div className="p-4 border-t border-dev space-y-1 flex-shrink-0">
              <button
                onClick={() => {
                  window.location.href = '/dashboard?tab=products';
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <Package size={16} />
                My Products
              </button>
              <button
                onClick={() => {
                  window.location.href = '/dashboard?tab=brand';
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <Palette size={16} />
                Brand Guidelines
              </button>
              <button
                onClick={() => {
                  window.location.href = '/dashboard?tab=subscription';
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <CreditCard size={16} />
                My Subscription
              </button>
              <button
                onClick={() => {
                  window.location.href = '/dashboard?tab=settings';
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <Settings size={16} />
                Settings
              </button>
              <button
                onClick={signOut}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <LogOut size={16} />
                Log Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chat Header */}
      <div className="p-4 border-b border-dev flex-shrink-0 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Mobile Menu Button */}
          <button
            onClick={onOpenMenu}
            className="lg:hidden p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-200 border border-white/20 min-w-[44px] min-h-[44px] flex items-center justify-center"
            title="Open menu"
          >
            <Menu size={18} className="text-white" />
          </button>
          
          <div className="w-8 h-8 bg-electric-500/20 rounded-lg flex items-center justify-center">
            <Video className="text-electric-300" size={16} />
          </div>
          <div>
            <h1 className="text-lg font-semibold dev-heading">{chat.title}</h1>
            <div className="flex items-center gap-2 text-sm dev-text">
              {chat.status === 'briefing' && <Clock size={12} className="text-yellow-300" />}
              {chat.status === 'generating' && <Loader size={12} className="animate-spin text-electric-300" />}
              {chat.status === 'completed' && <CheckCircle size={12} className="text-green-300" />}
              <span className="capitalize">{chat.status.replace('_', ' ')}</span>
              <span className="dev-text-muted">•</span>
              <span className="dev-text-muted">{chat.messages.length} messages</span>
            </div>
          </div>
        </div>
        
        {/* Desktop Back Button */}
        <button
          onClick={onBack}
          className="hidden lg:flex btn-dev-ghost p-2"
          title="Back to projects"
        >
          <ArrowLeft size={20} />
        </button>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 lg:p-6 min-h-0 mobile-messages-area">
        {alert && (
          <Alert
            type={alert.type}
            message={alert.message}
            onClose={() => setAlert(null)}
            className="mb-4"
          />
        )}
        <div className="space-y-4 lg:space-y-6 max-w-4xl">
          {chat.messages.map(renderMessage)}
        </div>
        <div ref={messagesEndRef} data-messages-end />
      </div>

      {/* Chat Input Area - Always Available */}
      <div className="flex-shrink-0 border-t border-dev p-4 lg:p-6 bg-dev-secondary" style={{ 
        paddingBottom: 'max(1rem, env(safe-area-inset-bottom))',
        position: 'relative',
        zIndex: 10
      }}>
        <form onSubmit={handleSendMessage} className="flex gap-3 items-end">
          <textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder={
              chat.status === 'briefing' 
                ? "Type 'approve' to start generation, or describe changes..."
                : chat.status === 'completed'
                  ? "Describe changes for video revision (3 credits)..."
                  : chat.status === 'revision'
                    ? "Type 'yes' to confirm revision or describe more changes..."
                    : chat.status === 'generating'
                      ? "Video is being generated... Please wait..."
                      : "Type your message..."
            }
            rows={2}
            className="flex-1 input-dev text-sm lg:text-base resize-none"
            style={{ fontSize: '16px', minHeight: '44px' }}
            disabled={isSending || chat.status === 'generating'}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (newMessage.trim() && !isSending && chat.status !== 'generating') {
                  handleSendMessage(e as any);
                }
              }
            }}
          />
          <button
            type="submit"
            disabled={isSending || !newMessage.trim() || chat.status === 'generating'}
            className={`px-4 lg:px-6 py-3 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 flex-shrink-0 ${
              isSending || !newMessage.trim() || chat.status === 'generating'
                ? 'bg-dev-tertiary dev-text-muted cursor-not-allowed'
                : 'bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white shadow-lg hover:shadow-xl'
            }`}
            style={{ minHeight: '44px', minWidth: '44px' }}
          >
            {isSending ? (
              <>
                <LoadingSpinner size="sm" />
              </>
            ) : (
              <>
                <Send size={16} />
                <span className="hidden sm:inline">Send</span>
              </>
            )}
          </button>
        </form>
        
        {/* Status Info */}
        <div className="mt-2 text-xs lg:text-sm dev-text-muted text-center">
          {chat.status === 'briefing' && "Type 'approve' to start generation (10 credits)"}
          {chat.status === 'completed' && `Changes cost 3 credits • ${credits?.available_credits || 0} available`}
          {chat.status === 'revision' && "Type 'yes' to confirm revision (3 credits)"}
          {chat.status === 'generating' && "Video generation in progress..."}
        </div>
      </div>
    </div>
  );
};

export default VideoChat;