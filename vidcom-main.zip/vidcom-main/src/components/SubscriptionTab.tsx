import React, { useState } from 'react';
import { 
  Crown, 
  CreditCard, 
  Calendar, 
  Zap, 
  Check, 
  X, 
  ArrowRight, 
  Star, 
  Shield, 
  Clock,
  AlertCircle,
  Plus,
  Sparkles,
  TrendingUp,
  Gift,
  ChevronRight,
  CheckCircle
} from 'lucide-react';
import { useSubscription, UserSubscription } from '../hooks/useSubscription';
import { useVideoCredits, UserVideoCredits } from '../hooks/useVideoCredits';
import { formatPrice, getSubscriptionPlans, getCreditPackages, getProductByPriceId } from '../stripe-config';
import CheckoutButton from './checkout/CheckoutButton';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';

interface SubscriptionTabProps {
  subscription?: UserSubscription | null;
  credits?: UserVideoCredits | null;
  onShowPricing?: () => void;
}

const SubscriptionTab: React.FC<SubscriptionTabProps> = ({ 
  subscription, 
  credits,
  onShowPricing 
}) => {
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const subscriptionPlans = getSubscriptionPlans();
  const creditPackages = getCreditPackages();
  const currentPlan = subscription?.price_id ? getProductByPriceId(subscription.price_id) : null;
  const hasActiveSubscription = subscription?.subscription_status === 'active' || subscription?.subscription_status === 'trialing';

  const formatDate = (timestamp: number | null) => {
    if (!timestamp) return 'N/A';
    return new Date(timestamp * 1000).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
      case 'trialing':
        return 'text-green-400 bg-green-400/10 border-green-400/20';
      case 'past_due':
        return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
      case 'canceled':
      case 'unpaid':
        return 'text-red-400 bg-red-400/10 border-red-400/20';
      default:
        return 'text-gray-400 bg-gray-400/10 border-gray-400/20';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Active';
      case 'trialing': return 'Trial';
      case 'past_due': return 'Past Due';
      case 'canceled': return 'Canceled';
      case 'unpaid': return 'Unpaid';
      case 'paused': return 'Paused';
      default: return 'No Plan';
    }
  };

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {alert && (
        <Alert
          type={alert.type}
          message={alert.message}
          onClose={() => setAlert(null)}
        />
      )}

      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-xl lg:text-2xl font-bold dev-heading mb-2">My Subscription</h1>
        <p className="dev-text text-sm">Manage your plan and credits</p>
      </div>

      {/* Current Plan Card */}
      <div className="card-dev p-4 lg:p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
              hasActiveSubscription 
                ? 'bg-gradient-to-br from-electric-500 to-electric-600' 
                : 'bg-gray-600'
            }`}>
              <Crown className="text-white" size={18} />
            </div>
            <div>
              <h2 className="text-lg font-semibold dev-heading">
                {currentPlan ? currentPlan.name : 'Pay-as-you-go'}
              </h2>
              <p className="text-sm dev-text-muted">
                {hasActiveSubscription ? 'Monthly plan' : 'No subscription'}
              </p>
            </div>
          </div>
          
          {subscription && (
            <div className={`px-3 py-1 rounded-lg text-xs font-semibold border ${getStatusColor(subscription.subscription_status)}`}>
              {getStatusText(subscription.subscription_status)}
            </div>
          )}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="bg-dev-tertiary rounded-lg p-3 text-center">
            <div className="text-lg font-bold text-electric-300 mb-1">
              {currentPlan ? formatPrice(currentPlan.price, currentPlan.currency) : '₪0'}
            </div>
            <div className="text-xs dev-text-muted">Monthly</div>
          </div>
          <div className="bg-dev-tertiary rounded-lg p-3 text-center">
            <div className="text-lg font-bold text-electric-300 mb-1">
              {currentPlan?.credits || 0}
            </div>
            <div className="text-xs dev-text-muted">Per Month</div>
          </div>
          <div className="bg-dev-tertiary rounded-lg p-3 text-center">
            <div className="text-lg font-bold text-electric-300 mb-1">
              {credits?.available_credits || 0}
            </div>
            <div className="text-xs dev-text-muted">Available</div>
          </div>
        </div>

        {/* Next Payment Info */}
        {hasActiveSubscription && subscription && (
          <div className="bg-dev-tertiary rounded-lg p-3">
            <div className="flex items-center justify-between text-sm">
              <span className="dev-text-muted">Next payment:</span>
              <span className="dev-text-light font-medium">
                {formatDate(subscription.current_period_end)}
              </span>
            </div>
            {subscription.payment_method_brand && (
              <div className="flex items-center justify-between text-sm mt-1">
                <span className="dev-text-muted">Payment method:</span>
                <span className="dev-text-light font-medium">
                  {subscription.payment_method_brand} •••• {subscription.payment_method_last4}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Cancel Warning */}
        {subscription?.cancel_at_period_end && (
          <div className="alert-dev-warning p-3 rounded-lg mt-4">
            <div className="flex items-center gap-2 text-sm">
              <AlertCircle size={14} />
              <span className="font-semibold">Ending {formatDate(subscription.current_period_end)}</span>
            </div>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Upgrade/Subscribe */}
        <div className="card-dev p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-electric-500 to-electric-600 flex items-center justify-center">
              <TrendingUp className="text-white" size={14} />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold dev-heading text-sm">
                {hasActiveSubscription ? 'Upgrade Plan' : 'Get Subscription'}
              </h3>
              <p className="text-xs dev-text-muted">
                {hasActiveSubscription ? 'More credits monthly' : 'Save with monthly plans'}
              </p>
            </div>
          </div>
          
          <button
            onClick={onShowPricing}
            className="w-full btn-dev-primary py-2 px-3 font-semibold text-sm flex items-center justify-center gap-2"
          >
            <Crown size={14} />
            {hasActiveSubscription ? 'View Plans' : 'Choose Plan'}
            <ChevronRight size={14} />
          </button>
        </div>

        {/* Buy Credits */}
        <div className="card-dev p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-lavender-500 to-lavender-600 flex items-center justify-center">
              <Zap className="text-white" size={14} />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold dev-heading text-sm">Top Up Credits</h3>
              <p className="text-xs dev-text-muted">One-time purchase</p>
            </div>
          </div>
          
          <button
            onClick={onShowPricing}
            className="w-full btn-dev-secondary py-2 px-3 font-semibold text-sm flex items-center justify-center gap-2"
          >
            <Plus size={14} />
            Buy Credits
            <ChevronRight size={14} />
          </button>
        </div>
      </div>

      {/* Usage This Month */}
      <div className="card-dev p-4">
        <h3 className="text-base font-semibold dev-heading mb-4 flex items-center gap-2">
          <Sparkles size={16} />
          Usage This Month
        </h3>
        
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-electric-300 mb-1">
              {credits?.total_used || 0}
            </div>
            <div className="text-xs dev-text-muted">Used</div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-electric-300 mb-1">
              {Math.floor((credits?.total_used || 0) / 10)}
            </div>
            <div className="text-xs dev-text-muted">Videos</div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-electric-300 mb-1">
              {credits?.total_purchased || 0}
            </div>
            <div className="text-xs dev-text-muted">Purchased</div>
          </div>
        </div>

        {/* Progress Bar */}
        {hasActiveSubscription && currentPlan && (
          <div>
            <div className="flex justify-between text-xs mb-2">
              <span className="dev-text-muted">Monthly usage</span>
              <span className="dev-text-light">
                {credits?.total_used || 0} / {currentPlan.credits}
              </span>
            </div>
            <div className="w-full bg-dev-tertiary rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-electric-500 to-electric-600 h-2 rounded-full transition-all duration-300"
                style={{ 
                  width: `${Math.min(((credits?.total_used || 0) / (currentPlan.credits || 1)) * 100, 100)}%` 
                }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Quick Credit Packages */}
      <div className="card-dev p-4">
        <h3 className="text-base font-semibold dev-heading mb-4 flex items-center gap-2">
          <Gift size={16} />
          Quick Top-up
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {creditPackages.map((pack, index) => (
            <div key={pack.id} className="bg-dev-tertiary rounded-lg p-3 text-center relative">
              {index === 1 && (
                <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                  <span className="bg-electric-500 text-white px-2 py-1 rounded text-xs font-bold">
                    Best Value
                  </span>
                </div>
              )}
              <div className="text-lg font-bold text-electric-300 mb-1">
                {pack.credits}
              </div>
              <div className="text-xs dev-text-muted mb-2">
                {formatPrice(pack.price, pack.currency)}
              </div>
              <div className="text-xs text-electric-400 mb-3">
                ₪{(pack.price / pack.credits!).toFixed(1)}/video
              </div>
              <CheckoutButton
                priceId={pack.priceId}
                productName={pack.name}
                mode={pack.mode}
                className="w-full py-2 px-3 btn-dev-secondary font-semibold text-xs"
              >
                Buy Now
              </CheckoutButton>
            </div>
          ))}
        </div>
      </div>

      {/* Available Plans Preview */}
      {!hasActiveSubscription && (
        <div className="card-dev p-4">
          <h3 className="text-base font-semibold dev-heading mb-4 flex items-center gap-2">
            <Crown size={16} />
            Monthly Plans
          </h3>
          
          <div className="space-y-3">
            {subscriptionPlans.slice(0, 2).map((plan, index) => (
              <div key={plan.id} className="flex items-center justify-between p-3 bg-dev-tertiary rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    index === 0 ? 'bg-blue-500/20' : 'bg-electric-500/20'
                  }`}>
                    <Crown className={index === 0 ? 'text-blue-400' : 'text-electric-400'} size={14} />
                  </div>
                  <div>
                    <h4 className="font-semibold dev-text-light text-sm">{plan.name}</h4>
                    <p className="text-xs dev-text-muted">{plan.credits} credits/month</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-electric-300">
                    {formatPrice(plan.price, plan.currency)}
                  </div>
                  <div className="text-xs dev-text-muted">/month</div>
                </div>
              </div>
            ))}
            
            <button
              onClick={onShowPricing}
              className="w-full py-3 px-4 btn-dev-primary font-semibold text-sm flex items-center justify-center gap-2"
            >
              <Star size={14} />
              View All Plans
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      )}

      {/* Help & Support */}
      <div className="card-dev p-4">
        <h3 className="text-base font-semibold dev-heading mb-4 flex items-center gap-2">
          <Shield size={16} />
          Need Help?
        </h3>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-dev-tertiary rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-electric-400/20 flex items-center justify-center">
                <Clock size={12} className="text-electric-400" />
              </div>
              <div>
                <h4 className="font-semibold dev-text-light text-sm">Billing Support</h4>
                <p className="text-xs dev-text-muted">Questions about payments</p>
              </div>
            </div>
            <ChevronRight size={14} className="dev-text-muted" />
          </div>
          
          <div className="flex items-center justify-between p-3 bg-dev-tertiary rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-electric-400/20 flex items-center justify-center">
                <Star size={12} className="text-electric-400" />
              </div>
              <div>
                <h4 className="font-semibold dev-text-light text-sm">Plan Advice</h4>
                <p className="text-xs dev-text-muted">Help choosing the right plan</p>
              </div>
            </div>
            <ChevronRight size={14} className="dev-text-muted" />
          </div>
        </div>
        
        <div className="mt-4 text-center">
          <a
            href="mailto:help.vidcom@gmail.com"
            className="text-electric-300 hover:text-electric-400 font-medium text-sm transition-colors"
          >
            help.vidcom@gmail.com
          </a>
        </div>
      </div>

      {/* Benefits of Subscription */}
      {!hasActiveSubscription && (
        <div className="card-dev p-4">
          <h3 className="text-base font-semibold dev-heading mb-4 text-center">
            Why Subscribe?
          </h3>
          
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-lg bg-green-400/20 flex items-center justify-center">
                <CheckCircle size={12} className="text-green-400" />
              </div>
              <span className="text-sm dev-text-light">Save up to 40% vs pay-per-video</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-lg bg-electric-400/20 flex items-center justify-center">
                <CheckCircle size={12} className="text-electric-400" />
              </div>
              <span className="text-sm dev-text-light">Fresh credits every month</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-lg bg-lavender-400/20 flex items-center justify-center">
                <CheckCircle size={12} className="text-lavender-400" />
              </div>
              <span className="text-sm dev-text-light">Priority support & faster processing</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionTab;