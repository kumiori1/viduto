import React, { useEffect, useState } from 'react';
import { CheckCircle, ArrowRight, Home, Video } from 'lucide-react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useSubscription } from '../../hooks/useSubscription';
import { useOrders } from '../../hooks/useOrders';
import { useFacebookPixel } from '../../hooks/useFacebookPixel';
import LoadingSpinner from '../ui/LoadingSpinner';
import Alert from '../ui/Alert';
import SEOHead from '../SEOHead';

const SuccessPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const sessionId = searchParams.get('session_id');
  const { refetch: refetchSubscription } = useSubscription();
  const { refetch: refetchOrders } = useOrders();
  const { trackPurchase } = useFacebookPixel();
  const [isRefreshing, setIsRefreshing] = useState(true);

  useEffect(() => {
    if (sessionId) {
      // Refresh subscription and order data after successful payment
      const refreshData = async () => {
        try {
          await Promise.all([
            refetchSubscription(),
            refetchOrders()
          ]);
          
          // Track successful purchase
          trackPurchase({
            value: 0, // You can get this from order data if available  
            currency: 'ILS',
            order_id: sessionId || undefined,
            content_name: 'Video Credits Package'
          });
        } catch (error) {
          console.error('Error refreshing data:', error);
        } finally {
          setIsRefreshing(false);
        }
      };

      // Add a small delay to ensure webhook has processed
      setTimeout(refreshData, 2000);
    } else {
      setIsRefreshing(false);
    }
  }, [sessionId, refetchSubscription, refetchOrders, trackPurchase]);

  const handleGoToDashboard = () => {
    navigate('/dashboard');
  };

  const handleGoHome = () => {
    navigate('/');
  };

  return (
    <div className="dark-developer-theme min-h-screen flex items-center justify-center p-4" dir="rtl">
      {/* SEO Head for Success Page */}
      <SEOHead
        title="תשלום בוצע בהצלחה | VidCom AI"
        description="תודה על הרכישה! התשלום שלך עובד בהצלחה ואנחנו כבר מתחילים לעבוד על הסרטונים שלך."
        keywords="תשלום מוצלח, רכישת סרטוני AI, אישור הזמנה"
        canonicalUrl="https://vidcom.ai/success"
      />
      
      <div className="max-w-md w-full">
        <div className="card-dev-elevated p-8 text-center">
          {/* Success Icon */}
          <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="text-green-600" size={40} />
          </div>

          {/* Title */}
          <h1 className="text-3xl font-bold dev-heading mb-4">
            תשלום בוצע בהצלחה!
          </h1>

          <p className="dev-text mb-6 leading-relaxed">
            תודה על הרכישה! התשלום שלך עובד בהצלחה ואנחנו כבר מתחילים לעבוד על הסרטונים שלך.
          </p>

          {/* Session ID (if available) */}
          {sessionId && (
            <div className="bg-dev-tertiary rounded-lg p-4 mb-6">
              <p className="text-sm dev-text-muted mb-1">מספר הזמנה:</p>
              <p className="text-xs font-mono dev-text break-all">{sessionId}</p>
            </div>
          )}

          {/* Refreshing indicator */}
          {isRefreshing && (
            <Alert
              type="info"
              message="מעדכן את פרטי החשבון שלך..."
              className="mb-6"
            />
          )}

          {/* Next Steps */}
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6 text-right">
            <h3 className="font-semibold text-blue-400 mb-2">מה הלאה?</h3>
            <ul className="text-sm text-blue-300 space-y-1">
              <li>• נחזור אליך תוך 24 שעות עם פרטים נוספים</li>
              <li>• תוכל לעקוב אחר התקדמות הסרטונים באיזור האישי</li>
              <li>• נשלח לך עדכונים באימייל</li>
            </ul>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <button
              onClick={handleGoToDashboard}
              disabled={isRefreshing}
              className="w-full btn-dev-primary py-3 px-6 font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isRefreshing ? (
                <>
                  <LoadingSpinner size="sm" />
                  מעדכן...
                </>
              ) : (
                <>
                  <Video size={20} />
                  לאיזור האישי
                  <ArrowRight size={20} />
                </>
              )}
            </button>

            <button
              onClick={handleGoHome}
              className="w-full btn-dev-secondary py-3 px-6 font-semibold flex items-center justify-center gap-2"
            >
              <Home size={20} />
              חזור לדף הבית
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-sm dev-text-muted">
            © 2024 VidCom AI. כל הזכויות שמורות.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SuccessPage;