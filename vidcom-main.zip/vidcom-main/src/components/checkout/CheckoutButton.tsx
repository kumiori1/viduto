import React, { useState } from 'react';
import { ShoppingCart, CreditCard } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useFacebookPixel } from '../../hooks/useFacebookPixel';
import { supabase } from '../../lib/supabase';
import LoadingSpinner from '../ui/LoadingSpinner';
import Alert from '../ui/Alert';

interface CheckoutButtonProps {
  priceId: string;
  productName: string;
  mode: 'payment' | 'subscription';
  className?: string;
  children?: React.ReactNode;
  onAuthRequired?: () => void;
}

const CheckoutButton: React.FC<CheckoutButtonProps> = ({
  priceId,
  productName,
  mode,
  className = '',
  children,
  onAuthRequired
}) => {
  const { user } = useAuth();
  const { trackInitiateCheckout } = useFacebookPixel();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCheckout = async () => {
    if (!user) {
      onAuthRequired?.();
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/stripe-checkout`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          price_id: priceId,
          mode,
          success_url: `${window.location.origin}/success?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: window.location.href,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create checkout session');
      }

      const { url } = await response.json();
      
      if (url) {
        window.location.href = url;
        
        // Track initiate checkout event  
        trackInitiateCheckout({
          value: 0, // Will be updated on success page with actual amount
          currency: 'ILS',
          content_ids: [priceId],
          content_name: productName,
        });
      } else {
        throw new Error('No checkout URL received');
      }
    } catch (err) {
      console.error('Checkout error:', err);
      setError(err instanceof Error ? err.message : 'Failed to start checkout');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      {error && (
        <Alert
          type="error"
          message={error}
          onClose={() => setError(null)}
          className="mb-4"
        />
      )}
      
      <button
        onClick={handleCheckout}
        disabled={isLoading}
        className={`flex items-center justify-center gap-2 font-semibold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
      >
        {isLoading ? (
          <>
            <LoadingSpinner size="sm" />
            Processing...
          </>
        ) : (
          <>
            {children || (
              <>
                <CreditCard size={20} />
                Buy Now
              </>
            )}
          </>
        )}
      </button>
    </div>
  );
};

export default CheckoutButton;