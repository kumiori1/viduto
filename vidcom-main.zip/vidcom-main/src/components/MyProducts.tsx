import React, { useState } from 'react';
import { Package, Plus, Upload, X, Save, Video, CreditCard, Camera, Grid3X3 } from 'lucide-react';
import { useProducts, Product } from '../hooks/useProducts';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';

interface MyProductsProps {
  onSelectProduct?: (product: Product) => void;
  selectedProductId?: string;
  showSelectMode?: boolean;
  credits?: any;
  setShowPricing?: (show: boolean) => void;
}

const MyProducts: React.FC<MyProductsProps> = ({ 
  onSelectProduct, 
  selectedProductId, 
  showSelectMode = false,
  credits,
  setShowPricing
}) => {
  const { user } = useAuth();
  const { products, loading, createProduct } = useProducts();
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    imageFiles: [] as File[]
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const resetForm = () => {
    setFormData({
      name: '',
      imageFiles: []
    });
    setShowAddForm(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    if (files.length === 0) return;
    
    if (files.length > 10) {
      setAlert({ type: 'error', message: 'Maximum 10 images allowed' });
      return;
    }
    
    for (const file of files) {
      if (file.size > 10 * 1024 * 1024) {
        setAlert({ type: 'error', message: `File ${file.name} is too large (max 10MB)` });
        return;
      }
      
      if (!file.type.startsWith('image/')) {
        setAlert({ type: 'error', message: `${file.name} is not an image` });
        return;
      }
    }
    
    setFormData(prev => ({ ...prev, imageFiles: files }));
    e.target.value = '';
  };

  const handleRemoveImage = (indexToRemove: number) => {
    setFormData(prev => ({
      ...prev,
      imageFiles: prev.imageFiles.filter((_, index) => index !== indexToRemove)
    }));
  };

  const uploadImagesToSupabase = async (files: File[]): Promise<string[]> => {
    if (!user) throw new Error('User not authenticated');

    const uploadedUrls: string[] = [];

    for (const file of files) {
      const timestamp = Date.now();
      const randomString = Math.random().toString(36).substring(2, 15);
      const fileExtension = file.name.split('.').pop();
      const uniqueFileName = `products/${user.id}/${timestamp}_${randomString}.${fileExtension}`;

      const { data, error } = await supabase.storage
        .from('video-request-images')
        .upload(uniqueFileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) {
        throw new Error(`Error uploading ${file.name}: ${error.message}`);
      }

      const { data: urlData } = supabase.storage
        .from('video-request-images')
        .getPublicUrl(uniqueFileName);

      if (urlData?.publicUrl) {
        uploadedUrls.push(urlData.publicUrl);
      } else {
        throw new Error(`Failed to get URL for ${file.name}`);
      }
    }

    return uploadedUrls;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);

    if (!formData.name.trim()) {
      setAlert({ type: 'error', message: 'Product name is required' });
      return;
    }

    if (formData.imageFiles.length === 0) {
      setAlert({ type: 'error', message: 'At least one image is required' });
      return;
    }

    setIsSubmitting(true);

    try {
      setAlert({ type: 'info', message: 'Uploading images...' });
      const imageUrls = await uploadImagesToSupabase(formData.imageFiles);
      const imageNames = formData.imageFiles.map(f => f.name);

      const productData = {
        name: formData.name,
        description: '',
        reference_tag: formData.name.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, ''),
        image_urls: imageUrls,
        image_names: imageNames
      };

      await createProduct(productData);
      setAlert({ type: 'success', message: 'Product saved successfully!' });
      resetForm();
    } catch (error) {
      console.error('Error saving product:', error);
      setAlert({ 
        type: 'error', 
        message: error instanceof Error ? error.message : 'Failed to save product' 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {alert && (
        <Alert
          type={alert.type}
          message={alert.message}
          onClose={() => setAlert(null)}
        />
      )}

      {/* Simple Header */}
      <div className="text-center">
        <h1 className="text-2xl font-bold dev-heading mb-2">My Products</h1>
        <p className="dev-text">Save your products for quick video creation</p>
      </div>

      {/* Add Product Form */}
      {showAddForm ? (
        <div className="card-dev p-6 max-w-lg mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold dev-heading">Add New Product</h2>
            <button
              onClick={resetForm}
              className="p-2 hover:bg-dev-tertiary rounded-lg transition-colors"
            >
              <X size={20} className="dev-text" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Product Name */}
            <div>
              <label className="block text-sm font-semibold mb-3 dev-text-light">
                Product Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="e.g., Wireless Headphones"
                className="w-full px-4 py-3 input-dev text-base"
                autoFocus
              />
            </div>

            {/* Image Upload */}
            <div>
              <label className="block text-sm font-semibold mb-3 dev-text-light">
                Product Images
              </label>
              
              {/* Upload Area */}
              <div className="border-2 border-dashed border-dev-light rounded-xl p-8 text-center hover:border-electric-400 hover:bg-electric-400/5 transition-all duration-200 cursor-pointer">
                <input
                  type="file"
                  id="product-images"
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                  disabled={isSubmitting}
                  className="hidden"
                />
                <label htmlFor="product-images" className="cursor-pointer block">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-electric-400/10 flex items-center justify-center">
                    <Camera className="w-8 h-8 text-electric-400" />
                  </div>
                  <h3 className="text-lg font-semibold dev-heading mb-2">Upload Photos</h3>
                  <p className="dev-text">PNG, JPG up to 10MB each</p>
                  <p className="text-sm dev-text-muted mt-1">Maximum 10 images</p>
                </label>
              </div>

              {/* Image Previews */}
              {formData.imageFiles.length > 0 && (
                <div className="mt-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-semibold dev-text-light">
                      {formData.imageFiles.length} image{formData.imageFiles.length !== 1 ? 's' : ''} selected
                    </span>
                  </div>
                  <div className="grid grid-cols-4 gap-3">
                    {formData.imageFiles.map((file, index) => (
                      <div key={index} className="relative group">
                        <div className="aspect-square bg-dev-tertiary rounded-lg overflow-hidden border border-dev-light">
                          <img
                            src={URL.createObjectURL(file)}
                            alt={`Product ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveImage(index)}
                          className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center text-xs transition-all duration-200 opacity-0 group-hover:opacity-100"
                        >
                          <X size={12} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={resetForm}
                className="flex-1 py-3 px-4 btn-dev-secondary font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || !formData.name.trim() || formData.imageFiles.length === 0}
                className="flex-1 py-3 px-4 btn-dev-primary font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <LoadingSpinner size="sm" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save size={16} />
                    Save Product
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      ) : (
        <>
          {/* Products Grid */}
          {products.length > 0 ? (
            <div className="space-y-4">
              {/* Stats */}
              <div className="text-center">
                <div className="inline-flex items-center gap-2 bg-dev-tertiary rounded-xl px-4 py-2">
                  <Package size={16} className="text-electric-400" />
                  <span className="text-sm font-medium dev-text-light">
                    {products.length} product{products.length !== 1 ? 's' : ''} saved
                  </span>
                </div>
              </div>

              {/* Products List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto">
                {products.map((product) => (
                  <div 
                    key={product.id} 
                    className={`card-dev p-4 transition-all duration-200 hover:scale-105 ${
                      showSelectMode && selectedProductId === product.id 
                        ? 'border-electric-400 bg-electric-400/10' 
                        : ''
                    }`}
                  >
                    {/* Product Image */}
                    <div className="aspect-square bg-dev-tertiary rounded-xl overflow-hidden mb-4 border border-dev-light">
                      {product.image_urls.length > 0 ? (
                        <img
                          src={product.image_urls[0]}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="w-12 h-12 text-gray-500" />
                        </div>
                      )}
                    </div>

                    {/* Product Info */}
                    <div className="text-center mb-4">
                      <h3 className="text-lg font-semibold dev-heading mb-2">{product.name}</h3>
                      <div className="flex items-center justify-center gap-4 text-sm dev-text-muted">
                        <div className="flex items-center gap-1">
                          <Camera size={14} />
                          <span>{product.image_urls.length} photos</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Grid3X3 size={14} />
                          <span>@{product.reference_tag}</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Button */}
                    {showSelectMode ? (
                      <button
                        onClick={() => onSelectProduct?.(product)}
                        className={`w-full py-3 px-4 font-semibold rounded-xl transition-all duration-200 flex items-center justify-center gap-2 ${
                          selectedProductId === product.id
                            ? 'bg-electric-500 text-white'
                            : 'btn-dev-primary'
                        }`}
                      >
                        <Video size={16} />
                        {selectedProductId === product.id ? 'Selected' : 'Use for Video'}
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          // Store selected product in localStorage for homepage
                          localStorage.setItem('selectedProduct', JSON.stringify(product));
                          // Navigate to homepage
                          window.location.href = '/?from=products';
                        }}
                        className="w-full py-3 px-4 btn-dev-primary font-semibold flex items-center justify-center gap-2"
                      >
                        <Video size={16} />
                        Create Video
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Empty State */
            <div className="text-center py-12 max-w-md mx-auto">
              <div className="w-20 h-20 bg-dev-tertiary rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Package className="w-10 h-10 text-gray-500" />
              </div>
              <h2 className="text-xl font-semibold dev-heading mb-3">No Products Yet</h2>
              <p className="dev-text mb-6 leading-relaxed">
                Save your products to create videos faster next time
              </p>
            </div>
          )}

          {/* Add Product Button */}
          <div className="text-center">
            {credits && credits.available_credits >= 30 ? (
              <button
                onClick={() => setShowAddForm(true)}
                className="btn-dev-primary py-4 px-8 font-semibold flex items-center gap-3 mx-auto text-lg shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <Plus size={20} />
                Add New Product
              </button>
            ) : (
              <div className="space-y-4">
                <div className="alert-dev-warning p-4 rounded-xl max-w-md mx-auto">
                  <p className="text-sm font-medium">
                    You need 30 credits to add a new product
                  </p>
                  <p className="text-xs mt-1 opacity-80">
                    Current balance: {credits?.available_credits || 0} credits
                  </p>
                </div>
                <button
                  onClick={() => setShowPricing?.(true)}
                  className="btn-dev-secondary py-3 px-6 font-semibold flex items-center gap-2 mx-auto"
                >
                  <CreditCard size={16} />
                  Get More Credits
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default MyProducts;