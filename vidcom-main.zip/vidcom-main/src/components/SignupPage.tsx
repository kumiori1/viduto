import React, { useState } from 'react';
import { Eye, EyeOff, Mail, Lock, UserPlus, ArrowRight, Home, CheckCircle } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';
import SEOHead from './SEOHead';

const SignupPage: React.FC = () => {
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const validatePassword = (password: string) => {
    if (password.length < 8) {
      return 'Password must be at least 8 characters long';
    }
    if (!/[A-Z]/.test(password)) {
      return 'Password must contain at least one uppercase letter';
    }
    if (!/[a-z]/.test(password)) {
      return 'Password must contain at least one lowercase letter';
    }
    if (!/\d/.test(password)) {
      return 'Password must contain at least one number';
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
      return 'Password must contain at least one special character';
    }
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setAlert(null);

    if (!email.trim() || !password.trim()) {
      setAlert({ type: 'error', message: 'Please fill in all fields' });
      setLoading(false);
      return;
    }

    const passwordError = validatePassword(password);
    if (passwordError) {
      setAlert({ type: 'error', message: passwordError });
      setLoading(false);
      return;
    }

    try {
      const { error } = await signUp(email, password);
      if (error) {
        if (error.message.includes('Database error saving new user') || error.message.includes('unexpected_failure')) {
          setAlert({ type: 'success', message: 'Account created successfully! Please sign in.' });
          setTimeout(() => {
            navigate('/login');
          }, 1500);
        } else {
          setAlert({ type: 'error', message: error.message });
        }
      } else {
        setAlert({ type: 'success', message: 'Account created successfully!' });
        setTimeout(() => {
          navigate('/dashboard');
        }, 1000);
      }
    } catch (error) {
      setAlert({ type: 'error', message: 'An unexpected error occurred. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen neo-cyber-bg relative">
      <SEOHead
        title="Sign Up | VidCom AI - Create Your Free Account"
        description="Create your free VidCom AI account and get 40 free credits to start generating professional product videos with AI. No credit card required."
        keywords="VidCom AI signup, create account, free trial, AI video generation, product videos"
        canonicalUrl="https://vidcom.ai/signup"
      />

      {/* Background Auras */}
      <div className="cyber-aura-1"></div>
      <div className="cyber-aura-2"></div>
      <div className="cyber-aura-3"></div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between p-4 lg:p-6">
        <div className="flex items-center gap-6">
          <img 
            src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
            alt="VidCom AI" 
            className="h-16 lg:h-20 w-auto object-contain"
          />
          
          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6">
            <a
              href="/"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              Home
            </a>
            <a
              href="/faq"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              FAQ
            </a>
            <a
              href="/contact"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              Contact
            </a>
            <a
              href="/pricing"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              Pricing
            </a>
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <a
            href="/login"
            className="text-black hover:text-electric-600 transition-all duration-200 text-sm lg:text-base font-semibold px-3 lg:px-4 py-2 rounded-xl hover:bg-electric-100/50"
          >
            Sign In
          </a>
          <span className="text-electric-600 font-semibold text-sm lg:text-base">
            Get Started
          </span>
        </div>
      </header>

      <div className="relative z-10 flex items-center justify-center min-h-[calc(100vh-120px)] px-4">
        <div className="w-full max-w-md">
          {/* Signup Form */}
          <div className="card-cyber p-8">
            <div className="text-center mb-8">
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2 heading-cyber">
                Get Started with VidCom AI
              </h1>
              <p className="text-gray-700 text-cyber">
                Create your account and get 40 free credits
              </p>
            </div>

            {/* Free Credits Highlight */}
            <div className="bg-gradient-to-r from-electric-50 to-lavender-50 border border-electric-200 rounded-2xl p-4 mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-electric-500 to-lavender-500 flex items-center justify-center shadow-lg">
                  <CheckCircle className="text-white" size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 heading-cyber">Free Trial Included</h3>
                  <p className="text-sm text-gray-700">40 credits to create your first videos</p>
                </div>
              </div>
            </div>

            {alert && (
              <Alert
                type={alert.type}
                message={alert.message}
                onClose={() => setAlert(null)}
                className="mb-6"
              />
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-900">
                  Email Address
                </label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 flex items-center justify-center">
                    <Mail className="text-electric-600" size={14} />
                  </div>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full pl-14 pr-4 py-3.5 input-cyber text-base"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-900">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 flex items-center justify-center">
                    <Lock className="text-electric-600" size={14} />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Create a strong password"
                    className="w-full pl-14 pr-14 py-3.5 input-cyber text-base"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-lg bg-electric-300/20 hover:bg-electric-300/30 flex items-center justify-center text-electric-600 hover:text-electric-700 transition-all duration-200"
                  >
                    {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
                
                {/* Password Requirements */}
                <div className="mt-3 text-xs text-gray-600 space-y-1">
                  <p className="font-medium">Password must contain:</p>
                  <ul className="list-disc list-inside space-y-0.5 ml-2">
                    <li>At least 8 characters</li>
                    <li>One uppercase letter (A-Z)</li>
                    <li>One lowercase letter (a-z)</li>
                    <li>One number (0-9)</li>
                    <li>One special character (!@#$%^&*)</li>
                  </ul>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 px-6 btn-cyber-primary font-semibold flex items-center justify-center gap-3 text-base hover-cyber micro-cyber glow-cyber-electric disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <LoadingSpinner size="sm" />
                    Creating Account...
                  </>
                ) : (
                  <>
                    <UserPlus size={16} />
                    Create Account
                    <ArrowRight size={16} />
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-gray-600 text-sm mb-3">
                Already have an account?
              </p>
              <a
                href="/login"
                className="btn-cyber-secondary py-3 px-6 font-semibold inline-flex items-center gap-2"
              >
                Sign In Instead
                <ArrowRight size={16} />
              </a>
            </div>
          </div>

          {/* Benefits */}
          <div className="mt-8 card-cyber p-6">
            <h2 className="text-lg font-bold text-gray-900 mb-4 text-center heading-cyber">
              What You Get
            </h2>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
                  <CheckCircle className="text-green-600" size={16} />
                </div>
                <span className="text-sm text-gray-700">40 free credits to start</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-electric-100 flex items-center justify-center">
                  <CheckCircle className="text-electric-600" size={16} />
                </div>
                <span className="text-sm text-gray-700">Professional video generation</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-lavender-100 flex items-center justify-center">
                  <CheckCircle className="text-lavender-600" size={16} />
                </div>
                <span className="text-sm text-gray-700">No credit card required</span>
              </div>
            </div>
          </div>

          {/* Back to Home */}
          <div className="text-center mt-8">
            <a
              href="/"
              className="text-gray-600 hover:text-electric-600 transition-colors inline-flex items-center gap-2 font-medium"
            >
              <Home size={16} />
              Back to Home
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignupPage;