import React, { useState } from 'react';
import { Mail, Send, MessageCircle, Clock, CheckCircle, ArrowLeft, HelpCircle, Phone, MapPin } from 'lucide-react';
import LoadingSpinner from './ui/LoadingSpinner';
import Alert from './ui/Alert';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [alert, setAlert] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);

    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setAlert({ type: 'error', message: 'Please fill in all required fields' });
      return;
    }

    if (!formData.email.includes('@')) {
      setAlert({ type: 'error', message: 'Please enter a valid email address' });
      return;
    }

    setIsSubmitting(true);

    try {
      // Create mailto link with form data
      const subject = encodeURIComponent(formData.subject || 'Contact from VidCom AI Website');
      const body = encodeURIComponent(
        `Name: ${formData.name}\nEmail: ${formData.email}\n\nMessage:\n${formData.message}`
      );
      
      // Open email client
      window.location.href = `mailto:help.vidcom@gmail.com?subject=${subject}&body=${body}`;
      
      // Show success message
      setIsSubmitted(true);
      setAlert({ type: 'success', message: 'Email client opened! We\'ll get back to you within 24 hours.' });
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      });
    } catch (error) {
      setAlert({ type: 'error', message: 'Failed to open email client. Please email us directly at help.vidcom@gmail.com' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen neo-cyber-bg relative flex items-center justify-center">
        <div className="cyber-aura-1"></div>
        <div className="cyber-aura-2"></div>
        
        <div className="max-w-md mx-auto px-4">
          <div className="card-cyber p-8 text-center">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center mx-auto mb-6 shadow-lg">
              <CheckCircle className="text-white" size={40} />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-4 heading-cyber">
              Email Client Opened!
            </h1>
            <p className="text-gray-700 mb-6 text-cyber-large">
              Your email client should have opened with our contact details. We'll get back to you within 24 hours.
            </p>
            <div className="space-y-3">
              <button
                onClick={() => window.location.href = '/'}
                className="w-full btn-cyber-primary py-3 px-6 font-semibold flex items-center justify-center gap-2"
              >
                <ArrowLeft size={16} />
                Back to Home
              </button>
              <p className="text-sm text-gray-600">
                Or email us directly: <a href="mailto:help.vidcom@gmail.com" className="text-electric-600 font-semibold">help.vidcom@gmail.com</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen neo-cyber-bg relative">
      {/* Background Auras */}
      <div className="cyber-aura-1"></div>
      <div className="cyber-aura-2"></div>
      <div className="cyber-aura-3"></div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between p-4 lg:p-6">
        <div className="flex items-center gap-3">
          <img 
            src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
            alt="VidCom AI" 
            className="h-20 lg:h-28 w-auto object-contain mx-auto mb-6"
          />
          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6">
            <a
              href="/"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              Home
            </a>
            <a
              href="/pricing"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              Pricing
            </a>
            <a
              href="/faq"
              className="text-black hover:text-electric-600 transition-all duration-200 text-base font-medium"
            >
              FAQ
            </a>
            <span className="text-electric-600 font-semibold text-base">
              Contact
            </span>
          </nav>
        </div>
        <div className="flex items-center gap-3">
          <a
            href="/login"
            className="text-black hover:text-electric-600 transition-all duration-200 text-sm lg:text-base font-semibold px-3 lg:px-4 py-2 rounded-xl hover:bg-electric-100/50"
          >
            Sign In
          </a>
          <a
            href="/signup"
            className="btn-cyber-primary py-2 px-4 lg:px-6 font-semibold text-sm lg:text-base shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Get Started
          </a>
        </div>
      </header>

      <div className="relative z-10 max-w-6xl mx-auto px-4 py-8 lg:py-12">
        {/* Page Header */}
        <div className="text-center mb-8 lg:mb-12">
          <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4 heading-cyber-large">
            Contact Us
          </h1>
          <p className="text-lg text-gray-700 max-w-2xl mx-auto text-cyber-large">
            Have questions about VidCom AI? We're here to help you create amazing product videos
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Contact Form */}
          <div className="card-cyber p-6 lg:p-8">
            <h2 className="text-xl font-bold text-gray-900 mb-6 heading-cyber flex items-center gap-3">
              <Send className="text-electric-500" size={24} />
              Send us a Message
            </h2>

            {alert && (
              <Alert
                type={alert.type}
                message={alert.message}
                onClose={() => setAlert(null)}
                className="mb-6"
              />
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-900">
                  Full Name *
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Enter your full name"
                  className="w-full px-4 py-3 input-cyber text-base"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-900">
                  Email Address *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="Enter your email address"
                  className="w-full px-4 py-3 input-cyber text-base"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-900">
                  Subject
                </label>
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  placeholder="What's this about?"
                  className="w-full px-4 py-3 input-cyber text-base"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-900">
                  Message *
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  placeholder="Tell us how we can help you..."
                  rows={5}
                  className="w-full px-4 py-3 input-cyber text-base resize-none"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 px-6 btn-cyber-primary font-semibold flex items-center justify-center gap-3 text-base hover-cyber micro-cyber glow-cyber-electric disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <LoadingSpinner size="sm" />
                    Sending Message...
                  </>
                ) : (
                  <>
                    <Send size={20} />
                    Send Message
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            {/* Direct Contact */}
            <div className="card-cyber p-6 lg:p-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6 heading-cyber flex items-center gap-3">
                <Mail className="text-electric-500" size={24} />
                Direct Contact
              </h2>
              
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-electric-100 flex items-center justify-center">
                    <Mail className="text-electric-600" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 heading-cyber">Email Support</h3>
                    <a 
                      href="mailto:help.vidcom@gmail.com"
                      className="text-electric-600 hover:text-electric-700 transition-colors font-medium"
                    >
                      help.vidcom@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-lavender-100 flex items-center justify-center">
                    <Clock className="text-lavender-600" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 heading-cyber">Response Time</h3>
                    <p className="text-gray-700 text-cyber">Within 24 hours</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Help */}
            <div className="card-cyber p-6 lg:p-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6 heading-cyber flex items-center gap-3">
                <HelpCircle className="text-electric-500" size={24} />
                Quick Help
              </h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2 heading-cyber">Common Questions</h3>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li>• How do credits work?</li>
                    <li>• What video formats do you support?</li>
                    <li>• How long does video generation take?</li>
                    <li>• Can I cancel my subscription?</li>
                  </ul>
                  <button
                    onClick={() => window.location.href = '/faq'}
                    className="mt-3 text-electric-600 hover:text-electric-700 font-semibold text-sm transition-colors"
                  >
                    View All FAQs →
                  </button>
                </div>

                <div>
                  <h3 className="font-semibold text-gray-900 mb-2 heading-cyber">Technical Issues</h3>
                  <p className="text-sm text-gray-700 text-cyber">
                    If you're experiencing technical problems, please include:
                  </p>
                  <ul className="mt-2 space-y-1 text-xs text-gray-600">
                    <li>• Your browser and version</li>
                    <li>• Steps to reproduce the issue</li>
                    <li>• Any error messages you see</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Business Hours */}
            <div className="card-cyber p-6 lg:p-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6 heading-cyber flex items-center gap-3">
                <Clock className="text-electric-500" size={24} />
                Support Hours
              </h2>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-900 font-medium">Monday - Friday</span>
                  <span className="text-gray-700">9:00 AM - 6:00 PM EST</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-900 font-medium">Saturday</span>
                  <span className="text-gray-700">10:00 AM - 4:00 PM EST</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-900 font-medium">Sunday</span>
                  <span className="text-gray-700">Closed</span>
                </div>
              </div>
              
              <div className="mt-4 p-3 bg-electric-50 rounded-lg border border-electric-200">
                <p className="text-sm text-electric-700 font-medium">
                  💡 For urgent issues, email us anytime - we monitor our inbox 24/7
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="mt-12 text-center card-cyber p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 heading-cyber">
            Ready to Start Creating?
          </h2>
          <p className="text-gray-700 mb-6 text-cyber-large">
            Join thousands of businesses creating professional product videos with AI
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => window.location.href = '/'}
              className="btn-cyber-primary py-3 px-6 font-semibold flex items-center justify-center gap-2 text-base"
            >
              <MessageCircle size={16} />
              Try Free Video
            </button>
            <button
              onClick={() => window.location.href = '/faq'}
              className="btn-cyber-secondary py-3 px-6 font-semibold flex items-center justify-center gap-2 text-base"
            >
              <HelpCircle size={16} />
              View FAQ
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;