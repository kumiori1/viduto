import React from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import SideNavigation from './SideNavigation';

interface GlobalHamburgerMenuProps {
  onShowPricing?: () => void;
}

const GlobalHamburgerMenu: React.FC<GlobalHamburgerMenuProps> = ({ onShowPricing }) => {
  const { user } = useAuth();
  const location = useLocation();

  // Don't show on auth pages or if user is not logged in
  const hideOnPaths = ['/login', '/signup', '/reset-password'];
  const shouldHide = !user || hideOnPaths.includes(location.pathname);

  if (shouldHide) {
    return null;
  }

  return (
    <SideNavigation 
      onShowPricing={onShowPricing}
      className="lg:hidden" // Only show on mobile/tablet
    />
  );
};

export default GlobalHamburgerMenu;