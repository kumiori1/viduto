import React from 'react';
import { Menu } from 'lucide-react';

interface HamburgerButtonProps {
  onClick: () => void;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'glass' | 'solid';
}

const HamburgerButton: React.FC<HamburgerButtonProps> = ({ 
  onClick, 
  className = '',
  size = 'md',
  variant = 'glass'
}) => {
  const getSizeClasses = () => {
    switch (size) {
      case 'sm': return 'p-2 w-10 h-10';
      case 'md': return 'p-3 w-12 h-12';
      case 'lg': return 'p-4 w-14 h-14';
      default: return 'p-3 w-12 h-12';
    }
  };

  const getVariantClasses = () => {
    switch (variant) {
      case 'glass':
        return 'bg-white/90 backdrop-blur-sm border border-gray-200/50 shadow-lg hover:shadow-xl';
      case 'solid':
        return 'bg-white border border-gray-200 shadow-md hover:shadow-lg';
      case 'default':
      default:
        return 'bg-white/80 backdrop-blur-sm border border-gray-200/30 shadow-md hover:shadow-lg';
    }
  };

  const getIconSize = () => {
    switch (size) {
      case 'sm': return 16;
      case 'md': return 20;
      case 'lg': return 24;
      default: return 20;
    }
  };

  return (
    <button
      onClick={onClick}
      className={`
        fixed top-4 right-4 z-50 
        ${getSizeClasses()}
        ${getVariantClasses()}
        rounded-xl 
        transition-all duration-200 
        hover:scale-105 
        active:scale-95
        flex items-center justify-center
        ${className}
      `}
      aria-label="Open navigation menu"
      style={{ 
        position: 'fixed',
        top: '1rem',
        right: '1rem',
        zIndex: 50
      }}
    >
      <Menu size={getIconSize()} className="text-gray-700" />
    </button>
  );
};

export default HamburgerButton;