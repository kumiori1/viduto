import React from 'react';
import { AlertCircle, CheckCircle, XCircle, Info, X, Sparkles, Zap, Shield, Clock } from 'lucide-react';

interface AlertProps {
  type: 'success' | 'error' | 'warning' | 'info';
  title?: string;
  message: string | React.ReactNode;
  onClose?: () => void;
  className?: string;
}

const Alert: React.FC<AlertProps> = ({ type, title, message, onClose, className = '' }) => {
  const getAlertConfig = () => {
    switch (type) {
      case 'success':
        return {
          bgClass: 'bg-gradient-to-r from-green-50/80 to-emerald-50/80 border-green-200/50',
          iconBgClass: 'bg-green-100/80',
          iconClass: 'text-green-600',
          textClass: 'text-green-800',
          titleClass: 'text-green-900',
          icon: CheckCircle,
          accentIcon: Sparkles
        };
      case 'error':
        return {
          bgClass: 'bg-gradient-to-r from-red-50/80 to-rose-50/80 border-red-200/50',
          iconBgClass: 'bg-red-100/80',
          iconClass: 'text-red-600',
          textClass: 'text-red-800',
          titleClass: 'text-red-900',
          icon: XCircle,
          accentIcon: AlertCircle
        };
      case 'warning':
        return {
          bgClass: 'bg-gradient-to-r from-amber-50/80 to-yellow-50/80 border-amber-200/50',
          iconBgClass: 'bg-amber-100/80',
          iconClass: 'text-amber-600',
          textClass: 'text-amber-800',
          titleClass: 'text-amber-900',
          icon: AlertCircle,
          accentIcon: Clock
        };
      case 'info':
        return {
          bgClass: 'bg-gradient-to-r from-electric-50/80 to-blue-50/80 border-electric-200/50',
          iconBgClass: 'bg-electric-100/80',
          iconClass: 'text-electric-600',
          textClass: 'text-electric-800',
          titleClass: 'text-electric-900',
          icon: Info,
          accentIcon: Zap
        };
      default:
        return {
          bgClass: 'bg-gradient-to-r from-gray-50/80 to-slate-50/80 border-gray-200/50',
          iconBgClass: 'bg-gray-100/80',
          iconClass: 'text-gray-600',
          textClass: 'text-gray-800',
          titleClass: 'text-gray-900',
          icon: Info,
          accentIcon: Shield
        };
    }
  };

  const config = getAlertConfig();
  const MainIcon = config.icon;
  const AccentIcon = config.accentIcon;

  return (
    <div className={`
      relative overflow-hidden rounded-2xl border backdrop-blur-xl
      ${config.bgClass}
      shadow-lg shadow-black/5
      animate-fade-cyber
      ${className}
    `}>
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent pointer-events-none" />
      
      {/* Main content */}
      <div className="relative p-4 lg:p-5">
        <div className="flex items-start gap-3 lg:gap-4">
          {/* Icon container with glassmorphism */}
          <div className={`
            flex-shrink-0 w-10 h-10 lg:w-12 lg:h-12 rounded-xl
            ${config.iconBgClass}
            backdrop-blur-sm border border-white/30
            flex items-center justify-center
            shadow-lg shadow-black/10
            relative overflow-hidden
          `}>
            {/* Icon background glow */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/40 to-transparent" />
            <MainIcon className={`${config.iconClass} relative z-10`} size={20} />
          </div>
          
          {/* Content */}
          <div className="flex-1 min-w-0">
            {title && (
              <div className="flex items-center gap-2 mb-1">
                <h4 className={`font-semibold text-sm lg:text-base ${config.titleClass}`}>
                  {title}
                </h4>
                <AccentIcon className={`${config.iconClass} opacity-60`} size={14} />
              </div>
            )}
            <p className={`text-sm lg:text-base leading-relaxed ${config.textClass} font-medium`}>
              {typeof message === 'string' ? message : message}
            </p>
          </div>
          
          {/* Close button */}
          {onClose && (
            <button
              onClick={onClose}
              className={`
                flex-shrink-0 w-8 h-8 lg:w-9 lg:h-9 rounded-xl
                ${config.iconBgClass}
                backdrop-blur-sm border border-white/30
                flex items-center justify-center
                hover:scale-105 transition-all duration-200
                shadow-md hover:shadow-lg
                group relative overflow-hidden
              `}
            >
              {/* Hover background */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
              <X className={`${config.iconClass} group-hover:scale-110 transition-transform duration-200 relative z-10`} size={16} />
            </button>
          )}
        </div>
      </div>
      
      {/* Bottom accent line */}
      <div className={`h-1 bg-gradient-to-r ${
        type === 'success' ? 'from-green-400 to-emerald-400' :
        type === 'error' ? 'from-red-400 to-rose-400' :
        type === 'warning' ? 'from-amber-400 to-yellow-400' :
        'from-electric-400 to-blue-400'
      } opacity-60`} />
    </div>
  );
};

export default Alert;