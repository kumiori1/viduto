import React, { useState, useEffect } from 'react';
import { 
  Menu, 
  X, 
  User, 
  Video, 
  Package, 
  Palette, 
  CreditCard, 
  Settings, 
  LogOut, 
  Plus,
  Home
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useVideoCredits } from '../../hooks/useVideoCredits';
import { useVideoChat } from '../../hooks/useVideoChat';
import { useLocation, useNavigate } from 'react-router-dom';

interface SideNavigationProps {
  onNavigate?: (path: string) => void;
  onShowPricing?: () => void;
  className?: string;
}

const SideNavigation: React.FC<SideNavigationProps> = ({ 
  onNavigate, 
  onShowPricing,
  className = '' 
}) => {
  const { user, signOut } = useAuth();
  const { credits } = useVideoCredits();
  const { chats } = useVideoChat();
  const location = useLocation();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);

  // Close menu when route changes
  useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  // Close menu on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen]);

  // Prevent body scroll when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  // Don't render if user is not logged in
  if (!user) {
    return null;
  }

  const handleNavigation = (path: string) => {
    setIsOpen(false);
    if (onNavigate) {
      onNavigate(path);
    } else {
      navigate(path);
    }
  };

  const handleSignOut = async () => {
    if (confirm('Are you sure you want to sign out?')) {
      setIsOpen(false);
      await signOut();
      navigate('/');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'briefing':
        return <div className="w-3 h-3 rounded-full bg-yellow-400" />;
      case 'approved':
        return <div className="w-3 h-3 rounded-full bg-blue-400" />;
      case 'generating':
        return <div className="w-3 h-3 rounded-full bg-blue-400 animate-pulse" />;
      case 'completed':
        return <div className="w-3 h-3 rounded-full bg-green-400" />;
      case 'revision':
        return <div className="w-3 h-3 rounded-full bg-orange-400" />;
      default:
        return <div className="w-3 h-3 rounded-full bg-gray-400" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'briefing': return 'Briefing';
      case 'approved': return 'Approved';
      case 'generating': return 'Generating';
      case 'completed': return 'Completed';
      case 'revision': return 'Revision';
      default: return 'Unknown';
    }
  };

  return (
    <>
      {/* Hamburger Button - Fixed Position */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed top-4 right-4 z-50 p-3 bg-white/90 backdrop-blur-sm border border-gray-200/50 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105 ${className}`}
        aria-label="Open navigation menu"
        style={{ 
          position: 'fixed',
          top: '1rem',
          right: '1rem',
          zIndex: 50
        }}
      >
        <Menu size={18} className="text-gray-700" />
      </button>

      {/* Side Menu Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-[60] overflow-hidden">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity duration-300"
            onClick={() => setIsOpen(false)}
            aria-hidden="true"
          />
          
          {/* Sidebar Panel */}
          <div className="absolute left-0 top-0 h-full w-80 max-w-[85vw] bg-dev-secondary border-r border-dev flex flex-col shadow-2xl transform transition-transform duration-300 ease-out">
            
            {/* Header Section */}
            <div className="p-4 border-b border-dev flex-shrink-0">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <a href="/" className="cursor-pointer">
                    <img 
                      src="https://i.postimg.cc/Ssm4QGCJ/vidcom-logo-removebg-preview.png" 
                      alt="VidCom AI" 
                      className="h-12 w-auto object-contain hover:opacity-80 transition-opacity"
                    />
                  </a>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="btn-dev-ghost p-2 hover:bg-dev-tertiary rounded-lg transition-colors"
                  aria-label="Close navigation menu"
                >
                  <X size={20} />
                </button>
              </div>
              
              {/* User Information */}
              <div className="flex items-center gap-3 p-3 card-dev rounded-lg">
                <div className="w-8 h-8 rounded-full bg-electric-500/20 flex items-center justify-center flex-shrink-0">
                  <User size={14} className="text-electric-300" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm dev-text-light font-medium truncate">{user.email}</p>
                  <p className="text-xs text-electric-300">{credits?.available_credits || 0} credits</p>
                </div>
              </div>
            </div>

            {/* New Project Button */}
            <div className="p-4 flex-shrink-0">
              <button
                onClick={() => handleNavigation('/')}
                className="w-full py-3 px-4 bg-gradient-to-r from-electric-500 to-electric-600 hover:from-electric-600 hover:to-electric-700 text-white rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <Plus size={16} />
                New Project
              </button>
            </div>

            {/* Recent Chats Section */}
            <div className="flex-1 min-h-0 overflow-hidden px-4 pb-4">
              <div className="mb-3">
                <h3 className="text-sm font-medium dev-text-light flex items-center gap-2">
                  <Video size={16} className="text-electric-300" />
                  Recent Projects
                </h3>
              </div>
              
              <div className="h-full overflow-y-auto space-y-2">
                {chats.length > 0 ? (
                  chats.map((chat) => (
                    <button
                      key={chat.id}
                      onClick={() => {
                        setIsOpen(false);
                        if (onNavigate) {
                          onNavigate(`/dashboard/chat/${chat.id}`);
                        } else {
                          navigate(`/dashboard/chat/${chat.id}`);
                        }
                      }}
                      className="w-full text-left p-3 rounded-md transition-colors card-dev hover:bg-dev-tertiary"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <Video size={12} className="text-electric-400" />
                        <span className="text-sm font-medium truncate dev-text">{chat.title}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(chat.status)}
                        <span className="text-xs dev-text-muted">{getStatusText(chat.status)}</span>
                      </div>
                      <div className="text-xs dev-text-muted mt-1">
                        {new Date(chat.created_at).toLocaleDateString()}
                      </div>
                    </button>
                  ))
                ) : (
                  <div className="text-center py-4 px-3 bg-dev-tertiary rounded-lg border border-dev-light">
                    <Video size={24} className="text-gray-500 mx-auto mb-2" />
                    <p className="text-xs dev-text-muted">No projects yet</p>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Navigation Menu */}
            <div className="p-4 border-t border-dev space-y-1 flex-shrink-0">
              <button
                onClick={() => handleNavigation('/dashboard/products')}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <Package size={16} />
                My Products
              </button>
              
              <button
                onClick={() => handleNavigation('/dashboard/brand')}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <Palette size={16} />
                Brand Guidelines
              </button>
              
              <button
                onClick={() => {
                  setIsOpen(false);
                  onShowPricing?.();
                }}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <CreditCard size={16} />
                Manage Subscription
              </button>
              
              <button
                onClick={() => handleNavigation('/dashboard/settings')}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm dev-text hover:dev-text-light hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <Settings size={16} />
                Settings
              </button>
              
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-dev-tertiary rounded-lg transition-all duration-200"
              >
                <LogOut size={16} />
                Log Out
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default SideNavigation;