import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import HomePage from './components/HomePage';
import FAQPage from './components/FAQPage';
import ContactPage from './components/ContactPage';
import PricingPage from './components/PricingPage';
import LoginPage from './components/LoginPage';
import SignupPage from './components/SignupPage';
import Dashboard from './components/Dashboard';
import SuccessPage from './components/checkout/SuccessPage';
import ResetPasswordPage from './components/auth/ResetPasswordPage';
import SEOHead from './components/SEOHead';
import StructuredData, { OrganizationSchema, ServiceSchema } from './components/StructuredData';
import GlobalHamburgerMenu from './components/ui/GlobalHamburgerMenu';
import PricingModal from './components/PricingModal';

function App() {
  const { user, loading } = useAuth();
  const [showPricing, setShowPricing] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <Router>
      <SEOHead
        title="VidCom AI | AI-Powered Product Video Generation"
        description="Transform your product images into cinematic marketing videos using AI. No agencies, no waiting. Professional videos in minutes."
        keywords="AI video generation, product videos, marketing videos, AI video creator, automated video production"
        canonicalUrl="https://vidcom.ai"
        structuredData={OrganizationSchema}
      />
      
      <StructuredData schema={ServiceSchema} />
      
      {/* Global Hamburger Menu - Available on all screens for logged-in users */}
      <GlobalHamburgerMenu onShowPricing={() => setShowPricing(true)} />
      
      {/* Global Pricing Modal */}
      <PricingModal
        isOpen={showPricing}
        onClose={() => setShowPricing(false)}
        onAuthRequired={() => {}}
      />
      
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/faq" element={<FAQPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/pricing" element={<PricingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/dashboard" element={user ? <Dashboard /> : <Navigate to="/" replace />} />
        <Route path="/dashboard/products" element={user ? <Dashboard initialTab="products" /> : <Navigate to="/" replace />} />
        <Route path="/dashboard/brand" element={user ? <Dashboard initialTab="brand" /> : <Navigate to="/" replace />} />
        <Route path="/dashboard/settings" element={user ? <Dashboard initialTab="settings" /> : <Navigate to="/" replace />} />
        <Route path="/dashboard/subscription" element={user ? <Dashboard initialTab="subscription" /> : <Navigate to="/" replace />} />
        <Route path="/dashboard/chat/:chatId" element={user ? <Dashboard /> : <Navigate to="/" replace />} />
        <Route path="/success" element={<SuccessPage />} />
        <Route path="/reset-password" element={<ResetPasswordPage />} />
      </Routes>
    </Router>
  );
}

export default App;