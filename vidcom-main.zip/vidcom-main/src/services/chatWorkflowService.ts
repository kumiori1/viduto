import { ChatMessage, VideoChat, WorkflowState, ProductionStep } from '../types/chat';
import { generateVideoBrief, generateChatResponse, updateVideoBrief } from '../lib/anthropic';

export class ChatWorkflowService {
  private static instance: ChatWorkflowService;
  
  static getInstance(): ChatWorkflowService {
    if (!ChatWorkflowService.instance) {
      ChatWorkflowService.instance = new ChatWorkflowService();
    }
    return ChatWorkflowService.instance;
  }

  // Generate chat response using Anthropic
  async generateChatResponse(chatHistory: Array<{role: string, content: string}>): Promise<string> {
    try {
      return await generateChatResponse(chatHistory);
    } catch (error) {
      console.error('Error generating chat response:', error);
      return 'I understand your request. Let me help you with that.';
    }
  }

  // Production steps configuration
  private productionSteps: ProductionStep[] = [
    { id: 'script', name: 'Script Planning', description: 'Analyzing your brief and creating the video script', duration: 3000, status: 'pending', progress: 0 },
    { id: 'analysis', name: 'Product Analysis', description: 'Processing your product images and details', duration: 2500, status: 'pending', progress: 0 },
    { id: 'frames', name: 'Frame Generation', description: 'Creating video frames and visual elements', duration: 4000, status: 'pending', progress: 0 },
    { id: 'voiceover', name: 'Voiceover Creation', description: 'Generating professional voiceover', duration: 3500, status: 'pending', progress: 0 },
    { id: 'music', name: 'Music Composition', description: 'Adding background music and sound effects', duration: 2000, status: 'pending', progress: 0 },
    { id: 'assembly', name: 'Final Assembly', description: 'Combining all elements into final video', duration: 3000, status: 'pending', progress: 0 }
  ];

  // Determine workflow phase based on message content and current state
  determineWorkflowAction(message: string, currentState: WorkflowState): {
    action: 'generate_brief' | 'revise_brief' | 'approve_brief' | 'start_production' | 'request_revision' | 'general_chat';
    confidence: number;
  } {
    const lowerMessage = message.toLowerCase().trim();
    
    // Approval keywords (multiple languages)
    const approvalKeywords = ['approve', 'approved', 'yes', 'ok', 'good', 'perfect', 'אישור', 'אשר', 'כן', 'מאושר', 'בסדר'];
    const isApproval = approvalKeywords.some(keyword => lowerMessage.includes(keyword));
    
    // Revision keywords
    const revisionKeywords = ['change', 'modify', 'different', 'instead', 'but', 'however', 'שנה', 'תקן', 'אבל', 'במקום'];
    const isRevisionRequest = revisionKeywords.some(keyword => lowerMessage.includes(keyword));
    
    // Based on current phase and message content
    switch (currentState.phase) {
      case 'initial':
        return { action: 'generate_brief', confidence: 0.9 };
        
      case 'brief_review':
        if (isApproval && !isRevisionRequest) {
          return { action: 'approve_brief', confidence: 0.95 };
        } else if (isRevisionRequest || lowerMessage.length > 10) {
          return { action: 'revise_brief', confidence: 0.8 };
        }
        return { action: 'general_chat', confidence: 0.6 };
        
      case 'production':
        return { action: 'general_chat', confidence: 0.7 };
        
      case 'delivery':
      case 'post_production':
        if (isRevisionRequest || lowerMessage.includes('change')) {
          return { action: 'request_revision', confidence: 0.85 };
        }
        return { action: 'general_chat', confidence: 0.7 };
        
      default:
        return { action: 'general_chat', confidence: 0.5 };
    }
  }

  // Generate initial brief from user description
  async generateInitialBrief(description: string, productInfo: string): Promise<ChatMessage> {
    try {
      const brief = await generateVideoBrief(description, productInfo);
      
      // Clean up the brief - remove markdown formatting
      const cleanBrief = brief
        .replace(/\*\*/g, '') // Remove bold markdown
        .replace(/\*/g, '') // Remove italic markdown
        .replace(/#{1,6}\s/g, '') // Remove headers
        .replace(/^\s*[\-\*\+]\s/gm, '• ') // Convert list items to bullets
        .trim();
      
      return {
        id: `msg_${Date.now()}_brief`,
        role: 'assistant',
        content: cleanBrief,
        timestamp: new Date().toISOString(),
        type: 'brief'
      };
    } catch (error) {
      console.error('Error generating brief:', error);
      throw new Error('Failed to generate video brief');
    }
  }

  // Create approval request message
  createApprovalRequest(): ChatMessage {
    return {
      id: `msg_${Date.now()}_approval`,
      role: 'system',
      content: 'What would you like to do next?\n\nYou can approve this brief to start video production, or describe any changes you would like me to make.\n\nI am here to help you get the perfect video brief before we start production!',
      timestamp: new Date().toISOString(),
      type: 'approval_request'
    };
  }

  // Revise brief based on user feedback
  async reviseBrief(originalBrief: string, userFeedback: string, productInfo: string): Promise<ChatMessage> {
    try {
      const revisedBrief = await updateVideoBrief(originalBrief, userFeedback, productInfo);
      
      // Clean up the revised brief
      const cleanRevisedBrief = revisedBrief
        .replace(/\*\*/g, '')
        .replace(/\*/g, '')
        .replace(/#{1,6}\s/g, '')
        .replace(/^\s*[\-\*\+]\s/gm, '• ')
        .trim();
      
      return {
        id: `msg_${Date.now()}_revised_brief`,
        role: 'assistant',
        content: cleanRevisedBrief,
        timestamp: new Date().toISOString(),
        type: 'brief'
      };
    } catch (error) {
      console.error('Error revising brief:', error);
      throw new Error('Failed to revise video brief');
    }
  }

  // Create production start confirmation
  createProductionStartMessage(): ChatMessage {
    return {
      id: `msg_${Date.now()}_production_start`,
      role: 'assistant',
      content: 'Perfect! Starting video production now...\n\nYour video is being created with real-time progress updates.',
      timestamp: new Date().toISOString(),
      type: 'production_status',
      metadata: { 
        current_step: 'script',
        progress: 0,
        steps: [
          { id: 'script', name: 'Script Planning', status: 'active' },
          { id: 'analysis', name: 'Product Analysis', status: 'pending' },
          { id: 'frames', name: 'Frame Generation', status: 'pending' },
          { id: 'voiceover', name: 'Voiceover Creation', status: 'pending' },
          { id: 'music', name: 'Music Composition', status: 'pending' },
          { id: 'assembly', name: 'Final Assembly', status: 'pending' }
        ]
      }
    };
  }

  // Update production status message
  updateProductionStatusMessage(currentStepId: string, progress: number): ChatMessage {
    const steps = [
      { id: 'script', name: 'Script Planning', status: 'pending' },
      { id: 'analysis', name: 'Product Analysis', status: 'pending' },
      { id: 'frames', name: 'Frame Generation', status: 'pending' },
      { id: 'voiceover', name: 'Voiceover Creation', status: 'pending' },
      { id: 'music', name: 'Music Composition', status: 'pending' },
      { id: 'assembly', name: 'Final Assembly', status: 'pending' }
    ];

    // Update step statuses based on current step
    let foundCurrent = false;
    const updatedSteps = steps.map(step => {
      if (step.id === currentStepId) {
        foundCurrent = true;
        return { ...step, status: 'active' };
      } else if (!foundCurrent) {
        return { ...step, status: 'completed' };
      } else {
        return { ...step, status: 'pending' };
      }
    });

    return {
      id: `msg_production_status`,
      role: 'assistant',
      content: 'Video Production in Progress\n\nYour video is being created with AI technology.',
      timestamp: new Date().toISOString(),
      type: 'production_status',
      metadata: { 
        current_step: currentStepId,
        progress,
        steps: updatedSteps
      }
    };
  }

  // Create video delivery message
  createVideoDeliveryMessage(videoUrl: string): ChatMessage {
    return {
      id: `msg_${Date.now()}_video_delivery`,
      role: 'assistant',
      content: '🎉 Your video is ready!\n\nHere is your professional product video. You can download it or request changes if needed.',
      timestamp: new Date().toISOString(),
      type: 'video',
      metadata: { video_url: videoUrl }
    };
  }

  // Create post-production options message
  createPostProductionMessage(): ChatMessage {
    return {
      id: `msg_${Date.now()}_post_production`,
      role: 'system',
      content: 'What would you like to do next?\n\n📥 Download your video using the button above\n✏️ Request changes by describing what you would like to modify (3 credits)\n🆕 Start a new project by going back to the main page\n\nI am here to help with any adjustments you need!',
      timestamp: new Date().toISOString(),
      type: 'approval_request'
    };
  }

  // Handle revision request
  async handleRevisionRequest(userRequest: string): Promise<ChatMessage> {
    try {
      const response = await generateChatResponse([
        { role: 'user', content: userRequest },
        { role: 'system', content: 'The user wants to make changes to their completed video. Acknowledge their request and explain what changes you can make.' }
      ]);

      return {
        id: `msg_${Date.now()}_revision_response`,
        role: 'assistant',
        content: response + '\n\nReady to create the revised version?\n\n✅ Type "yes" to start revision (3 credits)\n❌ Describe more changes first',
        timestamp: new Date().toISOString(),
        type: 'revision_request',
        metadata: { revision_cost: 3 }
      };
    } catch (error) {
      console.error('Error handling revision request:', error);
      throw new Error('Failed to process revision request');
    }
  }

  // Get production steps for simulation
  getProductionSteps(): ProductionStep[] {
    return [...this.productionSteps];
  }

  // Update workflow state
  updateWorkflowState(currentState: WorkflowState, action: string): WorkflowState {
    const newState = { ...currentState };
    
    switch (action) {
      case 'generate_brief':
        newState.phase = 'brief_review';
        newState.last_action = 'brief_generated';
        break;
        
      case 'approve_brief':
        newState.phase = 'production';
        newState.brief_approved = true;
        newState.last_action = 'brief_approved';
        break;
        
      case 'revise_brief':
        newState.phase = 'brief_review';
        newState.revision_count += 1;
        newState.last_action = 'brief_revised';
        break;
        
      case 'start_production':
        newState.phase = 'production';
        newState.last_action = 'production_started';
        break;
        
      case 'complete_production':
        newState.phase = 'delivery';
        newState.last_action = 'video_delivered';
        break;
        
      case 'request_revision':
        newState.phase = 'post_production';
        newState.revision_count += 1;
        newState.last_action = 'revision_requested';
        break;
    }
    
    return newState;
  }
}

export const chatWorkflowService = ChatWorkflowService.getInstance();