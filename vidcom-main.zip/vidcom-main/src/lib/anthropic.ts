import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({
  apiKey: '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',
  dangerouslyAllowBrowser: true
});

export async function generateVideoTitle(description: string): Promise<string> {
  try {
    const response = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 20,
      temperature: 0.7,
      messages: [
        {
          role: "user",
          content: `Create a short, catchy title for this video request (2-4 words maximum): ${description}

Examples:
- "Luxury Perfume Ad"
- "Tech Product Demo"
- "Fashion Showcase"

Respond only with the title, no quotes or extra text.`
        }
      ]
    });

    return response.content[0]?.type === 'text' ? response.content[0].text.trim() : 'New Video';
  } catch (error) {
    console.error('Error generating title:', error);
    return 'New Video';
  }
}

export async function generateVideoBrief(description: string, productLink: string): Promise<string> {
  try {
    console.log('🔵 generateVideoBrief: Starting brief generation');
    
    const response = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 400,
      temperature: 0.8,
      messages: [
        {
          role: "user",
          content: `Create a concise video production brief for: ${description}
Product info: ${productLink}

IMPORTANT: Respond in clean, readable text without any markdown formatting. Do not use asterisks, hashtags, or other markdown symbols.

Format the response like this structure:

🎬 Video Concept
[One sentence describing the main goal and feeling]

📋 Storyboard
Scene 1: [Brief description - 3-5 seconds]
Scene 2: [Brief description - 3-5 seconds] 
Scene 3: [Brief description - 3-5 seconds]
Scene 4: [Brief description - 3-5 seconds]

🎙️ Voiceover Script
[Exact text for narration - conversational, engaging tone]

🎵 Music Style
[Genre/mood - e.g., "Upbeat electronic", "Calm acoustic", "Energetic pop"]

📱 Final Result
[2-3 sentences explaining how the video will look and feel to viewers]

Keep it concise and practical. Focus on visual storytelling that converts viewers into customers.`
        }
      ]
    });

    const rawResult = response.content[0]?.type === 'text' ? response.content[0].text : 'I will create a professional video based on your description. The video will showcase your product in an engaging way that captures attention and drives action.';
    
    // Clean up any markdown formatting
    const result = rawResult
      .replace(/\*\*/g, '') // Remove bold
      .replace(/\*/g, '') // Remove italic
      .replace(/#{1,6}\s/g, '') // Remove headers
      .trim();
    
    console.log('🟢 generateVideoBrief: Brief generated successfully');
    return result;
    
  } catch (error) {
    console.error('🔴 generateVideoBrief: Error generating brief:', error);
    return 'I will create a professional video based on your description. The video will showcase your product in an engaging way that captures attention and drives action. Let me know if you want any specific changes!';
  }
}

export async function generateChatResponse(messages: Array<{role: string, content: string}>): Promise<string> {
  try {
    console.log('🔵 Generating chat response with Anthropic...');
    
    const anthropicMessages = messages.map(msg => ({
      role: msg.role === 'user' ? 'user' as const : 'assistant' as const,
      content: msg.content
    }));

    const response = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 500,
      temperature: 0.8,
      system: `You are a professional video production assistant helping clients improve their video concepts.

IMPORTANT: Always respond in clean, readable text without any markdown formatting. Do not use asterisks (*), hashtags (#), or other markdown symbols. Write in plain text only.

Always respond in English. Be helpful, creative and specific about video production details. Keep responses conversational and focused on video creation. Be concise but thorough.

When a client requests changes, provide concrete suggestions for improving the video:
- Camera angle changes
- Music or pacing adjustments
- Text or message modifications
- Scene length adjustments
- Visual style changes

If the client seems satisfied, guide them toward approval. If they want changes, help them refine their ideas.`,
      messages: anthropicMessages
    });

    const rawResult = response.content[0]?.type === 'text' ? response.content[0].text : 'I understand. Let me help you with that.';
    
    // Clean up any markdown formatting that might slip through
    const result = rawResult
      .replace(/\*\*/g, '') // Remove bold
      .replace(/\*/g, '') // Remove italic
      .replace(/#{1,6}\s/g, '') // Remove headers
      .replace(/^\s*[\-\*\+]\s/gm, '• ') // Convert list items to bullets
      .trim();
    
    console.log('🟢 Chat response generated successfully');
    return result;
  } catch (error) {
    console.error('Error generating chat response:', error);
    return 'I understand your request. Let me help you refine the video concept. What specific changes would you like to make?';
  }
}

export async function updateVideoBrief(originalBrief: string, userRequest: string, productInfo: string): Promise<string> {
  try {
    const response = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 400,
      temperature: 0.8,
      messages: [
        {
          role: "user",
          content: `You are a professional video production director. I need you to update this video brief based on the client's feedback.

IMPORTANT: Respond in clean, readable text without any markdown formatting. Do not use asterisks, hashtags, or other markdown symbols.

ORIGINAL BRIEF:
${originalBrief}

CLIENT FEEDBACK:
"${userRequest}"

PRODUCT INFO:
${productInfo}

Please create an UPDATED brief that incorporates the client's feedback. Keep the same format as the original:

🎬 Video Concept
[Updated concept based on feedback]

📋 Storyboard
Scene 1: [Updated scene - 3-5 seconds]
Scene 2: [Updated scene - 3-5 seconds] 
Scene 3: [Updated scene - 3-5 seconds]
Scene 4: [Updated scene - 3-5 seconds]

🎙️ Voiceover Script
[Updated script text - incorporate the requested changes]

🎵 Music Style
[Updated music style based on feedback]

📱 Final Result
[Updated explanation of how the video will look and feel]

Focus on making the changes the client requested while maintaining professional video production standards. Be specific and actionable.`
        }
      ]
    });

    const rawResult = response.content[0]?.type === 'text' ? response.content[0].text : originalBrief;
    
    // Clean up any markdown formatting
    const result = rawResult
      .replace(/\*\*/g, '') // Remove bold
      .replace(/\*/g, '') // Remove italic
      .replace(/#{1,6}\s/g, '') // Remove headers
      .trim();
    
    return result;
  } catch (error) {
    console.error('Error updating brief:', error);
    return originalBrief;
  }
}

export async function enhancePrompt(originalPrompt: string): Promise<string> {
  try {
    const response = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 300,
      temperature: 0.8,
      messages: [
        {
          role: "user",
          content: `You are a professional video marketing expert. Take this basic video description and enhance it into a detailed, professional video brief that will result in a high-quality marketing video.

IMPORTANT: Respond in clean, readable text without any markdown formatting. Do not use asterisks, hashtags, or other markdown symbols.

Transform their simple description into a comprehensive brief that includes:
- Clear visual style and mood
- Target audience consideration
- Key selling points to highlight
- Suggested video flow and pacing
- Call-to-action recommendations

Keep the enhanced prompt concise but detailed (150-250 words). Write in English and focus on creating a brief that will result in an effective marketing video.

Example transformation:
Input: "Video for my skincare product"
Output: "Create a premium skincare product video showcasing natural ingredients and glowing results. Open with close-up shots of the elegant packaging, transition to ingredient highlights with soft, natural lighting. Show before/after transformations with real people. Use calming, spa-like music with gentle transitions. Target health-conscious women 25-45. Emphasize natural, dermatologist-tested benefits. End with clear call-to-action: 'Transform your skin today - shop now with 20% off your first order.'"

Enhance this video description: ${originalPrompt}

Respond only with the enhanced prompt, no quotes or extra text.`
        }
      ]
    });

    const rawResult = response.content[0]?.type === 'text' ? response.content[0].text.trim() : originalPrompt;
    
    // Clean up any markdown formatting
    const result = rawResult
      .replace(/\*\*/g, '') // Remove bold
      .replace(/\*/g, '') // Remove italic
      .replace(/#{1,6}\s/g, '') // Remove headers
      .trim();
    
    return result;
  } catch (error) {
    console.error('Error enhancing prompt:', error);
    throw new Error('Failed to enhance prompt');
  }
}

export { anthropic };