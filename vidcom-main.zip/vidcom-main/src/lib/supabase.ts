import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Check if Supabase is configured
export const isSupabaseConfigured = supabaseUrl && supabaseAnonKey;

// Log configuration status
console.log('Supabase configuration status:', {
  hasUrl: !!supabaseUrl,
  hasKey: !!supabaseAnonKey,
  isConfigured: isSupabaseConfigured
});

if (!isSupabaseConfigured) {
  console.warn('Supabase environment variables not configured. Running in demo mode.');
}
// Custom fetch function to handle session errors
const customFetch = async (url: RequestInfo | URL, options?: RequestInit) => {
  try {
    // Check if we have valid Supabase configuration before making requests
    if (!isSupabaseConfigured) {
      console.warn('Supabase not configured, returning mock response');
      return new Response(JSON.stringify({ 
        data: null, 
        error: { 
          message: 'Demo mode - Supabase not configured',
          code: 'demo_mode'
        } 
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const response = await fetch(url, options);
    
    // Check for 403 session_not_found errors
    if (response.status === 403) {
      try {
        const responseClone = response.clone();
        const body = await responseClone.text();
        const errorData = JSON.parse(body);
        
        if (errorData.code === 'session_not_found') {
          // Dispatch custom event to notify auth hook
          window.dispatchEvent(new CustomEvent('supabase:session_not_found'));
        }
      } catch (e) {
        // Ignore parsing errors
      }
    }
    
    return response;
  } catch (error) {
    console.warn('Supabase fetch error (using fallback):', error);
    // Return a mock error response instead of throwing
    return new Response(JSON.stringify({ 
      data: null,
      error: { 
        message: 'Demo mode - connection failed',
        code: 'demo_mode'
      } 
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};

// Export configuration status for other components to check

// Create a mock client if Supabase is not configured
const createMockSupabaseClient = () => ({
  auth: {
    getSession: () => Promise.resolve({ 
      data: { 
        session: {
          user: {
            id: 'demo-user-123',
            email: 'demo@vidcom.ai',
            created_at: new Date().toISOString()
          },
          access_token: 'demo-token'
        }
      }, 
      error: null 
    }),
    onAuthStateChange: (callback: any) => {
      // Call callback immediately with demo session
      setTimeout(() => callback('SIGNED_IN', {
        user: {
          id: 'demo-user-123',
          email: 'demo@vidcom.ai',
          created_at: new Date().toISOString()
        },
        access_token: 'demo-token'
      }), 100);
      return { data: { subscription: { unsubscribe: () => {} } } };
    },
    signInWithPassword: () => Promise.resolve({ 
      data: { 
        user: {
          id: 'demo-user-123',
          email: 'demo@vidcom.ai',
          created_at: new Date().toISOString()
        },
        session: {
          user: {
            id: 'demo-user-123',
            email: 'demo@vidcom.ai',
            created_at: new Date().toISOString()
          },
          access_token: 'demo-token'
        }
      }, 
      error: null 
    }),
    signUp: () => Promise.resolve({ 
      data: { 
        user: {
          id: 'demo-user-123',
          email: 'demo@vidcom.ai',
          created_at: new Date().toISOString()
        },
        session: {
          user: {
            id: 'demo-user-123',
            email: 'demo@vidcom.ai',
            created_at: new Date().toISOString()
          },
          access_token: 'demo-token'
        }
      }, 
      error: null 
    }),
    signOut: () => Promise.resolve({ error: null }),
    getUser: () => Promise.resolve({ 
      data: { 
        user: {
          id: 'demo-user-123',
          email: 'demo@vidcom.ai',
          created_at: new Date().toISOString()
        }
      }, 
      error: null 
    }),
    updateUser: () => Promise.resolve({ 
      data: { 
        user: {
          id: 'demo-user-123',
          email: 'demo@vidcom.ai',
          created_at: new Date().toISOString()
        }
      }, 
      error: null 
    }),
    resetPasswordForEmail: () => Promise.resolve({ error: null })
  },
  from: () => ({
    select: () => ({
      eq: () => ({
        maybeSingle: () => Promise.resolve({ 
          data: {
            id: 1,
            user_id: 'demo-user-123',
            available_credits: 100,
            total_purchased: 100,
            total_used: 0,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }, 
          error: null 
        }),
        single: () => Promise.resolve({ 
          data: {
            id: 1,
            user_id: 'demo-user-123',
            available_credits: 100,
            total_purchased: 100,
            total_used: 0,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }, 
          error: null 
        }),
        order: () => Promise.resolve({ data: [], error: null }),
        limit: () => Promise.resolve({ data: [], error: null })
      }),
      order: () => Promise.resolve({ data: [], error: null }),
      limit: () => Promise.resolve({ data: [], error: null })
    }),
    insert: () => ({
      select: () => ({
        single: () => Promise.resolve({ 
          data: {
            id: `demo-${Date.now()}`,
            user_id: 'demo-user-123',
            title: 'Demo Video',
            description: 'Demo video description',
            status: 'briefing',
            messages: [],
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }, 
          error: null 
        })
      })
    }),
    update: () => ({
      eq: () => Promise.resolve({ 
        data: {
          id: `demo-${Date.now()}`,
          user_id: 'demo-user-123',
          updated_at: new Date().toISOString()
        }, 
        error: null 
      })
    }),
    upsert: () => ({
      select: () => ({
        single: () => Promise.resolve({ 
          data: {
            id: `demo-${Date.now()}`,
            user_id: 'demo-user-123',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }, 
          error: null 
        })
      })
    })
  }),
  storage: {
    from: () => ({
      upload: () => Promise.resolve({ 
        data: { 
          path: `demo/demo-image-${Date.now()}.jpg` 
        }, 
        error: null 
      }),
      getPublicUrl: () => ({ 
        data: { 
          publicUrl: `https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=400` 
        } 
      })
    })
  },
  channel: () => ({
    on: () => ({
      subscribe: () => Promise.resolve()
    })
  }),
  removeChannel: () => {},
  rpc: (functionName: string, params?: any) => {
    // Mock RPC responses for different functions
    if (functionName === 'use_user_credits_v3') {
      return Promise.resolve({ 
        data: {
          success: true,
          credits_used: params?.video_credits_to_use || 10,
          remaining_credits: 90
        }, 
        error: null 
      });
    }
    if (functionName === 'add_user_credits_v3') {
      return Promise.resolve({ 
        data: true, 
        error: null 
      });
    }
    return Promise.resolve({ 
      data: { success: true }, 
      error: null 
    });
  }
});

export const supabase = isSupabaseConfigured 
  ? createClient(supabaseUrl!, supabaseAnonKey!, {
      global: {
        fetch: customFetch
      }
    })
  : createMockSupabaseClient() as any;
export type Database = {
  public: {
    Tables: {
      video_chats: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          description: string;
          image_urls: string[];
          image_names: string[];
          status: string;
          messages: any;
          video_url: string | null;
          credits_used: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          user_id: string;
          title: string;
          description: string;
          image_urls?: string[];
          image_names?: string[];
          status?: string;
          messages?: any;
          video_url?: string | null;
          credits_used?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          title?: string;
          description?: string;
          image_urls?: string[];
          image_names?: string[];
          status?: string;
          messages?: any;
          video_url?: string | null;
          credits_used?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      user_video_credits: {
        Row: {
          id: number;
          user_id: string;
          available_credits: number;
          total_purchased: number;
          total_used: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          available_credits?: number;
          total_purchased?: number;
          total_used?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          user_id?: string;
          available_credits?: number;
          total_purchased?: number;
          total_used?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      stripe_customers: {
        Row: {
          id: number;
          user_id: string;
          customer_id: string;
          created_at: string;
          updated_at: string;
          deleted_at: string | null;
        };
        Insert: {
          user_id: string;
          customer_id: string;
          created_at?: string;
          updated_at?: string;
          deleted_at?: string | null;
        };
        Update: {
          user_id?: string;
          customer_id?: string;
          created_at?: string;
          updated_at?: string;
          deleted_at?: string | null;
        };
      };
      stripe_subscriptions: {
        Row: {
          id: number;
          customer_id: string;
          subscription_id: string | null;
          price_id: string | null;
          current_period_start: number | null;
          current_period_end: number | null;
          cancel_at_period_end: boolean;
          payment_method_brand: string | null;
          payment_method_last4: string | null;
          status: 'not_started' | 'incomplete' | 'incomplete_expired' | 'trialing' | 'active' | 'past_due' | 'canceled' | 'unpaid' | 'paused';
          created_at: string;
          updated_at: string;
          deleted_at: string | null;
        };
        Insert: {
          customer_id: string;
          subscription_id?: string | null;
          price_id?: string | null;
          current_period_start?: number | null;
          current_period_end?: number | null;
          cancel_at_period_end?: boolean;
          payment_method_brand?: string | null;
          payment_method_last4?: string | null;
          status: 'not_started' | 'incomplete' | 'incomplete_expired' | 'trialing' | 'active' | 'past_due' | 'canceled' | 'unpaid' | 'paused';
          created_at?: string;
          updated_at?: string;
          deleted_at?: string | null;
        };
        Update: {
          customer_id?: string;
          subscription_id?: string | null;
          price_id?: string | null;
          current_period_start?: number | null;
          current_period_end?: number | null;
          cancel_at_period_end?: boolean;
          payment_method_brand?: string | null;
          payment_method_last4?: string | null;
          status?: 'not_started' | 'incomplete' | 'incomplete_expired' | 'trialing' | 'active' | 'past_due' | 'canceled' | 'unpaid' | 'paused';
          created_at?: string;
          updated_at?: string;
          deleted_at?: string | null;
        };
      };
      stripe_orders: {
        Row: {
          id: number;
          checkout_session_id: string;
          payment_intent_id: string;
          customer_id: string;
          amount_subtotal: number;
          amount_total: number;
          currency: string;
          payment_status: string;
          status: 'pending' | 'completed' | 'canceled';
          created_at: string;
          updated_at: string;
          deleted_at: string | null;
        };
        Insert: {
          checkout_session_id: string;
          payment_intent_id: string;
          customer_id: string;
          amount_subtotal: number;
          amount_total: number;
          currency: string;
          payment_status: string;
          status?: 'pending' | 'completed' | 'canceled';
          created_at?: string;
          updated_at?: string;
          deleted_at?: string | null;
        };
        Update: {
          checkout_session_id?: string;
          payment_intent_id?: string;
          customer_id?: string;
          amount_subtotal?: number;
          amount_total?: number;
          currency?: string;
          payment_status?: string;
          status?: 'pending' | 'completed' | 'canceled';
          created_at?: string;
          updated_at?: string;
          deleted_at?: string | null;
        };
      };
      user_video_requests: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          brief_description: string;
          target_platform: string;
          music_style: string;
          voiceover: string;
          language: string;
          additional_requests: string;
          images_count: number;
          image_urls: string[];
          image_names: string[];
          status: 'submitted' | 'in-progress' | 'ready';
          request_date: string;
          expected_delivery: string | null;
          video_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          user_id: string;
          title: string;
          brief_description: string;
          target_platform: string;
          music_style?: string;
          voiceover: string;
          language: string;
          additional_requests?: string;
          images_count?: number;
          image_urls?: string[];
          image_names?: string[];
          status?: 'submitted' | 'in-progress' | 'ready';
          request_date?: string;
          expected_delivery?: string | null;
          video_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          title?: string;
          brief_description?: string;
          target_platform?: string;
          music_style?: string;
          voiceover?: string;
          language?: string;
          additional_requests?: string;
          images_count?: number;
          image_urls?: string[];
          image_names?: string[];
          status?: 'submitted' | 'in-progress' | 'ready';
          request_date?: string;
          expected_delivery?: string | null;
          video_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      products: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          description: string;
          reference_tag: string;
          image_urls: string[];
          image_names: string[];
          metadata: any;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          name: string;
          description?: string;
          reference_tag: string;
          image_urls?: string[];
          image_names?: string[];
          metadata?: any;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          user_id?: string;
          name?: string;
          description?: string;
          reference_tag?: string;
          image_urls?: string[];
          image_names?: string[];
          metadata?: any;
          created_at?: string;
          updated_at?: string;
        };
      };
      brand_guidelines: {
        Row: {
          id: string;
          user_id: string;
          logo_url: string;
          primary_color: string;
          secondary_color: string;
          accent_color: string;
          font_family: string;
          title_style: string;
          body_style: string;
          mood: string;
          pace: string;
          transitions: string;
          default_prompts: any;
          style_preferences: any;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          logo_url?: string;
          primary_color?: string;
          secondary_color?: string;
          accent_color?: string;
          font_family?: string;
          title_style?: string;
          body_style?: string;
          mood?: string;
          pace?: string;
          transitions?: string;
          default_prompts?: any;
          style_preferences?: any;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          user_id?: string;
          logo_url?: string;
          primary_color?: string;
          secondary_color?: string;
          accent_color?: string;
          font_family?: string;
          title_style?: string;
          body_style?: string;
          mood?: string;
          pace?: string;
          transitions?: string;
          default_prompts?: any;
          style_preferences?: any;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
    Views: {
      stripe_user_subscriptions: {
        Row: {
          customer_id: string;
          subscription_id: string | null;
          subscription_status: 'not_started' | 'incomplete' | 'incomplete_expired' | 'trialing' | 'active' | 'past_due' | 'canceled' | 'unpaid' | 'paused';
          price_id: string | null;
          current_period_start: number | null;
          current_period_end: number | null;
          cancel_at_period_end: boolean;
          payment_method_brand: string | null;
          payment_method_last4: string | null;
        };
      };
      stripe_user_orders: {
        Row: {
          customer_id: string;
          order_id: number;
          checkout_session_id: string;
          payment_intent_id: string;
          amount_subtotal: number;
          amount_total: number;
          currency: string;
          payment_status: string;
          order_status: 'pending' | 'completed' | 'canceled';
          order_date: string;
        };
      };
    };
  };
};