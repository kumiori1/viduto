export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  type: 'text' | 'brief' | 'video' | 'loading' | 'approval_request' | 'production_status' | 'revision_request';
  metadata?: {
    step?: string;
    progress?: number;
    video_url?: string;
    revision_cost?: number;
    current_step?: string;
    steps?: Array<{
      id: string;
      name: string;
      status: 'pending' | 'active' | 'completed';
    }>;
  };
}

export interface VideoChat {
  id: string;
  user_id: string;
  title: string;
  description: string;
  image_urls: string[];
  image_names: string[];
  status: 'briefing' | 'approved' | 'generating' | 'completed' | 'revision';
  messages: ChatMessage[];
  video_url?: string;
  credits_used: number;
  created_at: string;
  updated_at: string;
  product_id?: string;
  product_type?: 'new' | 'existing';
  workflow_state: {
    phase: 'initial' | 'brief_review' | 'production' | 'delivery' | 'post_production';
    brief_approved: boolean;
    revision_count: number;
    last_action: string;
    context: any;
  };
}

export interface WorkflowState {
  phase: 'initial' | 'brief_review' | 'production' | 'delivery' | 'post_production';
  brief_approved: boolean;
  revision_count: number;
  last_action: string;
  context: any;
}

export interface ProductionStep {
  id: string;
  name: string;
  description: string;
  duration: number;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  progress: number;
}