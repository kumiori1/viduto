export interface Product {
  id: string;
  priceId: string;
  name: string;
  description: string;
  mode: 'payment' | 'subscription';
  price: number;
  currency: string;
  features: string[];
  credits?: number; // For credit packages
  billingPeriod?: string; // For subscriptions
  products?: number; // Number of products included
  videos?: number; // Number of videos included
}

export const products: Product[] = [
  // Subscription Plans
  {
    id: 'prod_SfbEpxagDPsoLp',
    priceId: 'price_1RkG1zDaWkYYoABypEmeRZ7I',
    name: 'Starter',
    description: 'Perfect for small businesses starting with AI video marketing',
    mode: 'subscription',
    price: 29,
    currency: 'USD',
    billingPeriod: 'monthly',
    credits: 30,
    products: 1,
    videos: 3,
    features: [
      '1 product included',
      '3 videos included',
      '30 credits per month',
      'High-quality video output',
      'Multiple format support',
      'Email customer support',
      'Basic templates library'
    ]
  },
  {
    id: 'prod_SfbEdSH49qT38u',
    priceId: 'price_1RkG2KDaWkYYoAByDFQmz3mT',
    name: 'Creator',
    description: 'Ideal for content creators and growing businesses',
    mode: 'subscription',
    price: 49,
    currency: 'USD',
    billingPeriod: 'monthly',
    credits: 60,
    products: 2,
    videos: 6,
    features: [
      '2 products included',
      '6 videos included',
      '60 credits per month',
      'High-quality video output',
      'Multiple format support',
      'Priority customer support',
      'Premium templates library',
      'Advanced customization options'
    ]
  },
  {
    id: 'prod_SfbF1JF5R1ypu9',
    priceId: 'price_1RkG2cDaWkYYoAByKx3xERXU',
    name: 'Business',
    description: 'Advanced features for professional businesses',
    mode: 'subscription',
    price: 89,
    currency: 'USD',
    billingPeriod: 'monthly',
    credits: 120,
    products: 4,
    videos: 12,
    features: [
      '4 products included',
      '12 videos included',
      '120 credits per month',
      'Ultra high-quality video output',
      'All format support',
      'Priority customer support',
      'Complete templates library',
      'Full customization suite',
      'Faster processing speed',
      'API access'
    ]
  },
  {
    id: 'prod_SoDSSjx2eMJm4n',
    priceId: 'price_1Rsb1YDaWkYYoAByTCKR9jlO',
    name: 'Agency',
    description: 'Ultimate package for agencies and enterprise-level production',
    mode: 'subscription',
    price: 199,
    currency: 'USD',
    billingPeriod: 'monthly',
    credits: 250,
    products: 8,
    videos: 25,
    features: [
      '8 products included',
      '25 videos included',
      '250 credits per month',
      'Ultra high-quality video output',
      'All format support',
      'VIP customer support',
      'Complete templates library',
      'Full customization suite',
      'Fastest processing speed',
      'Full API access',
      'White-label options',
      'Dedicated account manager',
      'Brand guidelines integration'
    ]
  },
  // Credit Packages (Top Up)
  {
    id: 'prod_SfbFTGzlusvFtx',
    priceId: 'price_1RkG3ADaWkYYoAByh59io53I',
    name: '25 Credits',
    description: 'Small top-up package for additional videos',
    mode: 'payment',
    price: 19,
    currency: 'USD',
    credits: 25,
    features: [
      '25 AI video generation credits',
      'High-quality video output',
      'Multiple format support',
      'Basic customer support',
      'No expiration date'
    ]
  },
  {
    id: 'prod_SfbHHe6UCZUd6n',
    priceId: 'price_1RkG4UDaWkYYoAByv7E5JyrX',
    name: '60 Credits',
    description: 'Medium top-up package for content creators',
    mode: 'payment',
    price: 39,
    currency: 'USD',
    credits: 60,
    features: [
      '60 AI video generation credits',
      'High-quality video output',
      'Multiple format support',
      'Priority customer support',
      'No expiration date',
      'Bulk generation discounts'
    ]
  },
  {
    id: 'prod_SfbHoUlpQtgAtM',
    priceId: 'price_1RkG4sDaWkYYoAByR3pFTTEj',
    name: '150 Credits',
    description: 'Large top-up package for high-volume production',
    mode: 'payment',
    price: 89,
    currency: 'USD',
    credits: 150,
    features: [
      '150 AI video generation credits',
      'High-quality video output',
      'Multiple format support',
      'VIP customer support',
      'No expiration date',
      'Maximum bulk discounts',
      'Advanced customization options',
      'Priority processing queue'
    ]
  }
];

export function getProductByPriceId(priceId: string): Product | undefined {
  return products.find(product => product.priceId === priceId);
}

export function getProductById(id: string): Product | undefined {
  return products.find(product => product.id === id);
}

export function formatPrice(price: number, currency: string): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(price);
}

export function getCreditPackages(): Product[] {
  return products.filter(product => product.mode === 'payment');
}

export function getSubscriptionPlans(): Product[] {
  return products.filter(product => product.mode === 'subscription');
}

export function getProductLimitByPriceId(priceId: string): number {
  const product = getProductByPriceId(priceId);
  return product?.products || 0;
}

export function getVideoLimitByPriceId(priceId: string): number {
  const product = getProductByPriceId(priceId);
  return product?.videos || 0;
}