// Facebook Pixel utility functions
// This file provides helper functions to interact with the Facebook Pixel

declare global {
  interface Window {
    fbq: any;
  }
}

export class FacebookPixel {
  private pixelId: string;
  private isInitialized: boolean = false;

  constructor(pixelId?: string) {
    this.pixelId = pixelId || import.meta.env.VITE_FACEBOOK_PIXEL_ID || '';
    this.init();
  }

  private init() {
    // Only initialize in production or if explicitly enabled
    if (this.shouldLoadPixel()) {
      this.isInitialized = true;
      console.log('Facebook Pixel initialized with ID:', this.pixelId);
    } else {
      console.log('Facebook Pixel disabled (development mode)');
    }
  }

  private shouldLoadPixel(): boolean {
    // Don't load pixel in development unless explicitly enabled
    const isDevelopment = window.location.hostname === 'localhost' || 
                         window.location.hostname === '127.0.0.1';
    const forceEnable = import.meta.env.VITE_FACEBOOK_PIXEL_FORCE_ENABLE === 'true';
    
    return !isDevelopment || forceEnable;
  }

  private isAvailable(): boolean {
    return this.isInitialized && typeof window !== 'undefined' && window.fbq && this.pixelId;
  }

  /**
   * Track a standard event
   */
  track(eventName: string, parameters?: any): boolean {
    if (!this.isAvailable()) {
      console.log('Facebook Pixel not available, skipping event:', eventName);
      return false;
    }

    try {
      console.log('Facebook Pixel tracking event:', eventName, parameters);
      window.fbq('track', eventName, parameters);
      return true;
    } catch (error) {
      console.error('Facebook Pixel tracking error:', error);
      return false;
    }
  }

  /**
   * Track a custom event
   */
  trackCustom(eventName: string, parameters?: any): boolean {
    if (!this.isAvailable()) {
      console.log('Facebook Pixel not available, skipping custom event:', eventName);
      return false;
    }

    try {
      console.log('Facebook Pixel tracking custom event:', eventName, parameters);
      window.fbq('trackCustom', eventName, parameters);
      return true;
    } catch (error) {
      console.error('Facebook Pixel custom tracking error:', error);
      return false;
    }
  }

  /**
   * Track page view
   */
  trackPageView(): boolean {
    return this.track('PageView');
  }

  /**
   * Track purchase
   */
  trackPurchase(value: number, currency: string = 'ILS', parameters?: any): boolean {
    return this.track('Purchase', {
      value: value,
      currency: currency,
      ...parameters
    });
  }

  /**
   * Track lead generation
   */
  trackLead(parameters?: any): boolean {
    return this.track('Lead', parameters);
  }

  /**
   * Track registration
   */
  trackCompleteRegistration(parameters?: any): boolean {
    return this.track('CompleteRegistration', parameters);
  }

  /**
   * Track login
   */
  trackLogin(parameters?: any): boolean {
    return this.track('Login', parameters);
  }

  /**
   * Track video view
   */
  trackVideoView(parameters?: any): boolean {
    return this.track('VideoView', parameters);
  }

  /**
   * Track initiate checkout
   */
  trackInitiateCheckout(value?: number, currency: string = 'ILS', parameters?: any): boolean {
    return this.track('InitiateCheckout', {
      value: value,
      currency: currency,
      ...parameters
    });
  }

  /**
   * Track add to cart
   */
  trackAddToCart(value?: number, currency: string = 'ILS', parameters?: any): boolean {
    return this.track('AddToCart', {
      value: value,
      currency: currency,
      ...parameters
    });
  }

  /**
   * Track view content
   */
  trackViewContent(parameters?: any): boolean {
    return this.track('ViewContent', parameters);
  }
}

// Export singleton instance
export const facebookPixel = new FacebookPixel();

// Export individual functions for convenience
export const {
  track,
  trackCustom,
  trackPageView,
  trackPurchase,
  trackLead,
  trackCompleteRegistration,
  trackLogin,
  trackVideoView,
  trackInitiateCheckout,
  trackAddToCart,
  trackViewContent,
} = facebookPixel;