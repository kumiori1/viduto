import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Add API endpoint for prompt enhancement
if (typeof window !== 'undefined') {
  // Mock API endpoint for prompt enhancement
  const originalFetch = window.fetch;
  window.fetch = function(input: RequestInfo | URL, init?: RequestInit) {
    const url = typeof input === 'string' ? input : input.toString();
    
    if (url === '/api/enhance-prompt' && init?.method === 'POST') {
      return new Promise(async (resolve) => {
        try {
          const { enhancePrompt } = await import('./lib/anthropic');
          const body = JSON.parse(init.body as string);
          const enhancedPrompt = await enhancePrompt(body.prompt);
          
          resolve(new Response(JSON.stringify({ enhancedPrompt }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
          }));
        } catch (error) {
          console.warn('Prompt enhancement failed, using original:', error);
          resolve(new Response(JSON.stringify({ error: 'Failed to enhance prompt' }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
          }));
        }
      });
    }
    
    return originalFetch.call(this, input, init);
  };
}
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
