# רשימת משתנים נחוצים ל-Supabase

## משתני סביבה עבור הפרויקט (.env)

### 1. משתני Supabase בסיסיים
```
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

### 2. משתני Stripe (לתשלומים)
```
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your-stripe-publishable-key
```

### 3. משתני Make.com (לאוטומציה)
```
VITE_MAKE_WEBHOOK_URL=https://hook.us2.make.com/your-webhook-id
```

---

## משתני סביבה עבור Supabase Edge Functions

### עבור stripe-webhook function:
```
STRIPE_SECRET_KEY=sk_test_your-stripe-secret-key
STRIPE_WEBHOOK_SECRET=whsec_your-webhook-secret
SUPABASE_URL=https://your-project-id.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

### עבור stripe-checkout function:
```
STRIPE_SECRET_KEY=sk_test_your-stripe-secret-key
SUPABASE_URL=https://your-project-id.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

---

## איך להגדיר את המשתנים ב-Supabase

### 1. משתני הפרויקט הראשי (.env):
- צור קובץ `.env` בשורש הפרויקט
- העתק את המשתנים מהרשימה למעלה
- החלף את הערכים בערכים האמיתיים מהפרויקט שלך

### 2. משתני Edge Functions:
1. היכנס ל-Supabase Dashboard
2. עבור ל-Edge Functions → Settings
3. הוסף כל משתנה בנפרד:
   - שם המשתנה (ללא VITE_)
   - הערך המתאים

### 3. איך למצוא את הערכים:

#### Supabase:
- `SUPABASE_URL`: Settings → API → Project URL
- `SUPABASE_ANON_KEY`: Settings → API → Project API keys → anon public
- `SUPABASE_SERVICE_ROLE_KEY`: Settings → API → Project API keys → service_role (secret)

#### Stripe:
- `STRIPE_PUBLISHABLE_KEY`: Stripe Dashboard → Developers → API keys → Publishable key
- `STRIPE_SECRET_KEY`: Stripe Dashboard → Developers → API keys → Secret key
- `STRIPE_WEBHOOK_SECRET`: Stripe Dashboard → Developers → Webhooks → [your webhook] → Signing secret

#### Make.com:
- `MAKE_WEBHOOK_URL`: Make.com → Create scenario → Add Webhooks module → Copy webhook URL

---

## Storage Bucket נדרש

### יצירת Bucket לתמונות:
1. היכנס ל-Supabase Dashboard
2. עבור ל-Storage
3. צור bucket חדש בשם: `video-request-images`
4. הגדר את ה-bucket כ-Public
5. הגדר RLS policies:

```sql
-- Policy לקריאה
CREATE POLICY "Public read access" ON storage.objects
FOR SELECT USING (bucket_id = 'video-request-images');

-- Policy לכתיבה (רק למשתמשים מחוברים)
CREATE POLICY "Authenticated users can upload" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'video-request-images' 
  AND auth.role() = 'authenticated'
);
```

---

## בדיקת תקינות

### לבדוק שהכל עובד:
1. הפעל את הפרויקט: `npm run dev`
2. נסה להתחבר למערכת
3. נסה ליצור בקשת סרטון חדשה
4. בדוק שהתמונות מועלות ל-Storage
5. נסה לבצע רכישה (במצב test)

### אם יש שגיאות:
- בדוק שכל המשתנים מוגדרים נכון
- ודא שאין רווחים מיותרים בערכים
- בדוק שה-RLS policies מוגדרות נכון
- ודא שה-Edge Functions פרוסות עם המשתנים הנכונים

---

## הערות חשובות

1. **אבטחה**: אל תשתף את ה-SERVICE_ROLE_KEY או STRIPE_SECRET_KEY
2. **סביבת פיתוח**: השתמש במפתחות test של Stripe
3. **סביבת ייצור**: החלף למפתחות live של Stripe
4. **גיבוי**: שמור עותק של כל המשתנים במקום בטוח
5. **עדכונים**: אם תחליף מפתחות, עדכן בכל המקומות