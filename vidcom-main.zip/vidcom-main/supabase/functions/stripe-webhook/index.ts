import 'jsr:@supabase/functions-js/edge-runtime.d.ts';
import Stripe from 'npm:stripe@17.7.0';
import { createClient } from 'npm:@supabase/supabase-js@2.49.1';

// ייבוא הגדרות המוצרים
const products = [
  {
    id: 'prod_RNJJJhJJJhJJJh',
    priceId: 'price_1RkG1zDaWkYYoABypEmeRZ7I',
    name: 'Starter',
    credits: 30
  },
  {
    id: 'prod_RNJJJhJJJhJJJi',
    priceId: 'price_1RkG2KDaWkYYoAByDFQmz3mT',
    name: 'Creator',
    credits: 60
  },
  {
    id: 'prod_RNJJJhJJJhJJJj',
    priceId: 'price_1RkG2cDaWkYYoAByKx3xERXU',
    name: 'Business',
    credits: 120
  },
  {
    id: 'prod_RNJJJhJJJhJJJk',
    priceId: 'price_1Rsb1YDaWkYYoAByTCKR9jlO',
    name: 'Agency',
    credits: 250
  },
  {
    id: 'prod_RNJJJhJJJhJJJl',
    priceId: 'price_1RkG4UDaWkYYoAByv7E5JyrX',
    name: '25 Credits',
    credits: 25
  },
  {
    id: 'prod_RNJJJhJJJhJJJm',
    priceId: 'price_1RkG4sDaWkYYoAByR3pFTTEj',
    name: '60 Credits',
    credits: 60
  },
  {
    id: 'prod_RNJJJhJJJhJJJn',
    priceId: 'price_1RkG3ADaWkYYoAByh59io53I',
    name: '150 Credits',
    credits: 150
  }
];

function getProductByPriceId(priceId: string) {
  return products.find(product => product.priceId === priceId);
}

const stripeSecret = Deno.env.get('STRIPE_SECRET_KEY')!;
const stripeWebhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET')!;
const stripe = new Stripe(stripeSecret, {
  appInfo: {
    name: 'Bolt Integration',
    version: '1.0.0',
  },
});

const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

Deno.serve(async (req) => {
  try {
    // Handle OPTIONS request for CORS preflight
    if (req.method === 'OPTIONS') {
      return new Response(null, { status: 204 });
    }

    if (req.method !== 'POST') {
      return new Response('Method not allowed', { status: 405 });
    }

    // get the signature from the header
    const signature = req.headers.get('stripe-signature');

    if (!signature) {
      return new Response('No signature found', { status: 400 });
    }

    // get the raw body
    const body = await req.text();

    // verify the webhook signature
    let event: Stripe.Event;

    try {
      event = await stripe.webhooks.constructEventAsync(body, signature, stripeWebhookSecret);
    } catch (error: any) {
      console.error(`Webhook signature verification failed: ${error.message}`);
      return new Response(`Webhook signature verification failed: ${error.message}`, { status: 400 });
    }

    EdgeRuntime.waitUntil(handleEvent(event));

    return Response.json({ received: true });
  } catch (error: any) {
    console.error('Error processing webhook:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

async function handleEvent(event: Stripe.Event) {
  const stripeData = event?.data?.object ?? {};

  if (!stripeData) {
    return;
  }

  if (!('customer' in stripeData)) {
    return;
  }

  // for one time payments, we only listen for the checkout.session.completed event
  if (event.type === 'payment_intent.succeeded' && event.data.object.invoice === null) {
    return;
  }

  const { customer: customerId } = stripeData;

  if (!customerId || typeof customerId !== 'string') {
    console.error(`No customer received on event: ${JSON.stringify(event)}`);
  } else {
    let isSubscription = true;

    if (event.type === 'checkout.session.completed') {
      const { mode } = stripeData as Stripe.Checkout.Session;

      isSubscription = mode === 'subscription';

      console.info(`Processing ${isSubscription ? 'subscription' : 'one-time payment'} checkout session`);
    }

    const { mode, payment_status } = stripeData as Stripe.Checkout.Session;

    if (isSubscription) {
      console.info(`Starting subscription sync for customer: ${customerId}`);
      await syncCustomerFromStripe(customerId);
    } else if (mode === 'payment' && payment_status === 'paid') {
      try {
        // Extract the necessary information from the session
        const {
          id: checkout_session_id,
          payment_intent,
          amount_subtotal,
          amount_total,
          currency,
          line_items,
        } = stripeData as Stripe.Checkout.Session;

        // קבלת פרטי הקו הראשון (המוצר שנרכש)
        let priceId = null;
        if (line_items && line_items.data && line_items.data.length > 0) {
          priceId = line_items.data[0].price?.id;
        }

        // Insert the order into the stripe_orders table
        const { error: orderError } = await supabase.from('stripe_orders').insert({
          checkout_session_id,
          payment_intent_id: payment_intent,
          customer_id: customerId,
          amount_subtotal,
          amount_total,
          currency,
          payment_status,
          status: 'completed', // assuming we want to mark it as completed since payment is successful
        });

        if (orderError) {
          console.error('Error inserting order:', orderError);
          return;
        }

        // הוספת קרדיטים למשתמש
        if (priceId) {
          await addVideoCreditsToUser(customerId, priceId, false); // false for one-time payment
        }

        console.info(`Successfully processed one-time payment for session: ${checkout_session_id}`);
      } catch (error) {
        console.error('Error processing one-time payment:', error);
      }
    }
  }
}

// based on the excellent https://github.com/t3dotgg/stripe-recommendations
async function syncCustomerFromStripe(customerId: string) {
  try {
    // fetch latest subscription data from Stripe
    const subscriptions = await stripe.subscriptions.list({
      customer: customerId,
      limit: 1,
      status: 'all',
      expand: ['data.default_payment_method'],
    });

    // TODO verify if needed
    if (subscriptions.data.length === 0) {
      console.info(`No active subscriptions found for customer: ${customerId}`);
      const { error: noSubError } = await supabase.from('stripe_subscriptions').upsert(
        {
          customer_id: customerId,
          subscription_status: 'not_started',
        },
        {
          onConflict: 'customer_id',
        },
      );

      if (noSubError) {
        console.error('Error updating subscription status:', noSubError);
        throw new Error('Failed to update subscription status in database');
      }
    }

    // assumes that a customer can only have a single subscription
    const subscription = subscriptions.data[0];

    // Add monthly credits for active subscriptions
    if (subscription.status === 'active') {
      await addVideoCreditsToUser(customerId, subscription.items.data[0].price.id, true); // true for subscription
    }

    // store subscription state
    const { error: subError } = await supabase.from('stripe_subscriptions').upsert(
      {
        customer_id: customerId,
        subscription_id: subscription.id,
        price_id: subscription.items.data[0].price.id,
        current_period_start: subscription.current_period_start,
        current_period_end: subscription.current_period_end,
        cancel_at_period_end: subscription.cancel_at_period_end,
        ...(subscription.default_payment_method && typeof subscription.default_payment_method !== 'string'
          ? {
              payment_method_brand: subscription.default_payment_method.card?.brand ?? null,
              payment_method_last4: subscription.default_payment_method.card?.last4 ?? null,
            }
          : {}),
        status: subscription.status,
      },
      {
        onConflict: 'customer_id',
      },
    );

    if (subError) {
      console.error('Error syncing subscription:', subError);
      throw new Error('Failed to sync subscription in database');
    }
    console.info(`Successfully synced subscription for customer: ${customerId}`);
  } catch (error) {
    console.error(`Failed to sync subscription for customer ${customerId}:`, error);
    throw error;
  }
}

async function addVideoCreditsToUser(customerId: string, priceId: string, isSubscription: boolean = false) {
  try {
    // מציאת המוצר לפי price_id
    const product = getProductByPriceId(priceId);
    if (!product) {
      console.error(`Product not found for price_id: ${priceId}`);
      return;
    }

    // מציאת המשתמש לפי customer_id
    const { data: customer, error: customerError } = await supabase
      .from('stripe_customers')
      .select('user_id')
      .eq('customer_id', customerId)
      .single();

    if (customerError || !customer) {
      console.error('Error finding user for customer:', customerError);
      return;
    }

    // Use the safe add_user_credits function
    const { error: addCreditsError } = await supabase.rpc('add_user_credits', {
      user_id_param: customer.user_id,
      credits_to_add: product.credits,
      is_purchase: !isSubscription // For subscriptions, don't count as purchase
    });

    if (addCreditsError) {
      console.error('Error adding video credits:', addCreditsError);
    } else {
      console.info(`Added ${product.credits} video credits to user ${customer.user_id} (${isSubscription ? 'subscription' : 'purchase'})`);
    }
  } catch (error) {
    console.error('Error in addVideoCreditsToUser:', error);
  }
}