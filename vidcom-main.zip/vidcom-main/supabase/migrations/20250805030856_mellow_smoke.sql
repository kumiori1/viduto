/*
  # Create helper functions for the application

  1. Helper Functions
    - `get_user_credits` - Get current user credit balance
    - `can_afford_action` - Check if user can afford specific action
    - `generate_reference_tag` - Generate unique reference tag for products
  2. Security
    - All functions are security definer
    - Proper access control
*/

-- Function to get user credits
CREATE OR REPLACE FUNCTION get_user_credits(user_uuid uuid)
RETURNS TABLE(available_credits integer, total_purchased integer, total_used integer) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    uvc.available_credits,
    uvc.total_purchased,
    uvc.total_used
  FROM user_video_credits uvc
  WHERE uvc.user_id = user_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check if user can afford an action
CREATE OR REPLACE FUNCTION can_afford_action(user_uuid uuid, required_credits integer)
RETURNS boolean AS $$
DECLARE
  current_credits integer;
BEGIN
  SELECT available_credits INTO current_credits
  FROM user_video_credits
  WHERE user_id = user_uuid;

  RETURN COALESCE(current_credits, 0) >= required_credits;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to generate unique reference tag
CREATE OR REPLACE FUNCTION generate_reference_tag(product_name text, user_uuid uuid)
RETURNS text AS $$
DECLARE
  base_tag text;
  final_tag text;
  counter integer := 1;
BEGIN
  -- Create base tag from product name
  base_tag := lower(regexp_replace(product_name, '[^a-zA-Z0-9]', '', 'g'));
  base_tag := substring(base_tag from 1 for 15); -- Limit length
  
  -- Ensure uniqueness for this user
  final_tag := base_tag;
  
  WHILE EXISTS (
    SELECT 1 FROM products 
    WHERE user_id = user_uuid AND reference_tag = final_tag
  ) LOOP
    final_tag := base_tag || counter::text;
    counter := counter + 1;
  END LOOP;
  
  RETURN final_tag;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get user's brand guidelines
CREATE OR REPLACE FUNCTION get_user_brand_guidelines(user_uuid uuid)
RETURNS jsonb AS $$
DECLARE
  guidelines jsonb;
BEGIN
  SELECT to_jsonb(bg.*) INTO guidelines
  FROM brand_guidelines bg
  WHERE bg.user_id = user_uuid;
  
  RETURN COALESCE(guidelines, '{}'::jsonb);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;