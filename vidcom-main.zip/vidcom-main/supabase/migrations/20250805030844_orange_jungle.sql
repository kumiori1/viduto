/*
  # Create user signup trigger for automatic user record creation

  1. Trigger Function
    - Automatically create user record when auth.users record is created
    - Initialize with 40 free credits (1 product + 1 video)
  2. Security
    - Secure function execution
    - Proper error handling
*/

-- Function to handle new user signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert into users table
  INSERT INTO users (id, email, created_at, updated_at)
  VALUES (NEW.id, NEW.email, now(), now())
  ON CONFLICT (id) DO NOTHING;

  -- Initialize user credits (40 credits = 1 product + 1 video free)
  INSERT INTO user_video_credits (user_id, available_credits, total_purchased, total_used)
  VALUES (NEW.id, 40, 0, 0)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();