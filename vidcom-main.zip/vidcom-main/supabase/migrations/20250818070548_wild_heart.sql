/*
  # תיקון סופי של מערכת הקרדיטים

  1. RPC Functions
    - add_user_credits_v2: הוספת קרדיטים בצורה בטוחה
    - use_user_credits_v2: שימוש בקרדיטים בצורה אטומית
    - check_credit_usage: בדיקת שימוש בקרדיטים לצ'אט ספציפי

  2. Security
    - כל הפונקציות מוגנות מפני race conditions
    - בדיקות אטומיות של זמינות קרדיטים
    - מניעת גבייה כפולה
*/

-- פונקציה לבדיקת שימוש בקרדיטים לצ'אט ספציפי
CREATE OR REPLACE FUNCTION check_credit_usage(
  chat_id_param text,
  credit_type_param text -- 'video_generation' או 'video_revision'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_video_credits integer;
  current_product_credits integer;
  expected_video_credits integer;
BEGIN
  -- קבלת הקרדיטים הנוכחיים מהצ'אט
  SELECT 
    COALESCE(video_credits_used_for_chat, 0),
    COALESCE(product_credits_used_for_chat, 0)
  INTO current_video_credits, current_product_credits
  FROM video_chats 
  WHERE id = chat_id_param;

  -- בדיקה לפי סוג הפעולה
  IF credit_type_param = 'video_generation' THEN
    -- בדיקה אם כבר נגבו 10 קרדיטים לגנרציה
    RETURN current_video_credits >= 10;
  ELSIF credit_type_param = 'video_revision' THEN
    -- בדיקה אם יש רביזיה חדשה שטרם נגבתה
    expected_video_credits := 10 + (4 * ((current_video_credits - 10) / 4 + 1));
    RETURN current_video_credits >= expected_video_credits;
  END IF;

  RETURN false;
END;
$$;

-- פונקציה לשימוש בקרדיטים בצורה אטומית
CREATE OR REPLACE FUNCTION use_user_credits_v2(
  user_id_param uuid,
  chat_id_param text,
  product_credits_to_use integer DEFAULT 0,
  video_credits_to_use integer DEFAULT 0,
  operation_type text DEFAULT 'general' -- 'product_creation', 'video_generation', 'video_revision'
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_product_credits integer;
  current_video_credits integer;
  chat_product_credits integer;
  chat_video_credits integer;
  result json;
BEGIN
  -- נעילה אטומית של השורה
  SELECT 
    available_product_credits,
    available_video_credits
  INTO current_product_credits, current_video_credits
  FROM user_video_credits 
  WHERE user_id = user_id_param
  FOR UPDATE;

  -- בדיקת זמינות קרדיטים
  IF current_product_credits < product_credits_to_use THEN
    RETURN json_build_object(
      'success', false,
      'error', 'insufficient_product_credits',
      'available_product_credits', current_product_credits,
      'required_product_credits', product_credits_to_use
    );
  END IF;

  IF current_video_credits < video_credits_to_use THEN
    RETURN json_build_object(
      'success', false,
      'error', 'insufficient_video_credits',
      'available_video_credits', current_video_credits,
      'required_video_credits', video_credits_to_use
    );
  END IF;

  -- בדיקה נוספת לצ'אט ספציפי (אם סופק)
  IF chat_id_param IS NOT NULL THEN
    SELECT 
      COALESCE(product_credits_used_for_chat, 0),
      COALESCE(video_credits_used_for_chat, 0)
    INTO chat_product_credits, chat_video_credits
    FROM video_chats 
    WHERE id = chat_id_param;

    -- מניעת גבייה כפולה לפי סוג הפעולה
    IF operation_type = 'video_generation' AND chat_video_credits >= 10 THEN
      RETURN json_build_object(
        'success', false,
        'error', 'already_charged',
        'message', 'Video generation credits already deducted for this chat'
      );
    END IF;

    IF operation_type = 'video_revision' THEN
      -- חישוב כמה רביזיות כבר נגבו
      DECLARE
        revisions_charged integer;
        next_revision_cost integer;
      BEGIN
        revisions_charged := GREATEST(0, (chat_video_credits - 10) / 4);
        next_revision_cost := 10 + (4 * (revisions_charged + 1));
        
        IF chat_video_credits >= next_revision_cost THEN
          RETURN json_build_object(
            'success', false,
            'error', 'already_charged',
            'message', 'This revision was already charged'
          );
        END IF;
      END;
    END IF;
  END IF;

  -- ביצוע הגבייה
  UPDATE user_video_credits 
  SET 
    available_product_credits = available_product_credits - product_credits_to_use,
    available_video_credits = available_video_credits - video_credits_to_use,
    total_product_used = total_product_used + product_credits_to_use,
    total_video_used = total_video_used + video_credits_to_use,
    updated_at = now()
  WHERE user_id = user_id_param;

  -- עדכון הצ'אט (אם סופק)
  IF chat_id_param IS NOT NULL THEN
    UPDATE video_chats 
    SET 
      product_credits_used_for_chat = COALESCE(product_credits_used_for_chat, 0) + product_credits_to_use,
      video_credits_used_for_chat = COALESCE(video_credits_used_for_chat, 0) + video_credits_to_use,
      credits_used = COALESCE(product_credits_used_for_chat, 0) + COALESCE(video_credits_used_for_chat, 0) + product_credits_to_use + video_credits_to_use,
      updated_at = now()
    WHERE id = chat_id_param;
  END IF;

  -- החזרת תוצאה מוצלחת
  RETURN json_build_object(
    'success', true,
    'product_credits_used', product_credits_to_use,
    'video_credits_used', video_credits_to_use,
    'remaining_product_credits', current_product_credits - product_credits_to_use,
    'remaining_video_credits', current_video_credits - video_credits_to_use
  );
END;
$$;