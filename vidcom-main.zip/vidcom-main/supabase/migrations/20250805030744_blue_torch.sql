/*
  # Update video chats table for product integration

  1. Changes to video_chats table
    - Add `product_id` column (optional reference to products table)
    - Add `product_type` column ('new' or 'existing')
    - Update status enum to include new states
    - Add indexes for better performance
  2. Security
    - Update existing RLS policies
    - Ensure proper access control
*/

-- Add new columns to video_chats table
DO $$
BEGIN
  -- Add product_id column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'video_chats' AND column_name = 'product_id'
  ) THEN
    ALTER TABLE video_chats ADD COLUMN product_id uuid REFERENCES products(id) ON DELETE SET NULL;
  END IF;

  -- Add product_type column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'video_chats' AND column_name = 'product_type'
  ) THEN
    ALTER TABLE video_chats ADD COLUMN product_type text DEFAULT 'new' CHECK (product_type IN ('new', 'existing'));
  END IF;
END $$;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_video_chats_product_id ON video_chats(product_id);
CREATE INDEX IF NOT EXISTS idx_video_chats_product_type ON video_chats(product_type);

-- Update the status check constraint to include all possible statuses
DO $$
BEGIN
  -- Drop existing constraint if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_name = 'video_chats' AND constraint_name = 'video_chats_status_check'
  ) THEN
    ALTER TABLE video_chats DROP CONSTRAINT video_chats_status_check;
  END IF;

  -- Add updated constraint
  ALTER TABLE video_chats ADD CONSTRAINT video_chats_status_check 
    CHECK (status IN ('briefing', 'approved', 'generating', 'completed', 'revision'));
END $$;