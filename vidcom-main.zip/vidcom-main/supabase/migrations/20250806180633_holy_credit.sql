/*
  # Add workflow state to video chats

  1. Schema Changes
    - Add `workflow_state` JSONB column to `video_chats` table
    - Set default workflow state for existing records
    - Add index for better query performance

  2. Data Migration
    - Update existing chats with default workflow state
    - Ensure all chats have proper workflow tracking

  3. Performance
    - Add index on workflow_state for faster queries
*/

-- Add workflow_state column to video_chats table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'video_chats' AND column_name = 'workflow_state'
  ) THEN
    ALTER TABLE video_chats ADD COLUMN workflow_state JSONB DEFAULT '{
      "phase": "initial",
      "brief_approved": false,
      "revision_count": 0,
      "last_action": "created",
      "context": {}
    }'::jsonb;
  END IF;
END $$;

-- Update existing records with default workflow state
UPDATE video_chats 
SET workflow_state = '{
  "phase": "initial",
  "brief_approved": false,
  "revision_count": 0,
  "last_action": "created",
  "context": {}
}'::jsonb
WHERE workflow_state IS NULL;

-- Add index for workflow state queries
CREATE INDEX IF NOT EXISTS idx_video_chats_workflow_phase 
ON video_chats USING gin ((workflow_state->'phase'));

-- Add index for workflow last_action
CREATE INDEX IF NOT EXISTS idx_video_chats_workflow_action 
ON video_chats USING gin ((workflow_state->'last_action'));

-- Update the trigger function to handle workflow_state updates
CREATE OR REPLACE FUNCTION update_video_chats_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  
  -- Ensure workflow_state exists
  IF NEW.workflow_state IS NULL THEN
    NEW.workflow_state = '{
      "phase": "initial",
      "brief_approved": false,
      "revision_count": 0,
      "last_action": "updated",
      "context": {}
    }'::jsonb;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;