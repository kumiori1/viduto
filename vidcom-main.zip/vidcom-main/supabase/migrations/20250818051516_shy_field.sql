/*
  # Update Credit System - Complete Migration

  1. New Columns
    - Add separate credit columns for products and videos
    - Add tracking columns for purchased and used credits
    
  2. Data Migration
    - Migrate existing available_credits to available_video_credits
    - Give 1 product credit to existing users
    
  3. New Functions
    - add_user_credits_v2: Safely add credits with validation
    - use_user_credits_v2: Use credits with availability checks
    - refresh_monthly_credits: Monthly credit refresh for subscribers
    
  4. Security
    - Update RLS policies for new columns
    - Add proper permissions for new functions
    
  5. Performance
    - Add indexes for better query performance
*/

-- Add new credit columns to user_video_credits table
DO $$
BEGIN
  -- Add available_product_credits column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_video_credits' AND column_name = 'available_product_credits'
  ) THEN
    ALTER TABLE user_video_credits ADD COLUMN available_product_credits integer DEFAULT 0 NOT NULL;
  END IF;

  -- Add available_video_credits column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_video_credits' AND column_name = 'available_video_credits'
  ) THEN
    ALTER TABLE user_video_credits ADD COLUMN available_video_credits integer DEFAULT 0 NOT NULL;
  END IF;

  -- Add total_product_purchased column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_video_credits' AND column_name = 'total_product_purchased'
  ) THEN
    ALTER TABLE user_video_credits ADD COLUMN total_product_purchased integer DEFAULT 0 NOT NULL;
  END IF;

  -- Add total_video_purchased column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_video_credits' AND column_name = 'total_video_purchased'
  ) THEN
    ALTER TABLE user_video_credits ADD COLUMN total_video_purchased integer DEFAULT 0 NOT NULL;
  END IF;

  -- Add total_product_used column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_video_credits' AND column_name = 'total_product_used'
  ) THEN
    ALTER TABLE user_video_credits ADD COLUMN total_product_used integer DEFAULT 0 NOT NULL;
  END IF;

  -- Add total_video_used column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_video_credits' AND column_name = 'total_video_used'
  ) THEN
    ALTER TABLE user_video_credits ADD COLUMN total_video_used integer DEFAULT 0 NOT NULL;
  END IF;
END $$;

-- Migrate existing data from available_credits to available_video_credits
UPDATE user_video_credits 
SET available_video_credits = COALESCE(available_credits, 0),
    total_video_purchased = COALESCE(total_purchased, 0),
    total_video_used = COALESCE(total_used, 0)
WHERE available_video_credits = 0;

-- Give 1 product credit to all existing users
UPDATE user_video_credits 
SET available_product_credits = 1,
    total_product_purchased = 1
WHERE available_product_credits = 0;

-- Create function to safely add credits to user
CREATE OR REPLACE FUNCTION add_user_credits_v2(
  user_id_param uuid,
  product_credits_to_add integer DEFAULT 0,
  video_credits_to_add integer DEFAULT 0,
  is_purchase boolean DEFAULT true
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Validate input parameters
  IF user_id_param IS NULL THEN
    RAISE EXCEPTION 'user_id_param cannot be null';
  END IF;
  
  IF product_credits_to_add < 0 OR video_credits_to_add < 0 THEN
    RAISE EXCEPTION 'Credit amounts cannot be negative';
  END IF;

  -- Insert or update user credits
  INSERT INTO user_video_credits (
    user_id,
    available_product_credits,
    available_video_credits,
    total_product_purchased,
    total_video_purchased,
    total_product_used,
    total_video_used
  )
  VALUES (
    user_id_param,
    product_credits_to_add,
    video_credits_to_add,
    CASE WHEN is_purchase THEN product_credits_to_add ELSE 0 END,
    CASE WHEN is_purchase THEN video_credits_to_add ELSE 0 END,
    0,
    0
  )
  ON CONFLICT (user_id) DO UPDATE SET
    available_product_credits = user_video_credits.available_product_credits + product_credits_to_add,
    available_video_credits = user_video_credits.available_video_credits + video_credits_to_add,
    total_product_purchased = CASE 
      WHEN is_purchase THEN user_video_credits.total_product_purchased + product_credits_to_add
      ELSE user_video_credits.total_product_purchased
    END,
    total_video_purchased = CASE 
      WHEN is_purchase THEN user_video_credits.total_video_purchased + video_credits_to_add
      ELSE user_video_credits.total_video_purchased
    END,
    updated_at = now();

  RAISE NOTICE 'Added % product credits and % video credits to user %', 
    product_credits_to_add, video_credits_to_add, user_id_param;
END;
$$;

-- Create function to use credits safely
CREATE OR REPLACE FUNCTION use_user_credits_v2(
  user_id_param uuid,
  product_credits_to_use integer DEFAULT 0,
  video_credits_to_use integer DEFAULT 0
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_product_credits integer;
  current_video_credits integer;
BEGIN
  -- Validate input parameters
  IF user_id_param IS NULL THEN
    RAISE EXCEPTION 'user_id_param cannot be null';
  END IF;
  
  IF product_credits_to_use < 0 OR video_credits_to_use < 0 THEN
    RAISE EXCEPTION 'Credit usage amounts cannot be negative';
  END IF;

  -- Get current credits with row lock
  SELECT available_product_credits, available_video_credits
  INTO current_product_credits, current_video_credits
  FROM user_video_credits
  WHERE user_id = user_id_param
  FOR UPDATE;

  -- Check if user exists
  IF NOT FOUND THEN
    RAISE EXCEPTION 'User credits record not found for user %', user_id_param;
  END IF;

  -- Check if user has enough credits
  IF current_product_credits < product_credits_to_use THEN
    RAISE EXCEPTION 'Insufficient product credits. Available: %, Required: %', 
      current_product_credits, product_credits_to_use;
  END IF;

  IF current_video_credits < video_credits_to_use THEN
    RAISE EXCEPTION 'Insufficient video credits. Available: %, Required: %', 
      current_video_credits, video_credits_to_use;
  END IF;

  -- Deduct credits
  UPDATE user_video_credits
  SET 
    available_product_credits = available_product_credits - product_credits_to_use,
    available_video_credits = available_video_credits - video_credits_to_use,
    total_product_used = total_product_used + product_credits_to_use,
    total_video_used = total_video_used + video_credits_to_use,
    updated_at = now()
  WHERE user_id = user_id_param;

  RAISE NOTICE 'Used % product credits and % video credits for user %', 
    product_credits_to_use, video_credits_to_use, user_id_param;

  RETURN true;
END;
$$;

-- Create function to refresh monthly credits for subscribers
CREATE OR REPLACE FUNCTION refresh_monthly_credits()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  subscription_record RECORD;
  product_credits_to_add integer;
  video_credits_to_add integer;
BEGIN
  -- Loop through all active subscriptions
  FOR subscription_record IN
    SELECT 
      sc.user_id,
      ss.price_id,
      ss.subscription_status
    FROM stripe_customers sc
    JOIN stripe_subscriptions ss ON sc.customer_id = ss.customer_id
    WHERE ss.subscription_status = 'active'
      AND sc.deleted_at IS NULL
      AND ss.deleted_at IS NULL
  LOOP
    -- Determine credits based on price_id
    CASE subscription_record.price_id
      WHEN 'price_1RkG1zDaWkYYoABypEmeRZ7I' THEN -- Starter
        product_credits_to_add := 1;
        video_credits_to_add := 40;
      WHEN 'price_1RkG2KDaWkYYoAByDFQmz3mT' THEN -- Creator
        product_credits_to_add := 2;
        video_credits_to_add := 80;
      WHEN 'price_1RkG2cDaWkYYoAByKx3xERXU' THEN -- Business
        product_credits_to_add := 4;
        video_credits_to_add := 120;
      WHEN 'price_1Rsb1YDaWkYYoAByTCKR9jlO' THEN -- Agency
        product_credits_to_add := 8;
        video_credits_to_add := 250;
      ELSE
        product_credits_to_add := 0;
        video_credits_to_add := 0;
    END CASE;

    -- Reset monthly credits (refresh, don't accumulate)
    IF product_credits_to_add > 0 OR video_credits_to_add > 0 THEN
      UPDATE user_video_credits
      SET 
        available_product_credits = product_credits_to_add,
        available_video_credits = video_credits_to_add,
        updated_at = now()
      WHERE user_id = subscription_record.user_id;

      RAISE NOTICE 'Refreshed credits for user %: % product, % video', 
        subscription_record.user_id, product_credits_to_add, video_credits_to_add;
    END IF;
  END LOOP;
END;
$$;

-- Update trigger function for new user registration
CREATE OR REPLACE FUNCTION give_new_user_credits()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Give new users 1 product credit and 10 video credits
  INSERT INTO user_video_credits (
    user_id,
    available_product_credits,
    available_video_credits,
    total_product_purchased,
    total_video_purchased,
    total_product_used,
    total_video_used
  )
  VALUES (
    NEW.id,
    1,  -- 1 free product credit
    10, -- 10 free video credits
    1,  -- Count as purchased for tracking
    10, -- Count as purchased for tracking
    0,  -- No credits used yet
    0   -- No credits used yet
  );
  
  RETURN NEW;
END;
$$;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_user_video_credits_product_credits 
ON user_video_credits (available_product_credits);

CREATE INDEX IF NOT EXISTS idx_user_video_credits_video_credits 
ON user_video_credits (available_video_credits);

CREATE INDEX IF NOT EXISTS idx_user_video_credits_total_used 
ON user_video_credits (total_product_used, total_video_used);

-- Update RLS policies for new columns
DO $$
BEGIN
  -- Drop existing policies if they exist
  DROP POLICY IF EXISTS "Users can view their own credits" ON user_video_credits;
  DROP POLICY IF EXISTS "Users can update their own credits" ON user_video_credits;
  DROP POLICY IF EXISTS "Users can insert their own credits" ON user_video_credits;

  -- Create updated policies that include new columns
  CREATE POLICY "Users can view their own credits"
    ON user_video_credits
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);

  CREATE POLICY "Users can update their own credits"
    ON user_video_credits
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

  CREATE POLICY "Users can insert their own credits"
    ON user_video_credits
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);
END $$;

-- Grant execute permissions on new functions
GRANT EXECUTE ON FUNCTION add_user_credits_v2(uuid, integer, integer, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION use_user_credits_v2(uuid, integer, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION refresh_monthly_credits() TO service_role;

-- Test the migration by checking if columns exist
DO $$
BEGIN
  -- Verify all new columns exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_video_credits' 
    AND column_name IN ('available_product_credits', 'available_video_credits', 'total_product_purchased', 'total_video_purchased', 'total_product_used', 'total_video_used')
  ) THEN
    RAISE EXCEPTION 'Migration failed: New columns not created properly';
  END IF;

  RAISE NOTICE 'Migration completed successfully - all new credit columns added';
END $$;