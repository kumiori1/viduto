/*
  # Add credit tracking columns to video_chats table

  1. New Columns
    - `product_credits_used_for_chat` (integer, default 0)
      - Tracks product credits used specifically for this chat
      - 1 for new product creation, 0 for existing product usage
    - `video_credits_used_for_chat` (integer, default 0)  
      - Tracks video credits used specifically for this chat
      - 10 for initial video generation, 4 per revision

  2. Changes
    - Add the new columns with default values
    - Update existing records to have proper default values
    - Ensure backward compatibility

  3. Security
    - No RLS changes needed as table already has proper policies
*/

-- Add new credit tracking columns
DO $$
BEGIN
  -- Add product_credits_used_for_chat column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'video_chats' AND column_name = 'product_credits_used_for_chat'
  ) THEN
    ALTER TABLE video_chats ADD COLUMN product_credits_used_for_chat integer DEFAULT 0 NOT NULL;
  END IF;

  -- Add video_credits_used_for_chat column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'video_chats' AND column_name = 'video_credits_used_for_chat'
  ) THEN
    ALTER TABLE video_chats ADD COLUMN video_credits_used_for_chat integer DEFAULT 0 NOT NULL;
  END IF;
END $$;

-- Update existing records to have proper values based on current credits_used
-- This is a one-time migration to set proper values for existing chats
UPDATE video_chats 
SET 
  product_credits_used_for_chat = CASE 
    WHEN product_type = 'new' THEN 1 
    ELSE 0 
  END,
  video_credits_used_for_chat = CASE
    WHEN status IN ('approved', 'generating', 'completed', 'revision') THEN 
      CASE 
        WHEN status = 'revision' THEN 14  -- 10 for initial + 4 for revision
        ELSE 10  -- 10 for initial generation
      END
    ELSE 0
  END
WHERE product_credits_used_for_chat IS NULL OR video_credits_used_for_chat IS NULL;

-- Update credits_used to be the sum of the two new columns
UPDATE video_chats 
SET credits_used = COALESCE(product_credits_used_for_chat, 0) + COALESCE(video_credits_used_for_chat, 0);