/*
  # Create storage bucket for video request images

  1. Storage Setup
    - Create 'video-request-images' bucket
    - Set up public access for images
    - Configure RLS policies for secure uploads
  2. Security
    - Public read access for all images
    - Authenticated users can upload to their own folders
    - Users can only delete their own images
*/

-- Create storage bucket for video request images
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'video-request-images',
  'video-request-images',
  true,
  10485760, -- 10MB limit
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']
) ON CONFLICT (id) DO NOTHING;

-- RLS Policies for storage
CREATE POLICY "Public read access for video request images"
  ON storage.objects
  FOR SELECT
  USING (bucket_id = 'video-request-images');

CREATE POLICY "Authenticated users can upload video request images"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'video-request-images' 
    AND auth.role() = 'authenticated'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can update their own video request images"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'video-request-images'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can delete their own video request images"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'video-request-images'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );