/*
  # Fix storage bucket RLS policies for file uploads

  1. Storage Policies
    - Allow authenticated users to upload files to video-request-images bucket
    - Allow public read access to uploaded files
    - Allow users to manage their own files

  2. Security
    - INSERT policy for authenticated users
    - SELECT policy for public access
    - UPDATE/DELETE policies for file owners
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow authenticated uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public downloads" ON storage.objects;
DROP POLICY IF EXISTS "Allow users to update own files" ON storage.objects;
DROP POLICY IF EXISTS "Allow users to delete own files" ON storage.objects;

-- Create policy to allow authenticated users to upload files to video-request-images bucket
CREATE POLICY "Allow authenticated uploads"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'video-request-images');

-- Create policy to allow public read access to files in video-request-images bucket
CREATE POLICY "Allow public downloads"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'video-request-images');

-- Create policy to allow users to update their own files
CREATE POLICY "Allow users to update own files"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'video-request-images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Create policy to allow users to delete their own files
CREATE POLICY "Allow users to delete own files"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'video-request-images' AND auth.uid()::text = (storage.foldername(name))[1]);