/*
  # Update video chats trigger function

  1. Trigger Functions
    - Update existing trigger function for video_chats
    - Ensure proper updated_at handling
  2. Security
    - Maintain existing security model
*/

-- Create or update the trigger function for video_chats
CREATE OR REPLACE FUNCTION update_video_chats_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Ensure trigger exists
DROP TRIGGER IF EXISTS update_video_chats_updated_at ON video_chats;
CREATE TRIGGER update_video_chats_updated_at
  BEFORE UPDATE ON video_chats
  FOR EACH ROW
  EXECUTE FUNCTION update_video_chats_updated_at();