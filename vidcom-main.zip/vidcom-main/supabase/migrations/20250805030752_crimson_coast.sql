/*
  # Update user video credits system for new pricing model

  1. Changes to user_video_credits table
    - Ensure proper default values
    - Add indexes for performance
    - Update RLS policies
  2. Free tier support
    - New users get 40 credits (1 product + 1 video)
    - Proper credit tracking
*/

-- Ensure user_video_credits table has proper structure
DO $$
BEGIN
  -- Update default values if needed
  ALTER TABLE user_video_credits ALTER COLUMN available_credits SET DEFAULT 0;
  ALTER TABLE user_video_credits ALTER COLUMN total_purchased SET DEFAULT 0;
  ALTER TABLE user_video_credits ALTER COLUMN total_used SET DEFAULT 0;
END $$;

-- Add function to initialize user credits
CREATE OR REPLACE FUNCTION initialize_user_credits(user_uuid uuid, initial_credits integer DEFAULT 40)
RETURNS void AS $$
BEGIN
  INSERT INTO user_video_credits (user_id, available_credits, total_purchased, total_used)
  VALUES (user_uuid, initial_credits, 0, 0)
  ON CONFLICT (user_id) DO NOTHING;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add function to safely deduct credits
CREATE OR REPLACE FUNCTION deduct_user_credits(user_uuid uuid, credits_to_deduct integer)
RETURNS boolean AS $$
DECLARE
  current_credits integer;
BEGIN
  -- Get current available credits
  SELECT available_credits INTO current_credits
  FROM user_video_credits
  WHERE user_id = user_uuid;

  -- Check if user has enough credits
  IF current_credits IS NULL OR current_credits < credits_to_deduct THEN
    RETURN false;
  END IF;

  -- Deduct credits
  UPDATE user_video_credits
  SET 
    available_credits = available_credits - credits_to_deduct,
    total_used = total_used + credits_to_deduct,
    updated_at = now()
  WHERE user_id = user_uuid;

  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add function to add credits (for purchases/subscriptions)
CREATE OR REPLACE FUNCTION add_user_credits(user_uuid uuid, credits_to_add integer, is_purchase boolean DEFAULT true)
RETURNS void AS $$
BEGIN
  -- Initialize credits record if it doesn't exist
  INSERT INTO user_video_credits (user_id, available_credits, total_purchased, total_used)
  VALUES (user_uuid, credits_to_add, CASE WHEN is_purchase THEN credits_to_add ELSE 0 END, 0)
  ON CONFLICT (user_id) DO UPDATE SET
    available_credits = user_video_credits.available_credits + credits_to_add,
    total_purchased = CASE 
      WHEN is_purchase THEN user_video_credits.total_purchased + credits_to_add 
      ELSE user_video_credits.total_purchased 
    END,
    updated_at = now();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;