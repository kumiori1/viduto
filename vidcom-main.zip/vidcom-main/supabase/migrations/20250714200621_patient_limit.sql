/*
  # Create video requests table

  1. New Tables
    - `user_video_requests`
      - `id` (text, primary key) - unique identifier for video request
      - `user_id` (uuid, foreign key) - references auth.users.id
      - `title` (text) - video title
      - `brief_description` (text) - brief description of the video
      - `target_platform` (text) - target platform for the video
      - `music_style` (text) - music style preference
      - `voiceover` (text) - voiceover preference
      - `language` (text) - language preference
      - `additional_requests` (text) - additional requests and notes
      - `images_count` (integer) - number of images uploaded
      - `image_urls` (text[]) - array of image URLs from Supabase Storage
      - `image_names` (text[]) - array of original image file names
      - `status` (text) - request status (submitted, in-progress, ready)
      - `request_date` (timestamptz) - when the request was submitted
      - `expected_delivery` (timestamptz) - expected delivery date
      - `video_url` (text, nullable) - URL of the completed video
      - `created_at` (timestamptz) - record creation timestamp
      - `updated_at` (timestamptz) - record update timestamp

  2. Security
    - Enable RLS on `user_video_requests` table
    - Add policies for users to manage their own video requests
    - Users can SELECT, INSERT, and UPDATE their own requests only

  3. Indexes
    - Index on user_id for efficient queries
    - Index on status for filtering
    - Index on request_date for ordering
*/

-- Create the user_video_requests table
CREATE TABLE IF NOT EXISTS user_video_requests (
  id text PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  brief_description text NOT NULL,
  target_platform text NOT NULL,
  music_style text DEFAULT '',
  voiceover text NOT NULL,
  language text NOT NULL,
  additional_requests text DEFAULT '',
  images_count integer NOT NULL DEFAULT 0,
  image_urls text[] DEFAULT '{}',
  image_names text[] DEFAULT '{}',
  status text NOT NULL DEFAULT 'submitted',
  request_date timestamptz NOT NULL DEFAULT now(),
  expected_delivery timestamptz,
  video_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE user_video_requests ENABLE ROW LEVEL SECURITY;

-- Create policies for RLS
CREATE POLICY "Users can view their own video requests"
  ON user_video_requests
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own video requests"
  ON user_video_requests
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own video requests"
  ON user_video_requests
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_user_video_requests_user_id ON user_video_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_user_video_requests_status ON user_video_requests(status);
CREATE INDEX IF NOT EXISTS idx_user_video_requests_request_date ON user_video_requests(request_date DESC);

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_user_video_requests_updated_at
  BEFORE UPDATE ON user_video_requests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();