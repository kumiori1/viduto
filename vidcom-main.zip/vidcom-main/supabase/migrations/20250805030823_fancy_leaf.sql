/*
  # Create Stripe views for easy data access

  1. Views
    - `stripe_user_subscriptions` - Join users with their subscription data
    - `stripe_user_orders` - Join users with their order data
  2. Security
    - Views inherit RLS from underlying tables
    - Security definer functions for safe access
*/

-- Create view for user subscriptions
CREATE OR REPLACE VIEW stripe_user_subscriptions
WITH (security_invoker = false) AS
SELECT 
  sc.customer_id,
  ss.subscription_id,
  ss.status as subscription_status,
  ss.price_id,
  ss.current_period_start,
  ss.current_period_end,
  ss.cancel_at_period_end,
  ss.payment_method_brand,
  ss.payment_method_last4
FROM stripe_customers sc
LEFT JOIN stripe_subscriptions ss ON sc.customer_id = ss.customer_id
WHERE sc.user_id = auth.uid() 
  AND sc.deleted_at IS NULL 
  AND (ss.deleted_at IS NULL OR ss.deleted_at IS NULL);

-- Create view for user orders
CREATE OR REPLACE VIEW stripe_user_orders
WITH (security_invoker = false) AS
SELECT 
  sc.customer_id,
  so.id as order_id,
  so.checkout_session_id,
  so.payment_intent_id,
  so.amount_subtotal,
  so.amount_total,
  so.currency,
  so.payment_status,
  so.status as order_status,
  so.created_at as order_date
FROM stripe_customers sc
LEFT JOIN stripe_orders so ON sc.customer_id = so.customer_id
WHERE sc.user_id = auth.uid() 
  AND sc.deleted_at IS NULL 
  AND (so.deleted_at IS NULL OR so.deleted_at IS NULL)
ORDER BY so.created_at DESC;