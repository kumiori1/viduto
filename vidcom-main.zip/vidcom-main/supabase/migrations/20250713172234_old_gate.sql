/*
  # הוספת טבלת קרדיטים לסרטונים

  1. טבלה חדשה
    - `user_video_credits`
      - `id` (bigint, primary key)
      - `user_id` (uuid, foreign key)
      - `available_credits` (integer, default 0)
      - `total_purchased` (integer, default 0)
      - `total_used` (integer, default 0)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. אבטחה
    - הפעלת RLS על הטבלה
    - מדיניות לגישה למשתמשים מחוברים בלבד
*/

-- יצירת טבלת קרדיטים לסרטונים
CREATE TABLE IF NOT EXISTS user_video_credits (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  user_id uuid UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  available_credits integer DEFAULT 0 NOT NULL,
  total_purchased integer DEFAULT 0 NOT NULL,
  total_used integer DEFAULT 0 NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- הפעלת Row Level Security
ALTER TABLE user_video_credits ENABLE ROW LEVEL SECURITY;

-- מדיניות לקריאה - משתמשים יכולים לראות רק את הקרדיטים שלהם
CREATE POLICY "Users can view their own credits"
  ON user_video_credits
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- מדיניות לעדכון - משתמשים יכולים לעדכן רק את הקרדיטים שלהם
CREATE POLICY "Users can update their own credits"
  ON user_video_credits
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- מדיניות להוספה - משתמשים יכולים ליצור רק את הקרדיטים שלהם
CREATE POLICY "Users can insert their own credits"
  ON user_video_credits
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- פונקציה לעדכון אוטומטי של updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- טריגר לעדכון אוטומטי של updated_at
CREATE TRIGGER update_user_video_credits_updated_at
  BEFORE UPDATE ON user_video_credits
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();