/*
  # Create feedback table for NPS and user feedback

  1. New Tables
    - `user_feedback`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `chat_id` (text, optional reference to video chat)
      - `video_title` (text, title of the video being rated)
      - `nps_score` (integer, 1-10 rating)
      - `feedback_text` (text, optional written feedback)
      - `feedback_type` (text, type of feedback: nps, general, bug_report)
      - `metadata` (jsonb, additional data like user agent, source page, etc.)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `user_feedback` table
    - Add policy for users to insert their own feedback
    - Add policy for users to read their own feedback
    - Add policy for service role to manage all feedback

  3. Indexes
    - Index on user_id for fast user queries
    - Index on nps_score for analytics
    - Index on created_at for time-based queries
    - Index on feedback_type for filtering
*/

-- Create feedback table
CREATE TABLE IF NOT EXISTS user_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  chat_id text,
  video_title text NOT NULL DEFAULT '',
  nps_score integer CHECK (nps_score >= 1 AND nps_score <= 10),
  feedback_text text DEFAULT '',
  feedback_type text NOT NULL DEFAULT 'nps' CHECK (feedback_type IN ('nps', 'general', 'bug_report', 'feature_request')),
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_feedback ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can insert their own feedback"
  ON user_feedback
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read their own feedback"
  ON user_feedback
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own feedback"
  ON user_feedback
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Service role can manage all feedback"
  ON user_feedback
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_user_feedback_user_id ON user_feedback(user_id);
CREATE INDEX IF NOT EXISTS idx_user_feedback_nps_score ON user_feedback(nps_score);
CREATE INDEX IF NOT EXISTS idx_user_feedback_created_at ON user_feedback(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_feedback_type ON user_feedback(feedback_type);
CREATE INDEX IF NOT EXISTS idx_user_feedback_chat_id ON user_feedback(chat_id) WHERE chat_id IS NOT NULL;

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_user_feedback_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_user_feedback_updated_at
  BEFORE UPDATE ON user_feedback
  FOR EACH ROW
  EXECUTE FUNCTION update_user_feedback_updated_at();