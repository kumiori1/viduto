/*
  # Update Initial Credits to 40

  1. Changes
    - Update handle_new_user function to give 40 credits instead of 10
    - Update sync_user_credits function to give 40 credits for new users
    - Update demo credits in frontend to 40

  2. Rationale
    - 30 credits needed to create a product
    - 10 credits needed to create a video
    - Total: 40 credits for complete first experience
*/

-- Update the handle_new_user function to give 40 credits
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  BEGIN
    -- Insert into public.users table
    INSERT INTO public.users (id, email, created_at, updated_at)
    VALUES (NEW.id, NEW.email, NOW(), NOW())
    ON CONFLICT (id) DO NOTHING;
    
    -- Initialize with 40 free credits (30 for product + 10 for video)
    INSERT INTO public.user_video_credits (user_id, available_credits, total_purchased, total_used)
    VALUES (NEW.id, 40, 40, 0)
    ON CONFLICT (user_id) DO NOTHING;
    
    RETURN NEW;
  EXCEPTION
    WHEN OTHERS THEN
      -- Log error but don't fail the user creation
      RAISE WARNING 'Error in handle_new_user: %', SQLERRM;
      RETURN NEW;
  END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update the sync_user_credits function to give 40 credits
CREATE OR REPLACE FUNCTION sync_user_credits(user_id_param UUID)
RETURNS BOOLEAN AS $$
DECLARE
  credits_exist BOOLEAN;
BEGIN
  -- Check if credits record exists
  SELECT EXISTS(
    SELECT 1 FROM user_video_credits 
    WHERE user_id = user_id_param
  ) INTO credits_exist;
  
  -- If no credits record exists, create one with 40 credits
  IF NOT credits_exist THEN
    INSERT INTO user_video_credits (user_id, available_credits, total_purchased, total_used)
    VALUES (user_id_param, 40, 40, 0)
    ON CONFLICT (user_id) DO NOTHING;
    
    RETURN TRUE;
  END IF;
  
  RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;