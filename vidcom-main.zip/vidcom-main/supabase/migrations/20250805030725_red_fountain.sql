/*
  # Create products table for saved user products

  1. New Tables
    - `products`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `name` (text, product name)
      - `description` (text, optional description)
      - `reference_tag` (text, unique tag like @shoes, @samsungphone)
      - `image_urls` (text array, uploaded product images)
      - `image_names` (text array, original file names)
      - `metadata` (jsonb, additional product data)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
  2. Security
    - Enable RLS on `products` table
    - Add policies for authenticated users to manage their own products
  3. Indexes
    - Index on user_id for fast queries
    - Index on reference_tag for quick lookups
*/

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text DEFAULT '',
  reference_tag text NOT NULL,
  image_urls text[] DEFAULT '{}',
  image_names text[] DEFAULT '{}',
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own products"
  ON products
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert their own products"
  ON products
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own products"
  ON products
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete their own products"
  ON products
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_products_user_id ON products(user_id);
CREATE INDEX IF NOT EXISTS idx_products_reference_tag ON products(reference_tag);
CREATE INDEX IF NOT EXISTS idx_products_created_at ON products(created_at DESC);

-- Unique constraint for reference_tag per user
CREATE UNIQUE INDEX IF NOT EXISTS idx_products_user_reference_tag 
  ON products(user_id, reference_tag);

-- Trigger for updated_at
CREATE TRIGGER update_products_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();