/*
  # Fix Credit Tracking System

  1. Database Schema Updates
    - Add proper credit tracking columns to video_chats table
    - Update existing records with correct values
    - Add constraints and defaults

  2. Security
    - Maintain existing RLS policies
    - Ensure data integrity

  3. Migration Notes
    - Safe migration that preserves existing data
    - Backward compatible with current application
*/

-- Add new credit tracking columns to video_chats table
DO $$
BEGIN
  -- Add product_credits_used_for_chat column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'video_chats' AND column_name = 'product_credits_used_for_chat'
  ) THEN
    ALTER TABLE video_chats ADD COLUMN product_credits_used_for_chat integer DEFAULT 0 NOT NULL;
  END IF;

  -- Add video_credits_used_for_chat column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'video_chats' AND column_name = 'video_credits_used_for_chat'
  ) THEN
    ALTER TABLE video_chats ADD COLUMN video_credits_used_for_chat integer DEFAULT 0 NOT NULL;
  END IF;
END $$;

-- Update existing records to have proper credit tracking
-- For existing chats, we'll estimate based on status and product_type
UPDATE video_chats 
SET 
  product_credits_used_for_chat = CASE 
    WHEN product_type = 'new' THEN 1 
    ELSE 0 
  END,
  video_credits_used_for_chat = CASE 
    WHEN status IN ('approved', 'generating', 'completed', 'revision') THEN 10
    ELSE 0
  END
WHERE product_credits_used_for_chat IS NULL OR video_credits_used_for_chat IS NULL;

-- Update credits_used to be the sum of both credit types
UPDATE video_chats 
SET credits_used = product_credits_used_for_chat + video_credits_used_for_chat;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_video_chats_product_credits 
ON video_chats (product_credits_used_for_chat);

CREATE INDEX IF NOT EXISTS idx_video_chats_video_credits 
ON video_chats (video_credits_used_for_chat);

-- Add check constraints to ensure data integrity
DO $$
BEGIN
  -- Ensure product credits are 0 or 1
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints 
    WHERE constraint_name = 'video_chats_product_credits_check'
  ) THEN
    ALTER TABLE video_chats 
    ADD CONSTRAINT video_chats_product_credits_check 
    CHECK (product_credits_used_for_chat >= 0 AND product_credits_used_for_chat <= 10);
  END IF;

  -- Ensure video credits are reasonable (0-100)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints 
    WHERE constraint_name = 'video_chats_video_credits_check'
  ) THEN
    ALTER TABLE video_chats 
    ADD CONSTRAINT video_chats_video_credits_check 
    CHECK (video_credits_used_for_chat >= 0 AND video_credits_used_for_chat <= 100);
  END IF;
END $$;