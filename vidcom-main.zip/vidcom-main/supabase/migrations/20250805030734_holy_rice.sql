/*
  # Create brand guidelines table for user brand settings

  1. New Tables
    - `brand_guidelines`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users, unique)
      - `logo_url` (text, uploaded logo URL)
      - `primary_color` (text, hex color)
      - `secondary_color` (text, hex color)
      - `accent_color` (text, hex color)
      - `font_family` (text, font selection)
      - `title_style` (text, font weight for titles)
      - `body_style` (text, font weight for body)
      - `mood` (text, video mood preference)
      - `pace` (text, video pace preference)
      - `transitions` (text, transition style preference)
      - `default_prompts` (jsonb, array of default guidelines)
      - `style_preferences` (jsonb, additional style data)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
  2. Security
    - Enable RLS on `brand_guidelines` table
    - Add policies for authenticated users to manage their own guidelines
  3. Constraints
    - One brand guideline per user (unique user_id)
*/

-- Create brand guidelines table
CREATE TABLE IF NOT EXISTS brand_guidelines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  logo_url text DEFAULT '',
  primary_color text DEFAULT '#5EE3FF',
  secondary_color text DEFAULT '#B18CFF',
  accent_color text DEFAULT '#FFD8BE',
  font_family text DEFAULT 'Satoshi',
  title_style text DEFAULT 'bold',
  body_style text DEFAULT 'regular',
  mood text DEFAULT 'professional',
  pace text DEFAULT 'medium',
  transitions text DEFAULT 'smooth',
  default_prompts jsonb DEFAULT '[]',
  style_preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE brand_guidelines ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own brand guidelines"
  ON brand_guidelines
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert their own brand guidelines"
  ON brand_guidelines
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own brand guidelines"
  ON brand_guidelines
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete their own brand guidelines"
  ON brand_guidelines
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Unique constraint - one brand guideline per user
CREATE UNIQUE INDEX IF NOT EXISTS idx_brand_guidelines_user_id 
  ON brand_guidelines(user_id);

-- Index for performance
CREATE INDEX IF NOT EXISTS idx_brand_guidelines_created_at ON brand_guidelines(created_at DESC);

-- Trigger for updated_at
CREATE TRIGGER update_brand_guidelines_updated_at
  BEFORE UPDATE ON brand_guidelines
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();