/*
  # Update user_video_credits to support free tier

  1. Changes
    - Add trigger to automatically give 10 free credits to new users
    - Update default available_credits to 10 for new users

  2. Functions
    - Create function to initialize free credits for new users
*/

-- Function to initialize free credits for new users
CREATE OR REPLACE FUNCTION initialize_free_credits()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert free credits for new user (1 product + 1 video = 10 credits)
  INSERT INTO user_video_credits (user_id, available_credits, total_purchased, total_used)
  VALUES (NEW.id, 10, 0, 0)
  ON CONFLICT (user_id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically give free credits to new users
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.triggers
    WHERE trigger_name = 'initialize_user_free_credits'
  ) THEN
    CREATE TRIGGER initialize_user_free_credits
      AFTER INSERT ON auth.users
      FOR EACH ROW
      EXECUTE FUNCTION initialize_free_credits();
  END IF;
END $$;