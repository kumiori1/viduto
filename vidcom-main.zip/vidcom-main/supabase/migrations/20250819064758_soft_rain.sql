/*
  # Create waitlist table for VidCom AI

  1. New Tables
    - `waitlist_signups`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `position` (integer, auto-generated)
      - `referral_code` (text, unique)
      - `referred_by` (uuid, nullable - references another signup)
      - `referral_count` (integer, default 0)
      - `status` (text, default 'pending')
      - `metadata` (jsonb, for additional data)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `waitlist_signups` table
    - Add policy for public insert (anyone can sign up)
    - Add policy for users to read their own data

  3. Functions
    - Auto-generate position number
    - Auto-generate unique referral code
    - Update referral counts automatically
*/

-- Create waitlist signups table
CREATE TABLE IF NOT EXISTS waitlist_signups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  position integer NOT NULL,
  referral_code text UNIQUE NOT NULL,
  referred_by uuid REFERENCES waitlist_signups(id),
  referral_count integer DEFAULT 0,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'invited', 'converted')),
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE waitlist_signups ENABLE ROW LEVEL SECURITY;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_waitlist_signups_email ON waitlist_signups(email);
CREATE INDEX IF NOT EXISTS idx_waitlist_signups_position ON waitlist_signups(position);
CREATE INDEX IF NOT EXISTS idx_waitlist_signups_referral_code ON waitlist_signups(referral_code);
CREATE INDEX IF NOT EXISTS idx_waitlist_signups_referred_by ON waitlist_signups(referred_by);
CREATE INDEX IF NOT EXISTS idx_waitlist_signups_created_at ON waitlist_signups(created_at DESC);

-- RLS Policies
CREATE POLICY "Anyone can sign up for waitlist"
  ON waitlist_signups
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Users can read their own waitlist data"
  ON waitlist_signups
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Function to auto-generate position number
CREATE OR REPLACE FUNCTION generate_waitlist_position()
RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  next_position integer;
BEGIN
  SELECT COALESCE(MAX(position), 0) + 1 INTO next_position FROM waitlist_signups;
  RETURN next_position;
END;
$$;

-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION generate_referral_code()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  code text;
  exists boolean;
BEGIN
  LOOP
    -- Generate 6-character alphanumeric code
    code := upper(substring(md5(random()::text) from 1 for 6));
    
    -- Check if code already exists
    SELECT EXISTS(SELECT 1 FROM waitlist_signups WHERE referral_code = code) INTO exists;
    
    -- Exit loop if code is unique
    IF NOT exists THEN
      EXIT;
    END IF;
  END LOOP;
  
  RETURN code;
END;
$$;

-- Function to update referral counts
CREATE OR REPLACE FUNCTION update_referral_count()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  -- If this signup was referred by someone, increment their referral count
  IF NEW.referred_by IS NOT NULL THEN
    UPDATE waitlist_signups 
    SET 
      referral_count = referral_count + 1,
      updated_at = now()
    WHERE id = NEW.referred_by;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger to auto-set position and referral code on insert
CREATE OR REPLACE FUNCTION set_waitlist_defaults()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  -- Set position if not provided
  IF NEW.position IS NULL THEN
    NEW.position := generate_waitlist_position();
  END IF;
  
  -- Set referral code if not provided
  IF NEW.referral_code IS NULL OR NEW.referral_code = '' THEN
    NEW.referral_code := generate_referral_code();
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create triggers
CREATE TRIGGER set_waitlist_defaults_trigger
  BEFORE INSERT ON waitlist_signups
  FOR EACH ROW
  EXECUTE FUNCTION set_waitlist_defaults();

CREATE TRIGGER update_referral_count_trigger
  AFTER INSERT ON waitlist_signups
  FOR EACH ROW
  EXECUTE FUNCTION update_referral_count();

-- Trigger to update updated_at timestamp
CREATE TRIGGER update_waitlist_signups_updated_at
  BEFORE UPDATE ON waitlist_signups
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();