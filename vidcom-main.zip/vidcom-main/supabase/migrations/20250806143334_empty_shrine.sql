/*
  # Fix User Creation Issues

  1. Database Functions
    - Create or update trigger functions for user creation
    - Add proper error handling and logging
    - Ensure functions have correct permissions

  2. RLS Policies
    - Update RLS policies to allow system operations
    - Add policies for authenticated user operations
    - Fix any restrictive policies blocking triggers

  3. Triggers
    - Recreate user creation triggers
    - Add proper error handling
    - Ensure triggers fire correctly on auth.users INSERT

  4. Security
    - Maintain security while allowing necessary operations
    - Add service role bypass for system operations
*/

-- Drop existing problematic triggers and functions
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;
DROP FUNCTION IF EXISTS public.initialize_free_credits() CASCADE;

-- Create improved user creation function with better error handling
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Log the start of user creation
  RAISE LOG 'Starting user creation for user_id: %', NEW.id;
  
  BEGIN
    -- Insert into public.users table
    INSERT INTO public.users (id, email, created_at, updated_at)
    VALUES (
      NEW.id,
      NEW.email,
      NOW(),
      NOW()
    )
    ON CONFLICT (id) DO UPDATE SET
      email = EXCLUDED.email,
      updated_at = NOW();
    
    RAISE LOG 'Successfully created user record for user_id: %', NEW.id;
    
  EXCEPTION WHEN OTHERS THEN
    RAISE LOG 'Error creating user record for user_id: %, error: %', NEW.id, SQLERRM;
    -- Don't re-raise the error to prevent rollback
  END;
  
  BEGIN
    -- Initialize free credits for new user
    INSERT INTO public.user_video_credits (
      user_id,
      available_credits,
      total_purchased,
      total_used,
      created_at,
      updated_at
    )
    VALUES (
      NEW.id,
      10, -- Free credits for new users
      10,
      0,
      NOW(),
      NOW()
    )
    ON CONFLICT (user_id) DO UPDATE SET
      available_credits = GREATEST(user_video_credits.available_credits, 10),
      updated_at = NOW();
    
    RAISE LOG 'Successfully initialized credits for user_id: %', NEW.id;
    
  EXCEPTION WHEN OTHERS THEN
    RAISE LOG 'Error initializing credits for user_id: %, error: %', NEW.id, SQLERRM;
    -- Don't re-raise the error to prevent rollback
  END;
  
  RETURN NEW;
END;
$$;

-- Grant necessary permissions to the function
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO service_role;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO postgres;

-- Create the trigger on auth.users
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Update RLS policies to allow system operations

-- Users table policies
DROP POLICY IF EXISTS "Users can read own data" ON public.users;
DROP POLICY IF EXISTS "Users can update own data" ON public.users;
DROP POLICY IF EXISTS "Service role can manage users" ON public.users;

CREATE POLICY "Users can read own data"
  ON public.users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON public.users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Allow service role to manage all user operations (for triggers)
CREATE POLICY "Service role can manage users"
  ON public.users
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- User video credits policies
DROP POLICY IF EXISTS "Users can view their own credits" ON public.user_video_credits;
DROP POLICY IF EXISTS "Users can update their own credits" ON public.user_video_credits;
DROP POLICY IF EXISTS "Users can insert their own credits" ON public.user_video_credits;
DROP POLICY IF EXISTS "Service role can manage credits" ON public.user_video_credits;

CREATE POLICY "Users can view their own credits"
  ON public.user_video_credits
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own credits"
  ON public.user_video_credits
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert their own credits"
  ON public.user_video_credits
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Allow service role to manage all credit operations (for triggers and webhooks)
CREATE POLICY "Service role can manage credits"
  ON public.user_video_credits
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Video chats policies
DROP POLICY IF EXISTS "Users can view their own chats" ON public.video_chats;
DROP POLICY IF EXISTS "Users can insert their own chats" ON public.video_chats;
DROP POLICY IF EXISTS "Users can update their own chats" ON public.video_chats;
DROP POLICY IF EXISTS "Users can delete their own chats" ON public.video_chats;
DROP POLICY IF EXISTS "Service role can manage chats" ON public.video_chats;

CREATE POLICY "Users can view their own chats"
  ON public.video_chats
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own chats"
  ON public.video_chats
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own chats"
  ON public.video_chats
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own chats"
  ON public.video_chats
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Allow service role to manage all chat operations (for webhooks)
CREATE POLICY "Service role can manage chats"
  ON public.video_chats
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Products table policies
DROP POLICY IF EXISTS "Users can view their own products" ON public.products;
DROP POLICY IF EXISTS "Users can insert their own products" ON public.products;
DROP POLICY IF EXISTS "Users can update their own products" ON public.products;
DROP POLICY IF EXISTS "Users can delete their own products" ON public.products;
DROP POLICY IF EXISTS "Service role can manage products" ON public.products;

CREATE POLICY "Users can view their own products"
  ON public.products
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own products"
  ON public.products
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own products"
  ON public.products
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own products"
  ON public.products
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Allow service role to manage all product operations
CREATE POLICY "Service role can manage products"
  ON public.products
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Brand guidelines policies
DROP POLICY IF EXISTS "Users can view their own brand guidelines" ON public.brand_guidelines;
DROP POLICY IF EXISTS "Users can insert their own brand guidelines" ON public.brand_guidelines;
DROP POLICY IF EXISTS "Users can update their own brand guidelines" ON public.brand_guidelines;
DROP POLICY IF EXISTS "Users can delete their own brand guidelines" ON public.brand_guidelines;
DROP POLICY IF EXISTS "Service role can manage brand guidelines" ON public.brand_guidelines;

CREATE POLICY "Users can view their own brand guidelines"
  ON public.brand_guidelines
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own brand guidelines"
  ON public.brand_guidelines
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own brand guidelines"
  ON public.brand_guidelines
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own brand guidelines"
  ON public.brand_guidelines
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Allow service role to manage all brand guidelines operations
CREATE POLICY "Service role can manage brand guidelines"
  ON public.brand_guidelines
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Stripe tables policies (allow service role full access for webhooks)
DROP POLICY IF EXISTS "Service role can manage stripe customers" ON public.stripe_customers;
DROP POLICY IF EXISTS "Service role can manage stripe subscriptions" ON public.stripe_subscriptions;
DROP POLICY IF EXISTS "Service role can manage stripe orders" ON public.stripe_orders;

CREATE POLICY "Service role can manage stripe customers"
  ON public.stripe_customers
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Service role can manage stripe subscriptions"
  ON public.stripe_subscriptions
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Service role can manage stripe orders"
  ON public.stripe_orders
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Create a function to sync user on login (for cases where trigger failed)
CREATE OR REPLACE FUNCTION public.sync_user_on_login(user_id uuid, user_email text)
RETURNS void
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Ensure user exists in public.users
  INSERT INTO public.users (id, email, created_at, updated_at)
  VALUES (user_id, user_email, NOW(), NOW())
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    updated_at = NOW();
  
  -- Ensure user has credits
  INSERT INTO public.user_video_credits (
    user_id,
    available_credits,
    total_purchased,
    total_used,
    created_at,
    updated_at
  )
  VALUES (
    user_id,
    10,
    10,
    0,
    NOW(),
    NOW()
  )
  ON CONFLICT (user_id) DO UPDATE SET
    available_credits = GREATEST(user_video_credits.available_credits, 10),
    updated_at = NOW()
  WHERE user_video_credits.available_credits < 10;
  
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'Error in sync_user_on_login for user_id: %, error: %', user_id, SQLERRM;
END;
$$;

-- Grant permissions to the sync function
GRANT EXECUTE ON FUNCTION public.sync_user_on_login(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.sync_user_on_login(uuid, text) TO service_role;

-- Create a simple test function to verify database connectivity
CREATE OR REPLACE FUNCTION public.test_user_creation()
RETURNS text
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN 'User creation system is working correctly';
EXCEPTION WHEN OTHERS THEN
  RETURN 'Error: ' || SQLERRM;
END;
$$;

-- Grant permissions to test function
GRANT EXECUTE ON FUNCTION public.test_user_creation() TO authenticated;
GRANT EXECUTE ON FUNCTION public.test_user_creation() TO anon;