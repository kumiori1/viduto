/*
  # Transition to Prompt-and-Image Workflow

  1. Schema Updates
    - Add `source_image_url` column to video_chats table for single image storage
    - Add `generation_prompt` column to video_chats table for user prompt
    - Make product-related columns nullable for graceful transition
    
  2. Credit System Consolidation
    - Remove product credit columns from user_video_credits table
    - Migrate existing product credits to video credits
    - Update RPC functions to handle single credit type
    
  3. Data Migration
    - Preserve existing video data
    - Convert product credits to video credits (1 product credit = 10 video credits)
    - Update existing chats to use new schema where possible
    
  4. Security
    - Maintain existing RLS policies
    - Update triggers for new columns
*/

-- Add new columns to video_chats table
DO $$
BEGIN
  -- Add source_image_url column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'video_chats' AND column_name = 'source_image_url'
  ) THEN
    ALTER TABLE video_chats ADD COLUMN source_image_url text;
  END IF;
  
  -- Add generation_prompt column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'video_chats' AND column_name = 'generation_prompt'
  ) THEN
    ALTER TABLE video_chats ADD COLUMN generation_prompt text;
  END IF;
END $$;

-- Make product-related columns nullable (they may already be nullable)
DO $$
BEGIN
  -- Make product_id nullable if not already
  BEGIN
    ALTER TABLE video_chats ALTER COLUMN product_id DROP NOT NULL;
  EXCEPTION
    WHEN OTHERS THEN NULL; -- Ignore if already nullable
  END;
  
  -- Make product_type nullable if not already
  BEGIN
    ALTER TABLE video_chats ALTER COLUMN product_type DROP NOT NULL;
  EXCEPTION
    WHEN OTHERS THEN NULL; -- Ignore if already nullable
  END;
END $$;

-- Migrate existing product credits to video credits
-- Convert 1 product credit = 10 video credits (reasonable conversion rate)
UPDATE user_video_credits 
SET 
  available_video_credits = available_video_credits + (available_product_credits * 10),
  total_video_purchased = total_video_purchased + (total_product_purchased * 10),
  total_video_used = total_video_used + (total_product_used * 10)
WHERE available_product_credits > 0 OR total_product_purchased > 0 OR total_product_used > 0;

-- Remove product credit columns from user_video_credits table
DO $$
BEGIN
  -- Drop available_product_credits column if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_video_credits' AND column_name = 'available_product_credits'
  ) THEN
    ALTER TABLE user_video_credits DROP COLUMN available_product_credits;
  END IF;
  
  -- Drop total_product_purchased column if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_video_credits' AND column_name = 'total_product_purchased'
  ) THEN
    ALTER TABLE user_video_credits DROP COLUMN total_product_purchased;
  END IF;
  
  -- Drop total_product_used column if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_video_credits' AND column_name = 'total_product_used'
  ) THEN
    ALTER TABLE user_video_credits DROP COLUMN total_product_used;
  END IF;
END $$;

-- Update RPC function for simplified credit system
CREATE OR REPLACE FUNCTION add_user_credits_v3(
  user_id_param uuid,
  video_credits_to_add integer,
  is_purchase boolean DEFAULT true
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Insert or update user credits (video credits only)
  INSERT INTO user_video_credits (
    user_id,
    available_video_credits,
    total_video_purchased,
    total_video_used
  ) VALUES (
    user_id_param,
    video_credits_to_add,
    CASE WHEN is_purchase THEN video_credits_to_add ELSE 0 END,
    0
  )
  ON CONFLICT (user_id) DO UPDATE SET
    available_video_credits = user_video_credits.available_video_credits + video_credits_to_add,
    total_video_purchased = CASE 
      WHEN is_purchase THEN user_video_credits.total_video_purchased + video_credits_to_add
      ELSE user_video_credits.total_video_purchased
    END,
    updated_at = now();
    
  RETURN true;
EXCEPTION
  WHEN OTHERS THEN
    RETURN false;
END;
$$;

-- Update RPC function for using credits (simplified)
CREATE OR REPLACE FUNCTION use_user_credits_v3(
  user_id_param uuid,
  chat_id_param text,
  video_credits_to_use integer,
  operation_type text DEFAULT 'video_generation'
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_video_credits integer;
  result json;
BEGIN
  -- Get current video credits
  SELECT available_video_credits INTO current_video_credits
  FROM user_video_credits
  WHERE user_id = user_id_param;
  
  -- Check if user has enough video credits
  IF current_video_credits IS NULL OR current_video_credits < video_credits_to_use THEN
    RETURN json_build_object(
      'success', false,
      'error', 'insufficient_video_credits',
      'available_credits', COALESCE(current_video_credits, 0),
      'required_credits', video_credits_to_use
    );
  END IF;
  
  -- Check if credits were already charged for this chat/operation
  IF chat_id_param IS NOT NULL THEN
    -- Check if this operation was already performed for this chat
    DECLARE
      existing_chat_credits integer;
    BEGIN
      SELECT video_credits_used_for_chat INTO existing_chat_credits
      FROM video_chats
      WHERE id = chat_id_param AND user_id = user_id_param;
      
      -- If this is video generation and credits already charged
      IF operation_type = 'video_generation' AND existing_chat_credits >= 10 THEN
        RETURN json_build_object(
          'success', false,
          'error', 'already_charged',
          'message', 'Credits already charged for this video generation'
        );
      END IF;
      
      -- If this is revision and we're trying to charge again
      IF operation_type = 'video_revision' AND existing_chat_credits > 10 THEN
        RETURN json_build_object(
          'success', false,
          'error', 'already_charged',
          'message', 'Credits already charged for this revision'
        );
      END IF;
    END;
  END IF;
  
  -- Deduct video credits
  UPDATE user_video_credits
  SET 
    available_video_credits = available_video_credits - video_credits_to_use,
    total_video_used = total_video_used + video_credits_to_use,
    updated_at = now()
  WHERE user_id = user_id_param;
  
  -- Update chat credits if chat_id provided
  IF chat_id_param IS NOT NULL THEN
    UPDATE video_chats
    SET 
      video_credits_used_for_chat = video_credits_used_for_chat + video_credits_to_use,
      credits_used = credits_used + video_credits_to_use,
      updated_at = now()
    WHERE id = chat_id_param AND user_id = user_id_param;
  END IF;
  
  RETURN json_build_object(
    'success', true,
    'credits_used', video_credits_to_use,
    'remaining_credits', current_video_credits - video_credits_to_use,
    'operation_type', operation_type
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN json_build_object(
      'success', false,
      'error', 'database_error',
      'message', SQLERRM
    );
END;
$$;

-- Add indexes for new columns
CREATE INDEX IF NOT EXISTS idx_video_chats_source_image ON video_chats(source_image_url);
CREATE INDEX IF NOT EXISTS idx_video_chats_generation_prompt ON video_chats USING gin(to_tsvector('english', generation_prompt));

-- Update existing video_chats to populate new fields where possible
UPDATE video_chats 
SET 
  source_image_url = CASE 
    WHEN array_length(image_urls, 1) > 0 THEN image_urls[1]
    ELSE NULL
  END,
  generation_prompt = CASE 
    WHEN description IS NOT NULL AND description != '' THEN description
    ELSE 'Video generation request'
  END
WHERE source_image_url IS NULL OR generation_prompt IS NULL;

-- Create view for simplified video data
CREATE OR REPLACE VIEW simple_video_chats AS
SELECT 
  id,
  user_id,
  title,
  generation_prompt,
  source_image_url,
  status,
  video_url,
  video_credits_used_for_chat as credits_used,
  created_at,
  updated_at,
  workflow_state
FROM video_chats
WHERE generation_prompt IS NOT NULL;

-- Grant access to the view
GRANT SELECT ON simple_video_chats TO authenticated;
GRANT SELECT ON simple_video_chats TO service_role;