/*
  # User synchronization trigger

  1. New Functions
    - `handle_new_user()` - Automatically creates user record when auth user is created
    - `sync_user_on_login()` - Ensures user exists in users table on login

  2. New Triggers
    - Trigger on auth.users INSERT to create corresponding users table record
    - Manual sync function for existing users

  3. Security
    - Uses SECURITY DEFINER to allow function to access auth schema
    - Maintains RLS policies on users table
*/

-- Function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.users (id, email, created_at, updated_at)
  VALUES (NEW.id, NEW.email, NOW(), NOW())
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    updated_at = NOW();
  
  RETURN NEW;
END;
$$;

-- Function to sync existing users
CREATE OR REPLACE FUNCTION public.sync_user_on_login(user_id UUID, user_email TEXT)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.users (id, email, created_at, updated_at)
  VALUES (user_id, user_email, NOW(), NOW())
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    updated_at = NOW();
END;
$$;

-- Create trigger for new users (if it doesn't exist)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'on_auth_user_created'
  ) THEN
    CREATE TRIGGER on_auth_user_created
      AFTER INSERT ON auth.users
      FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
  END IF;
END $$;

-- Sync all existing auth users to users table
INSERT INTO public.users (id, email, created_at, updated_at)
SELECT 
  id, 
  email, 
  created_at, 
  COALESCE(updated_at, created_at)
FROM auth.users
ON CONFLICT (id) DO UPDATE SET
  email = EXCLUDED.email,
  updated_at = NOW();