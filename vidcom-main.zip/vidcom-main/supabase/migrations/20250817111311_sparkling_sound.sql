/*
  # Add 40 free credits for new users

  1. New Function
    - `give_new_user_credits` - Automatically gives 40 credits to new users
  
  2. Updated Trigger
    - Modified `handle_new_user` trigger to include credit allocation
    
  3. Security
    - Function runs with security definer privileges
    - Only triggered on new user creation
*/

-- Create or replace function to give new users 40 free credits
CREATE OR REPLACE FUNCTION give_new_user_credits()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert 40 free credits for the new user
  INSERT INTO user_video_credits (
    user_id,
    available_credits,
    total_purchased,
    total_used
  ) VALUES (
    NEW.id,
    40,  -- 40 free credits
    40,  -- Count as purchased for tracking
    0    -- No credits used yet
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS give_new_user_credits_trigger ON auth.users;

-- Create trigger to automatically give credits to new users
CREATE TRIGGER give_new_user_credits_trigger
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION give_new_user_credits();

-- Also update the existing handle_new_user function to ensure it includes credits
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert user into public.users table
  INSERT INTO public.users (id, email)
  VALUES (NEW.id, NEW.email)
  ON CONFLICT (id) DO NOTHING;
  
  -- Insert 40 free credits for the new user
  INSERT INTO public.user_video_credits (
    user_id,
    available_credits,
    total_purchased,
    total_used
  ) VALUES (
    NEW.id,
    40,  -- 40 free credits
    40,  -- Count as purchased for tracking
    0    -- No credits used yet
  ) ON CONFLICT (user_id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;