/*
  # Create all missing tables for VidCom AI

  1. New Tables
    - `user_video_credits`
      - `id` (bigint, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `available_credits` (integer, default 0)
      - `total_purchased` (integer, default 0)
      - `total_used` (integer, default 0)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `user_video_requests`
      - `id` (text, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `title` (text)
      - `brief_description` (text)
      - `target_platform` (text)
      - `music_style` (text)
      - `voiceover` (text)
      - `language` (text)
      - `additional_requests` (text)
      - `images_count` (integer)
      - `image_urls` (text array)
      - `image_names` (text array)
      - `status` (text, default 'submitted')
      - `request_date` (timestamptz)
      - `expected_delivery` (timestamptz)
      - `video_url` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    
  3. Performance
    - Add indexes for frequently queried columns
    - Add triggers for automatic updated_at timestamps
*/

-- Create trigger function for updated_at if it doesn't exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create user_video_credits table
CREATE TABLE IF NOT EXISTS user_video_credits (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  available_credits integer NOT NULL DEFAULT 0,
  total_purchased integer NOT NULL DEFAULT 0,
  total_used integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS on user_video_credits
ALTER TABLE user_video_credits ENABLE ROW LEVEL SECURITY;

-- Create policies for user_video_credits
CREATE POLICY "Users can view their own credits"
  ON user_video_credits
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own credits"
  ON user_video_credits
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own credits"
  ON user_video_credits
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create trigger for user_video_credits
CREATE TRIGGER update_user_video_credits_updated_at
  BEFORE UPDATE ON user_video_credits
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create index for user_video_credits
CREATE INDEX IF NOT EXISTS idx_user_video_credits_user_id 
  ON user_video_credits(user_id);

-- Create user_video_requests table
CREATE TABLE IF NOT EXISTS user_video_requests (
  id text PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  brief_description text NOT NULL,
  target_platform text NOT NULL,
  music_style text DEFAULT '',
  voiceover text NOT NULL,
  language text NOT NULL,
  additional_requests text DEFAULT '',
  images_count integer DEFAULT 0,
  image_urls text[] DEFAULT '{}',
  image_names text[] DEFAULT '{}',
  status text DEFAULT 'submitted',
  request_date timestamptz DEFAULT now(),
  expected_delivery timestamptz,
  video_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on user_video_requests
ALTER TABLE user_video_requests ENABLE ROW LEVEL SECURITY;

-- Create policies for user_video_requests
CREATE POLICY "Users can view their own video requests"
  ON user_video_requests
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own video requests"
  ON user_video_requests
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own video requests"
  ON user_video_requests
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create trigger for user_video_requests
CREATE TRIGGER update_user_video_requests_updated_at
  BEFORE UPDATE ON user_video_requests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes for user_video_requests
CREATE INDEX IF NOT EXISTS idx_user_video_requests_user_id 
  ON user_video_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_user_video_requests_status 
  ON user_video_requests(status);
CREATE INDEX IF NOT EXISTS idx_user_video_requests_request_date 
  ON user_video_requests(request_date DESC);